import { 
  collection, 
  addDoc, 
  getDocs,
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  serverTimestamp, 
  doc, 
  setDoc,
  updateDoc, 
  deleteDoc,
  getDoc,
  Timestamp 
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { encryptMessage, decryptMessage, generateKey, exportKey, importKey } from '../lib/encryption';
import { Message, MessageType, Conversation } from '../types';
import { handleFirestoreError, OperationType } from '../lib/error-handler';
import { UserService } from './UserService';

export class MessageService {
  private static COLLECTION = 'conversations';

  static async getOrCreateConversation(participantIds: string[], type: 'private' | 'group' = 'private', groupName?: string): Promise<string> {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error('Not authenticated');

      // Check if current user has blocked any participant, or if any participant has blocked current user
      if (type === 'private') {
        const targetId = participantIds[0];
        const iBlockedTarget = await UserService.isBlocked(targetId);
        if (iBlockedTarget) throw new Error('You have blocked this shadow.');

        const targetDoc = await getDoc(doc(db, 'users', targetId));
        if (targetDoc.exists()) {
          const targetData = targetDoc.data();
          if (targetData.blockedUsers?.includes(user.uid)) {
            throw new Error('This frequency is unavailable.');
          }
        }
      }

      const allParticipants = Array.from(new Set([user.uid, ...participantIds]));

      // Check if private chat already exists
      if (type === 'private' && allParticipants.length === 2) {
        const q = query(
          collection(db, this.COLLECTION),
          where('type', '==', 'private'),
          where('participants', 'array-contains', user.uid)
        );
        const snap = await getDocs(q);
        const existing = snap.docs.find(d => {
          const p = d.data().participants as string[];
          return p.length === 2 && p.includes(participantIds[0]);
        });
        if (existing) {
          return existing.id;
        }
      }

      const newConv = {
        participants: allParticipants,
        type,
        name: type === 'group' ? groupName || 'Unnamed Group' : null,
        createdBy: user.uid,
        updatedAt: serverTimestamp(),
        createdAt: serverTimestamp()
      };

      const docRef = await addDoc(collection(db, this.COLLECTION), newConv);
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, this.COLLECTION);
      throw error;
    }
  }

  static async getConversation(conversationId: string): Promise<Conversation> {
    try {
      const docRef = doc(db, this.COLLECTION, conversationId);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as Conversation;
      } else {
        throw new Error('Shadow Session Not Found');
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, `${this.COLLECTION}/${conversationId}`);
      throw error;
    }
  }

  static async sendMessage(
    conversationId: string, 
    text: string, 
    type: MessageType = 'text', 
    timer: number = 30,
    mediaUrl?: string
  ) {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error('Not authenticated');

      // Check for blocks in private conversations
      const convDoc = await getDoc(doc(db, this.COLLECTION, conversationId));
      if (convDoc.exists()) {
        const convData = convDoc.data();
        if (convData.type === 'private') {
          const targetId = convData.participants.find((p: string) => p !== user.uid);
          if (targetId) {
            const iBlockedTarget = await UserService.isBlocked(targetId);
            if (iBlockedTarget) throw new Error('You have blocked this shadow.');

            const targetDoc = await getDoc(doc(db, 'users', targetId));
            if (targetDoc.exists()) {
              const targetData = targetDoc.data();
              if (targetData.blockedUsers?.includes(user.uid)) {
                throw new Error('This frequency is unavailable.');
              }
            }
          }
        }
      }

      // 1. Generate session key (In a real app, this would be derived from a shared secret)
      // For this implementation, we'll store the key encrypted for the participants or similar.
      // Simplification: We'll generate a key and use it. In E2EE, both parties need the key.
      const key = await generateKey();
      const exportedKey = await exportKey(key);

      // 2. Encrypt
      const { ciphertext, iv } = await encryptMessage(text, key);

      // 3. Create message doc
      const messageData = {
        senderId: user.uid,
        contentEncrypted: ciphertext,
        iv: iv,
        sessionKey: exportedKey, // NOTE: In production, this key itself must be encrypted for the recipient
        type: type,
        mediaUrl: mediaUrl || null,
        timer: timer,
        status: 'sent',
        createdAt: serverTimestamp(),
      };

      const path = `${this.COLLECTION}/${conversationId}/messages`;
      await addDoc(collection(db, path), messageData);
      
      // Update conversation last activity
      await setDoc(doc(db, this.COLLECTION, conversationId), {
        updatedAt: serverTimestamp(),
        lastMessage: {
          senderId: user.uid,
          type,
          createdAt: serverTimestamp()
        }
      }, { merge: true });

    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `conversations/${conversationId}/messages`);
      throw error;
    }
  }

  static subscribeToMessages(conversationId: string, callback: (messages: Message[]) => void) {
    const path = `${this.COLLECTION}/${conversationId}/messages`;
    const q = query(
      collection(db, path),
      orderBy('createdAt', 'asc')
    );

    return onSnapshot(q, (snapshot) => {
      const messages = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Message[];
      callback(messages);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });
  }

  static async deleteMessage(conversationId: string, messageId: string) {
    const path = `${this.COLLECTION}/${conversationId}/messages`;
    try {
      await deleteDoc(doc(db, path, messageId));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `${path}/${messageId}`);
      throw e;
    }
  }

  static async revealMessage(conversationId: string, messageId: string, timerSeconds: number) {
    try {
      const path = `${this.COLLECTION}/${conversationId}/messages`;
      const msgDoc = doc(db, path, messageId);
      
      const revealedAt = Timestamp.now();
      const expiresAt = Timestamp.fromMillis(revealedAt.toMillis() + (timerSeconds * 1000));

      await updateDoc(msgDoc, {
        revealedAt,
        expiresAt,
        status: 'read'
      });

      // Schedule remote deletion (Client-side best effort + Rule enforcement)
      setTimeout(async () => {
        try {
          await deleteDoc(msgDoc);
        } catch (e) {
          console.warn("Auto-delete cleanup failed (might already be deleted or rule restricted)");
        }
      }, timerSeconds * 1000);

    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `conversations/${conversationId}/messages/${messageId}`);
      throw error;
    }
  }
}
