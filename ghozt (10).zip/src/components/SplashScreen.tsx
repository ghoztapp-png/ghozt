import React, { useEffect } from 'react';
import { motion } from 'motion/react';

export const SplashScreen: React.FC<{ onComplete?: () => void }> = ({ onComplete }) => {
  useEffect(() => {
    if (onComplete) {
      const timer = setTimeout(onComplete, 3000);
      return () => clearTimeout(timer);
    }
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1.5, ease: "easeInOut" }}
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#050505] overflow-hidden"
    >
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#1a1a1a_0%,#050505_100%)]" />
        <motion.div 
          animate={{ scale: [1, 1.5, 1], opacity: [0.1, 0.3, 0.1], x: [-100, 100, -100], y: [-100, 100, -100] }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute top-[-20%] left-[-20%] w-[80%] h-[80%] bg-phantom-purple/20 rounded-full blur-[160px]" 
        />
      </div>

      <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden select-none">
        <motion.div
          initial={{ scale: 1.2, opacity: 0, letterSpacing: "0.5em" }}
          animate={{ scale: 1, opacity: 0.05, letterSpacing: "-0.02em" }}
          transition={{ duration: 4, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col items-center w-full px-4"
        >
          <h1 className="text-[38vw] md:text-[35vw] font-black text-white uppercase leading-[0.8] tracking-tighter" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            GHOZT
          </h1>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 60 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 2.5, ease: [0.16, 1, 0.3, 1], delay: 0.8 }}
        className="relative z-10 flex flex-col items-center"
      >
        <img src="https://i.imgur.com/KjaXBWH.png" className="w-32 h-32 md:w-48 md:h-48 rounded-full border border-white/10" />
        <h2 className="text-5xl md:text-8xl font-black text-white uppercase mt-8" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>GHOZT</h2>
        
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.4 }}
          transition={{ duration: 2, delay: 2.5 }}
          className="mt-4 text-[10px] md:text-xs font-bold uppercase tracking-[0.4em] text-phantom-purple"
        >
          Chat without echoes
        </motion.p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.2 }}
        transition={{ duration: 2, delay: 3 }}
        className="absolute bottom-10 flex flex-col items-center gap-1"
      >
        <p className="text-[10px] font-black uppercase tracking-[0.5em] text-white/50">GHOZT Protocol</p>
        <p className="text-[8px] font-mono text-phantom-purple opacity-50 tracking-widest">v4.0.2 // SECURE_NODE_ACTIVE</p>
      </motion.div>

      <motion.div
        animate={{ top: ["-10%", "110%"] }}
        transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
        className="absolute left-0 right-0 h-[1px] bg-phantom-purple/20 blur-[2px] z-20 pointer-events-none"
      />
    </motion.div>
  );
};
