import React from 'react';
import { LogIn } from 'lucide-react';
import { toast } from 'sonner';
import { auth, googleProvider } from '../lib/firebase';
import { signInWithPopup } from 'firebase/auth';

interface LandingPageProps {
  onNavigate?: (route: 'privacy' | 'terms') => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
      if (error.code === 'auth/popup-closed-by-user' || error.code === 'auth/cancelled-popup-request') {
        return;
      }
      console.error("Login failed", error);
      toast.error("Protocol Breach", {
        description: "Failed to authenticate with the shadow network."
      });
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-[#050505] text-white p-6 relative overflow-hidden">
      <div className="flex flex-col items-center w-full max-w-sm z-10">
        <img src="https://i.imgur.com/KjaXBWH.png" alt="Ghozt Logo" className="w-24 h-24 sm:w-32 sm:h-32 rounded-full border border-white/10 mb-8" />
        <h1 className="text-4xl sm:text-5xl font-black uppercase tracking-widest mb-10 text-white" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
          GHOZT
        </h1>

        <button 
          onClick={handleLogin}
          className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold uppercase tracking-wider rounded-xl transition-all"
        >
          <LogIn size={20} />
          Sign In with Google
        </button>
      </div>

      <div className="absolute bottom-10 flex flex-col items-center z-10 gap-6">
        <div className="flex gap-6 uppercase tracking-widest text-[10px] text-white/40">
          <button onClick={() => onNavigate?.('privacy')} className="hover:text-white transition-colors">Privacy Policy</button>
          <button onClick={() => onNavigate?.('terms')} className="hover:text-white transition-colors">Terms of Service</button>
        </div>
        <div className="flex flex-col items-center pointer-events-none select-none">
          <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-phantom-purple opacity-60">Chat without echoes</p>
        </div>
      </div>
    </div>
  );
};

