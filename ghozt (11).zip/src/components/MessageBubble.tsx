import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, PanInfo } from 'motion/react';
import { Clock, Eye, Lock, ShieldCheck, Paperclip, Check, CheckCheck, FileText, Music, File } from 'lucide-react';
import { Message } from '../types';
import { decryptMessage, importKey } from '../lib/encryption';
import { MessageService } from '../services/MessageService';
import { useFirebase } from '../context/FirebaseContext';
import { cn } from '@/lib/utils';

interface MessageBubbleProps {
  message: Message;
  conversationId: string;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({ message, conversationId }) => {
  const { user } = useFirebase();
  const [decryptedText, setDecryptedText] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const isOwn = message.senderId === user?.uid;

  useEffect(() => {
    const decrypt = async () => {
      try {
        // @ts-ignore - sessionKey added in service
        if (!message.contentEncrypted || !message.sessionKey || !message.iv) return;
        
        // @ts-ignore
        const key = await importKey(message.sessionKey);
        const text = await decryptMessage(message.contentEncrypted, message.iv, key);
        setDecryptedText(text);
      } catch (e) {
        console.error("Decryption failed", e);
        setDecryptedText("Decryption Error");
      }
    };

    decrypt();
  }, [message.contentEncrypted, message.sessionKey, message.iv]);

  useEffect(() => {
    if (message.expiresAt) {
      const remaining = Math.round((message.expiresAt.toMillis() - Date.now()) / 1000);
      
      if (remaining <= 0) {
        setTimeLeft(0);
        MessageService.deleteMessage(conversationId, message.id).catch(() => {});
        return;
      }

      setTimeLeft(remaining);

      const interval = setInterval(() => {
        const currentRemaining = Math.round((message.expiresAt!.toMillis() - Date.now()) / 1000);
        if (currentRemaining <= 0) {
          setTimeLeft(0);
          clearInterval(interval);
          MessageService.deleteMessage(conversationId, message.id).catch(() => {});
        } else {
          setTimeLeft(currentRemaining);
        }
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [message.expiresAt, conversationId, message.id]);

  const handleReveal = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!message.revealedAt && !isOwn) {
      MessageService.revealMessage(conversationId, message.id, message.timer);
    }
  };

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    const swipeThreshold = 50;
    const isSwipedLeft = isOwn && info.offset.x < -swipeThreshold;
    const isSwipedRight = !isOwn && info.offset.x > swipeThreshold;
    
    if (isSwipedLeft || isSwipedRight) {
      MessageService.deleteMessage(conversationId, message.id).catch(() => {});
    }
  };

  const isRevealed = !!message.revealedAt || isOwn;

  if (timeLeft !== null && timeLeft <= 0) {
    return null;
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: isOwn ? 10 : -10, y: 10 }}
      animate={{ opacity: 1, x: 0, y: 0 }}
      exit={{ opacity: 0, scale: 0.8, filter: "blur(10px)", transition: { duration: 0.3 } }}
      transition={{ type: "spring", damping: 25, stiffness: 400 }}
      className={cn(
        "flex w-full mb-3 relative group/message",
        isOwn ? "justify-end pl-12" : "justify-start pr-12"
      )}
    >
      <motion.div 
        drag="x"
        dragConstraints={isOwn ? { right: 0, left: 0 } : { left: 0, right: 0 }}
        dragElastic={isOwn ? { left: 0.3, right: 0 } : { right: 0.3, left: 0 }}
        dragDirectionLock
        onDragEnd={handleDragEnd}
        className={cn(
        "max-w-full rounded-[20px] px-4 py-3 relative group overflow-hidden z-10 cursor-grab active:cursor-grabbing",
        isOwn 
          ? "bg-phantom-purple text-white rounded-tr-sm shadow-sm" 
          : "bg-phantom-purple/10 border border-phantom-purple/20 text-white rounded-tl-sm shadow-xl"
      )}>
        {/* Content Layer */}
        <motion.div 
          animate={
            isRevealed 
              ? { filter: "blur(0px)", opacity: 1 } 
              : { filter: "blur(12px)", opacity: 0.2 }
          }
          transition={{ duration: 0.7, ease: "easeOut" }}
          className={cn(
           !isRevealed && "pointer-events-none select-none"
        )}>
          {message.type === 'text' && (
            <p className="text-[15px] leading-relaxed break-words">{decryptedText || "•••••••••••••••"}</p>
          )}
          {message.type === 'image' && message.mediaUrl && (
            <div className="relative overflow-hidden rounded-xl mt-1">
              <img src={message.mediaUrl} alt="Ephemeral" className="max-h-60 w-full object-cover" />
            </div>
          )}
          {message.type === 'video' && message.mediaUrl && (
            <div className="relative overflow-hidden rounded-xl mt-1 bg-black/20">
              <video 
                src={message.mediaUrl} 
                controls={isRevealed}
                className="max-h-60 w-full object-cover rounded-xl"
                referrerPolicy="no-referrer"
              />
            </div>
          )}
          {(message.type === 'file' || message.type === 'audio' || message.type === 'pdf') && message.mediaUrl && (
            <a 
              href={message.mediaUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className={cn(
                "flex items-center gap-3 p-3 rounded-xl transition-all no-underline mt-1",
                isOwn ? "bg-black/10 hover:bg-black/20" : "bg-white/5 hover:bg-white/10"
              )}
            >
              <div className={cn(
                "h-10 w-10 flex items-center justify-center rounded-lg shadow-sm border",
                isOwn ? "bg-white text-phantom-purple border-white/50" : "bg-black text-white border-white/10"
              )}>
                {message.type === 'audio' ? <Music size={18} /> : 
                 message.type === 'pdf' ? <FileText size={18} /> : 
                 <File size={18} />}
              </div>
              <div className="flex flex-col overflow-hidden">
                <span className="text-sm font-semibold truncate">{decryptedText || "Attachment"}</span>
                <span className="text-[10px] opacity-60 uppercase tracking-wider mt-0.5">
                  {message.type === 'audio' ? 'Voice Shadow' : 
                   message.type === 'pdf' ? 'Data Ghost' : 'Secure Payload'}
                </span>
              </div>
            </a>
          )}

          {isRevealed && (
            <div className="mt-1.5 flex items-center justify-end gap-2.5 w-full">
              {message.createdAt && (
                <span className={cn(
                  "text-[10px] font-medium tracking-wide",
                  isOwn ? "text-white/70" : "text-white/30"
                )}>
                  {message.createdAt.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              )}

              {timeLeft !== null && (
                <div className={cn(
                  "flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[9px] font-bold tracking-wider",
                  timeLeft < 5 
                    ? "bg-red-500 text-white animate-pulse" 
                    : isOwn ? "bg-black/20 text-white/80" : "bg-white/10 text-white/50"
                )}>
                  <Clock size={10} strokeWidth={2.5} />
                  <span>{timeLeft}s</span>
                </div>
              )}

              {isOwn && message.revealedAt && (
                <span className="text-[10px] font-medium text-white/80 tracking-wide">
                  Viewed: {message.revealedAt.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              )}

              {isOwn && (
                <div className={cn("flex items-center gap-0.5 text-[10px]", message.status === 'read' ? "text-white" : "text-white/50")}>
                  {message.status === 'read' ? (
                    <CheckCheck size={14} strokeWidth={2.5} className="text-white" />
                  ) : (
                    <Check size={14} strokeWidth={2.5} />
                  )}
                </div>
              )}
            </div>
          )}
        </motion.div>

        {/* Reveal Overlay */}
        <AnimatePresence>
          {!isRevealed && (
            <motion.div 
              initial={{ opacity: 1 }}
              exit={{ opacity: 0, scale: 0.9, filter: "blur(5px)" }}
              transition={{ duration: 0.4 }}
              className="absolute inset-0 z-20 flex items-center justify-center bg-transparent group cursor-pointer" 
              onClick={handleReveal}
            >
               <motion.div
                 whileHover={{ scale: 1.02 }}
                 whileTap={{ scale: 0.98 }}
                 className="flex items-center gap-2 px-4 py-2 rounded-full bg-black/40 backdrop-blur-md border border-white/10 transition-all shadow-lg"
               >
                  <Eye size={14} className="text-white/80 shrink-0" strokeWidth={2} />
                  <span className="text-[11px] font-semibold text-white tracking-wide">Hold to Reveal</span>
               </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Expiring progress bar */}
        {isRevealed && timeLeft !== null && message.timer && (
           <motion.div 
             initial={{ width: `${(timeLeft / message.timer) * 100}%` }}
             animate={{ width: "0%" }}
             transition={{ duration: timeLeft, ease: "linear" }}
             className={cn(
               "absolute bottom-0 left-0 h-[4px]",
               timeLeft < 5 
                 ? "bg-red-500 shadow-[0_0_10px_#ef4444]" 
                 : isOwn ? "bg-black/30" : "bg-phantom-purple/60"
             )}
           />
        )}
      </motion.div>
    </motion.div>
  );
};
