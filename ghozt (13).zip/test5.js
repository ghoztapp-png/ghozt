fetch('http://localhost:3000/some-non-existent-api', { 
  method: 'POST', 
  headers: { 'Content-Type': 'application/json' }, 
  body: '{"test":1}'
}).then(r => r.text().then(t => console.log(r.status, t.substring(0, 150))));
