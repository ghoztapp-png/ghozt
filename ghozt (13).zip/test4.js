fetch('http://localhost:3000/api/upload', { 
  method: 'POST', 
  headers: { 'Content-Type': 'application/json' }, 
  body: 'invalid json'
}).then(r => r.text().then(t => console.log(r.status, t.substring(0, 150))));
