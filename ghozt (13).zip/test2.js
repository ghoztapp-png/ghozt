fetch('http://localhost:3000/api/upload', { 
  method: 'POST', 
  headers: { 'Content-Type': 'application/json' }, 
  body: JSON.stringify({ fileData: 'x'.repeat(100 * 1024), fileName: 'test', mimeType: 'image/png' }) 
}).then(r => r.text().then(t => console.log(r.status, t.substring(0, 50))));
