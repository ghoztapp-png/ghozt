import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MessageSquare, Users } from "lucide-react";
import { FirebaseProvider, useFirebase } from "./context/FirebaseContext";
import { ErrorProvider } from "./context/ErrorContext";
import { Toaster } from "sonner";
import { ConversationList } from "./components/ConversationList";
import { ChatWindow } from "./components/ChatWindow";
import { PrivacyService } from "./services/PrivacyService";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

import { SplashScreen } from "./components/SplashScreen";
import { PrivacyPolicy } from "./components/PrivacyPolicy";
import { LandingPage } from "./components/LandingPage";
import { TermsOfService } from "./components/TermsOfService";

function AppContent() {
  const { user, loading } = useFirebase();
  const [showSplash, setShowSplash] = useState(true);
  const [currentScreen, setCurrentScreen] = useState<'home' | 'privacy' | 'terms'>('home');

  useEffect(() => {
    PrivacyService.initialize();
    
    // Fallback timer to ensure app loads even if splash takes too long
    const timer = setTimeout(() => setShowSplash(false), 3500);
    return () => clearTimeout(timer);
  }, []);

  if (loading) return null;

  return (
    <div className="h-[100dvh] w-full flex flex-col overflow-hidden bg-phantom-black text-white font-sans selection:bg-phantom-purple/30">
      <AnimatePresence mode="wait">
        {showSplash ? (
          <SplashScreen key="splash" onComplete={() => setShowSplash(false)} />
        ) : !user ? (
          <div key="auth-flow" className="flex-1 flex flex-col min-h-0">
            <AnimatePresence mode="wait">
              {currentScreen === 'home' && (
                <LandingPage key="home" onNavigate={setCurrentScreen} />
              )}
              {currentScreen === 'privacy' && (
                <PrivacyPolicy key="privacy" onBack={() => setCurrentScreen('home')} />
              )}
              {currentScreen === 'terms' && (
                <TermsOfService key="terms" onBack={() => setCurrentScreen('home')} />
              )}
            </AnimatePresence>
          </div>
        ) : (
          <Dashboard key="dashboard" />
        )}
      </AnimatePresence>
      <Toaster 
        position="top-center" 
        theme="dark" 
        richColors 
        toastOptions={{ 
          style: { 
            background: 'rgba(15, 15, 15, 0.8)', 
            border: '1px solid rgba(157, 80, 187, 0.3)', 
            backdropFilter: 'blur(10px)', 
            color: 'white' 
          } 
        }} 
      />
    </div>
  );
}

import { ProfileScreen } from "./components/ProfileScreen";

function Dashboard() {
  const { user, profile } = useFirebase();
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [showProfile, setShowProfile] = useState(false);

  if (showProfile) {
    return <ProfileScreen onBack={() => setShowProfile(false)} />;
  }

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-phantom-black relative">
      <AnimatePresence mode="wait">
        {!selectedConversationId ? (
          <motion.div 
            key="list"
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -20, opacity: 0 }}
            className="flex-1 flex flex-col min-h-0"
          >
            <header className="flex items-center justify-between p-6 glass border-b border-white/5">
              <div className="flex items-center gap-3">
                <motion.div
                  animate={{ 
                     y: [0, -3, 0],
                     filter: ["drop-shadow(0 0 10px rgba(157,80,187,0.4))", "drop-shadow(0 0 20px rgba(157,80,187,0.6))", "drop-shadow(0 0 10px rgba(157,80,187,0.4))"]
                  }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="relative flex items-center justify-center w-10 h-10 rounded-full overflow-hidden border border-phantom-purple/30 bg-black"
                >
                  <img src="https://i.imgur.com/KjaXBWH.png" alt="Ghozt Logo" className="w-full h-full object-cover" />
                </motion.div>
                <div>
                  <h1 className="text-xl font-serif font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-br from-white via-phantom-purple to-phantom-purple uppercase italic">
                    Ghozt
                  </h1>
                </div>
              </div>
              <button 
                 onClick={() => setShowProfile(true)}
                 className="flex items-center gap-3 px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 hover:border-phantom-purple/30 hover:bg-white/10 transition-all text-left active:scale-95"
              >
                <div className="flex flex-col text-right">
                  <span className="text-xs font-bold text-white leading-none max-w-[120px] truncate">
                    {profile?.displayName || user?.displayName || user?.email?.split('@')[0] || 'Ghost Shadow'}
                  </span>
                  <span className="text-[9px] text-phantom-purple uppercase tracking-wider mt-1">
                    My Profile
                  </span>
                </div>
                <Avatar className="h-9 w-9 border border-phantom-purple/30 bg-phantom-purple/10">
                  <AvatarImage src={profile?.photoURL || user?.photoURL || undefined} />
                  <AvatarFallback className="text-white bg-phantom-purple/20 text-xs font-bold uppercase">
                    {(profile?.displayName?.[0] || user?.displayName?.[0] || user?.email?.[0] || 'U').toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </button>
            </header>
            
            <div className="flex-1 overflow-hidden">
               <ConversationList 
                 onSelect={(id) => setSelectedConversationId(id)} 
                 selectedId={selectedConversationId} 
               />
            </div>

            <nav className="flex items-center justify-around p-6 glass border-t border-white/5 pb-10">
              <div className="text-phantom-purple drop-shadow-[0_0_5px_rgba(0,229,255,0.5)]"><MessageSquare /></div>
              <div className="text-muted-foreground hover:text-white transition-colors" onClick={() => setShowProfile(true)}><Users /></div>
            </nav>
          </motion.div>
        ) : (
          <motion.div 
            key="chat"
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 20, opacity: 0 }}
            className="flex-1 flex flex-col overflow-hidden min-h-0"
          >
            <ChatWindow 
              conversationId={selectedConversationId} 
              onBack={() => setSelectedConversationId(null)} 
              onOpenProfile={() => setShowProfile(true)}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

const GhostIcon = ({ size = 24, className = "" }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M9 10h.01M15 10h.01M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z" />
  </svg>
);

export default function App() {
  return (
    <ErrorProvider>
      <FirebaseProvider>
        <AppContent />
      </FirebaseProvider>
    </ErrorProvider>
  );
}
