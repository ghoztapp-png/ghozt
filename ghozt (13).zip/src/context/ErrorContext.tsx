import React, { createContext, useContext, useEffect } from 'react';
import { toast } from 'sonner';
import { errorBus, getFriendlyErrorMessage, FirestoreErrorInfo } from '../lib/error-handler';

interface ErrorContextType {
  reportError: (err: any) => void;
}

const ErrorContext = createContext<ErrorContextType | undefined>(undefined);

export const ErrorProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  useEffect(() => {
    // Listen for global firestore errors emitted from services
    const unsubscribe = errorBus.subscribe((errorInfo: FirestoreErrorInfo) => {
      const { title, description } = getFriendlyErrorMessage(errorInfo.error);
      
      toast.error(title, {
        description,
        action: {
          label: "Dismiss",
          onClick: () => {}
        }
      });
    });

    return () => unsubscribe();
  }, []);

  const reportError = (err: any) => {
    const message = err instanceof Error ? err.message : String(err);
    const { title, description } = getFriendlyErrorMessage(message);
    
    toast.error(title, {
      description,
      action: {
        label: "Dismiss",
        onClick: () => {}
      }
    });
  };

  return (
    <ErrorContext.Provider value={{ reportError }}>
      {children}
    </ErrorContext.Provider>
  );
};

export const useError = () => {
  const context = useContext(ErrorContext);
  if (context === undefined) {
    throw new Error('useError must be used within an ErrorProvider');
  }
  return context;
};
