import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { UserProfile } from '../types';
import { NotificationService } from '../services/NotificationService';

interface FirebaseContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  signOut: () => Promise<void>;
}

const FirebaseContext = createContext<FirebaseContextType | undefined>(undefined);

export const FirebaseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;
    let unsubscribeNotifications: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      
      if (currentUser) {
        // Sync profile and listen for updates
        const userDoc = doc(db, 'users', currentUser.uid);
        
        unsubscribeProfile = onSnapshot(userDoc, (snap) => {
          if (snap.exists()) {
            const updatedProfile = snap.data() as UserProfile;
            
            // Migration: Add displayName_lowercase if missing
            if (updatedProfile.displayName && !updatedProfile.displayName_lowercase) {
              setDoc(userDoc, { 
                displayName_lowercase: updatedProfile.displayName.toLowerCase() 
              }, { merge: true });
            }

            setProfile(updatedProfile);
            
            // Re-initialize notification listener if not already done
            if (!unsubscribeNotifications) {
              unsubscribeNotifications = NotificationService.initializeNotificationListener(currentUser.uid);
            }
          } else {
            const newProfile: UserProfile & { displayName_lowercase: string } = {
              uid: currentUser.uid,
              email: currentUser.email || '',
              displayName: currentUser.displayName || 'Ghozt User',
              displayName_lowercase: (currentUser.displayName || 'Ghozt User').toLowerCase(),
              photoURL: currentUser.photoURL || undefined,
              trustScore: 100,
              isPremium: false,
              createdAt: serverTimestamp(),
            };
            setDoc(userDoc, newProfile);
            setProfile(newProfile);
          }
        });
      } else {
        setProfile(null);
        if (unsubscribeProfile) {
          unsubscribeProfile();
          unsubscribeProfile = null;
        }
        if (unsubscribeNotifications) {
          unsubscribeNotifications();
          unsubscribeNotifications = null;
        }
      }
      setLoading(false);
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfile) unsubscribeProfile();
      if (unsubscribeNotifications) unsubscribeNotifications();
    };
  }, []); // Only on mount

  const signOut = () => auth.signOut();

  return (
    <FirebaseContext.Provider value={{ user, profile, loading, signOut }}>
      {children}
    </FirebaseContext.Provider>
  );
};

export const useFirebase = () => {
  const context = useContext(FirebaseContext);
  if (context === undefined) {
    throw new Error('useFirebase must be used within a FirebaseProvider');
  }
  return context;
};
