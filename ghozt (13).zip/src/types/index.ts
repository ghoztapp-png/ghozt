export type MessageType = 'text' | 'image' | 'video' | 'audio' | 'pdf' | 'file';
export type MessageStatus = 'sent' | 'delivered' | 'read';
export type ConversationType = 'private' | 'group';

export interface NotificationSettings {
  enabled: boolean;
  sound: string; // e.g. 'phantom', 'whisper', 'pulse', 'static'
}

export interface UserNotifications {
  messages: NotificationSettings;
  mentions: NotificationSettings;
  system: NotificationSettings;
  customSounds?: Record<string, string>; // name -> base64 or URL
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  displayName_lowercase?: string;
  photoURL?: string;
  phone?: string;
  trustScore: number;
  isPremium: boolean;
  blockedUsers?: string[];
  createdAt: any;
  lastActive?: any;
  dndMode?: boolean;
  visibility?: 'online' | 'invisible';
  notifications?: UserNotifications;
}

export interface Conversation {
  id: string;
  participants: string[];
  type: ConversationType;
  name?: string; // For groups
  lastMessage?: any;
  updatedAt: any;
  createdBy?: string;
}

export interface Message {
  id: string;
  senderId: string;
  contentEncrypted: string; // Base64 ciphertext
  type: MessageType;
  mediaUrl?: string;
  fileName?: string;
  timer: 5 | 10 | 30 | 60 | 3600; // in seconds
  revealedAt?: any;
  expiresAt?: any;
  status: MessageStatus;
  createdAt: any;
  iv?: string; // For AES-GCM decryption
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: 'create' | 'update' | 'delete' | 'list' | 'get' | 'write';
  path: string | null;
  authInfo: any;
}
