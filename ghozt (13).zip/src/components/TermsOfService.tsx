import React from 'react';
import { motion } from 'motion/react';
import { ChevronLeft } from 'lucide-react';

export const TermsOfService: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  return (
    <div className="min-h-screen bg-phantom-deep text-white font-sans p-6 md:p-12 overflow-y-auto">
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-white/50 hover:text-white transition-colors group mb-8"
      >
        <ChevronLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
        <span className="text-sm font-medium tracking-wider uppercase">Return</span>
      </button>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-3xl mx-auto bg-white/[0.02] border border-white/5 p-8 md:p-12 rounded-3xl"
      >
        <h1 className="text-3xl md:text-5xl font-bold uppercase tracking-tight mb-8" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
          Terms of Service
        </h1>

        <div className="space-y-6 text-white/70 font-light leading-relaxed">
          <section>
            <h2 className="text-xl text-white font-bold mb-3 underline decoration-phantom-purple">1. The Shadow Protocol</h2>
            <p>By entering the Ghozt network, you acknowledge that all communications are ephemeral. We do not guarantee the retrieval of any data once the expiry timer has elapsed.</p>
          </section>
          
          <section>
            <h2 className="text-xl text-white font-bold mb-3 underline decoration-phantom-purple">2. User Conduct</h2>
            <p>Users are expected to respect the privacy of others. Any attempt to bypass screenshot deterrents or compromising the trust-score system may lead to immediate account termination.</p>
          </section>
          
          <section>
            <h2 className="text-xl text-white font-bold mb-3 underline decoration-phantom-purple">3. Service Availability</h2>
            <p>Ghozt provides a best-effort service for encrypted communications. We are not responsible for metadata or transmission artifacts inherent to the public internet.</p>
          </section>

          <section>
            <h2 className="text-xl text-white font-bold mb-3 underline decoration-phantom-purple">4. Governing Law</h2>
            <p>This protocol operates under the digital jurisdiction of decentralized privacy standards. Local laws regarding encryption and data transmission still apply to individual users.</p>
          </section>
        </div>
      </motion.div>
    </div>
  );
};
