import React, { useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Search, UserPlus, Users, Ghost } from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { UserProfile } from '../types';
import { Badge } from '@/components/ui/badge';
import { UserService } from '../services/UserService';
import { MessageService } from '../services/MessageService';

export const NewChatDialog: React.FC<{ onSuccess: (id: string) => void }> = ({ onSuccess }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState<UserProfile[]>([]);
  const [groupName, setGroupName] = useState('');

  const handleSearch = async () => {
    if (!searchTerm.trim()) return;
    setLoading(true);
    try {
      const found = await UserService.searchUsers(searchTerm);
      setResults(found);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const startChat = async () => {
    const user = auth.currentUser;
    if (!user) return;

    setLoading(true);
    try {
      const participantIds = selectedUsers.map(u => u.uid);
      const type = participantIds.length > 1 ? 'group' : 'private';
      
      const conversationId = await MessageService.getOrCreateConversation(
        participantIds, 
        type, 
        groupName
      );
      
      onSuccess(conversationId);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog>
      <DialogTrigger
        render={
          <button className="text-phantom-purple p-2 rounded-full bg-phantom-purple/10 hover:bg-phantom-purple/20 transition-all">
            <UserPlus size={20} />
          </button>
        }
      />
      <DialogContent className="glass border-white/5 bg-phantom-black text-white sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 italic tracking-tight font-bold italic">
            <Ghost className="text-phantom-purple" /> INITIALIZE SHADOW
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex gap-2">
            <div className="relative flex-1">
               <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
               <Input 
                 placeholder="Search by Name, Email or Phone..." 
                 value={searchTerm}
                 onChange={(e) => setSearchTerm(e.target.value)}
                 className="bg-white/5 border-white/5 pl-10 focus:border-phantom-purple/50"
                 onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
               />
            </div>
            <button onClick={handleSearch} className="rounded-lg bg-phantom-purple px-4 py-2 font-bold text-phantom-black">
              Find
            </button>
          </div>

          <div className="flex flex-wrap gap-2">
             {selectedUsers.map(u => (
               <Badge key={u.uid} className="bg-phantom-purple text-white gap-1 py-1">
                 {u.displayName}
                 <button onClick={() => setSelectedUsers(prev => prev.filter(x => x.uid !== u.uid))}>×</button>
               </Badge>
             ))}
          </div>

          {selectedUsers.length > 1 && (
            <Input 
              placeholder="Group Shadow Name..." 
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              className="bg-white/5 border-white/5 focus:border-phantom-purple/50"
            />
          )}

          <div className="max-h-60 overflow-y-auto space-y-2">
             {loading ? (
               <p className="text-center text-xs opacity-50">Searching frequencies...</p>
             ) : results.length > 0 ? (
               results.map(res => (
                 <button 
                   key={res.uid}
                   onClick={() => !selectedUsers.find(u => u.uid === res.uid) && setSelectedUsers(prev => [...prev, res])}
                   className="flex items-center gap-3 w-full p-3 rounded-xl hover:bg-white/5 transition-colors border border-transparent hover:border-white/10"
                 >
                    <div className="h-10 w-10 rounded-full bg-phantom-purple/10 border border-phantom-purple/30 flex items-center justify-center">
                       <Ghost size={16} className="text-phantom-purple" />
                    </div>
                    <div className="text-left">
                       <p className="text-sm font-bold">{res.displayName}</p>
                       <p className="text-[10px] opacity-40">{res.email}</p>
                    </div>
                 </button>
               ))
             ) : searchTerm && (
                <p className="text-center text-xs opacity-40 py-4 italic">No shadows identified at this frequency.</p>
             )}
          </div>

          <button 
            disabled={selectedUsers.length === 0}
            onClick={startChat}
            className="w-full rounded-xl bg-gradient-to-r from-phantom-purple to-phantom-purple p-4 font-bold text-white shadow-lg disabled:opacity-30 flex items-center justify-center gap-2"
          >
            {selectedUsers.length > 1 ? <Users size={18} /> : <Search size={18} />}
            {selectedUsers.length > 1 ? 'FORM GROUP SHADOW' : 'INITIALIZE SHADOW'}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
