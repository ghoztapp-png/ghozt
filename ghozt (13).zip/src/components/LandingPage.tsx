import React, { useState } from 'react';
import { ShieldCheck, ArrowRight, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { toast } from 'sonner';
import { auth, googleProvider } from '../lib/firebase';
import { signInWithPopup } from 'firebase/auth';

interface LandingPageProps {
  onNavigate?: (route: 'privacy' | 'terms') => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    if (isLoading) return;
    setIsLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
      if (error.code === 'auth/popup-closed-by-user' || error.code === 'auth/cancelled-popup-request') {
        setIsLoading(false);
        return;
      }
      console.error("Login failed", error);
      toast.error("Protocol Breach", {
        description: "Failed to authenticate with the shadow network."
      });
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-phantom-deep text-white p-6 relative overflow-hidden select-none">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-gradient-to-tr from-phantom-purple/20 via-cyan-500/10 to-transparent rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none opacity-40" />

      {/* Main Container */}
      <div className="flex flex-col items-center w-full max-w-md z-10">
        {/* Logo Header */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="flex flex-col items-center mb-8"
        >
          <div className="relative flex items-center justify-center w-28 h-28 rounded-full border border-white/10 bg-black/60 p-1 shadow-[0_0_30px_rgba(157,80,187,0.3)] mb-5">
            <motion.img 
              src="https://i.imgur.com/KjaXBWH.png" 
              alt="Ghozt Logo" 
              className="w-full h-full object-cover rounded-full"
              animate={{
                filter: ["drop-shadow(0 0 10px rgba(157,80,187,0.4))", "drop-shadow(0 0 20px rgba(0,229,255,0.6))", "drop-shadow(0 0 10px rgba(157,80,187,0.4))"]
              }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            />
          </div>

          <h1 className="text-4xl sm:text-5xl font-black uppercase tracking-[0.25em] text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-phantom-purple italic" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            GHOZT
          </h1>
          <p className="text-[11px] font-mono uppercase tracking-[0.3em] text-white/40 mt-1">
            Ephemeral Shadow Protocol
          </p>
        </motion.div>

        {/* Auth Glass Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1, ease: "easeOut" }}
          className="w-full bg-white/[0.03] backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 flex flex-col items-center shadow-2xl relative group overflow-hidden"
        >
          {/* Subtle top edge glow */}
          <div className="absolute top-0 left-1/4 right-1/4 h-[1px] bg-gradient-to-r from-transparent via-phantom-purple to-transparent opacity-70" />

          <div className="w-full flex items-center justify-between text-[11px] font-mono text-white/50 mb-6 uppercase tracking-wider">
            <span className="flex items-center gap-1.5 text-phantom-purple font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-phantom-purple animate-ping" />
              Node Active
            </span>
            <span className="text-white/30">Auth v4.2</span>
          </div>

          <p className="text-xs text-white/70 text-center mb-6 leading-relaxed">
            Enter the zero-knowledge communication node. All messages auto-expire.
          </p>

          {/* Redesigned Sign In Button */}
          <motion.button 
            onClick={handleLogin}
            disabled={isLoading}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-white via-slate-100 to-white hover:from-white hover:to-slate-200 text-black font-extrabold uppercase tracking-wider py-4 px-6 shadow-[0_0_25px_rgba(255,255,255,0.15)] hover:shadow-[0_0_30px_rgba(157,80,187,0.4)] transition-all flex items-center justify-between group/btn border border-white/50 active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {/* Shimmer overlay */}
            <div className="absolute inset-0 w-1/2 h-full bg-white/40 skew-x-12 -translate-x-full group-hover/btn:translate-x-[300%] transition-transform duration-1000 ease-in-out pointer-events-none" />

            {/* Left Google Icon */}
            <div className="flex items-center justify-center w-8 h-8 rounded-xl bg-black/5 shrink-0">
              {isLoading ? (
                <Loader2 size={18} className="animate-spin text-phantom-purple" />
              ) : (
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
              )}
            </div>

            {/* Center Text */}
            <span className="text-xs sm:text-sm tracking-widest text-slate-900 font-black">
              {isLoading ? "Authenticating..." : "Sign In with Google"}
            </span>

            {/* Right Arrow / Action icon */}
            <div className="flex items-center justify-center w-7 h-7 rounded-lg bg-black/5 group-hover/btn:bg-black group-hover/btn:text-white transition-colors shrink-0">
              <ArrowRight size={14} className="group-hover/btn:translate-x-0.5 transition-transform" />
            </div>
          </motion.button>

          {/* Security badge */}
          <div className="flex items-center gap-2 mt-6 text-[10px] text-white/40 font-mono tracking-wider">
            <ShieldCheck size={13} className="text-emerald-400 shrink-0" />
            <span>End-to-End Encrypted Auth · Zero Logs</span>
          </div>
        </motion.div>
      </div>

      {/* Bottom Footer Links */}
      <div className="absolute bottom-8 flex flex-col items-center z-10 gap-4">
        <div className="flex gap-6 uppercase tracking-widest text-[10px] text-white/40">
          <button onClick={() => onNavigate?.('privacy')} className="hover:text-white transition-colors">Privacy Policy</button>
          <span className="text-white/10">•</span>
          <button onClick={() => onNavigate?.('terms')} className="hover:text-white transition-colors">Terms of Service</button>
        </div>
        <div className="flex flex-col items-center pointer-events-none select-none">
          <p className="text-[10px] font-black uppercase tracking-[0.4em] text-phantom-purple text-glow-purple">
            Chat Without Echoes
          </p>
        </div>
      </div>
    </div>
  );
};


