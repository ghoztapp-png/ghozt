import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mic,
  Send, 
  ChevronLeft, 
  Clock, 
  Image as ImageIcon, 
  Paperclip, 
  MoreVertical,
  Activity,
  User,
  ZoomIn,
  ZoomOut,
  X,
  Play,
  RotateCcw,
  Smartphone,
  Ghost,
  Camera,
  Search,
  Palette,
  LogOut,
  Bell,
  BellOff,
  Eye,
  Zap,
  Shield,
  StopCircle,
  Lock,
  FileText,
  Music,
  File
} from 'lucide-react';
import { MessageBubble } from './MessageBubble';
import { MessageService } from '../services/MessageService';
import { UserService } from '../services/UserService';
import { Message, Conversation, UserProfile } from '../types';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { useFirebase } from '../context/FirebaseContext';
import { db } from '../lib/firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { io, Socket } from 'socket.io-client';
import { PrivacyService } from '../services/PrivacyService';
import { toast } from 'sonner';

interface ChatWindowProps {
  conversationId: string;
  onBack: () => void;
  onOpenProfile?: () => void;
}

import { Camera as CapCamera, CameraResultType } from '@capacitor/camera';
import { MediaService } from '../services/MediaService';

export const ChatWindow: React.FC<ChatWindowProps> = ({ conversationId, onBack, onOpenProfile }) => {
  const { user, profile } = useFirebase();
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [recipient, setRecipient] = useState<UserProfile | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [timer, setTimer] = useState<5 | 10 | 30 | 60 | 3600>(30);
  const [isUploading, setIsUploading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isRecordingAudio, setIsRecordingAudio] = useState(false);
  const [isBlurry, setIsBlurry] = useState(false);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewType, setPreviewType] = useState<'image' | 'video' | 'audio' | 'pdf' | 'file' | null>(null);
  const [isZoomed, setIsZoomed] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<Socket | null>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // 10MB limit for shadow transmissions
    const MAX_SIZE = 10 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
      toast.error("Packet Too Large", { 
        description: "Shadow transmissions are capped at 10MB to maintain spectral integrity." 
      });
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    const url = URL.createObjectURL(file);
    
    let type: 'image' | 'video' | 'audio' | 'pdf' | 'file' = 'file';
    if (file.type.startsWith('image/')) type = 'image';
    else if (file.type.startsWith('video/')) type = 'video';
    else if (file.type.startsWith('audio/')) type = 'audio';
    else if (file.type === 'application/pdf') type = 'pdf';
    
    setPendingFile(file);
    setPreviewUrl(url);
    setPreviewType(type);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const cancelPendingMedia = () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPendingFile(null);
    setPreviewUrl(null);
    setPreviewType(null);
    setIsZoomed(false);
  };

  const sendPendingMedia = async () => {
    if (!pendingFile || !previewUrl) return;

    setIsUploading(true);
    try {
      const url = await MediaService.uploadMedia(pendingFile, conversationId);
      await MessageService.sendMessage(conversationId, pendingFile.name, previewType!, timer, url);
      cancelPendingMedia();
    } catch (error: any) {
      console.error("Upload failed", error);
      toast.error("Upload Failed", { description: String(error) });
    } finally {
      setIsUploading(false);
      cancelPendingMedia();
    }
  };

  useEffect(() => {
    // Socket initialization
    const socket = io();
    socketRef.current = socket;

    socket.emit('join', conversationId);

    socket.on('typing', (data: { userId: string, userName: string, isTyping: boolean }) => {
      if (data.userId !== user?.uid) {
        setTypingUsers(prev => {
          if (data.isTyping) {
            return prev.includes(data.userName) ? prev : [...prev, data.userName];
          } else {
            return prev.filter(name => name !== data.userName);
          }
        });
      }
    });

    socket.on('screenshot', (data: { userId: string, userName: string }) => {
      if (data.userId !== user?.uid) {
        toast.warning("SCREENSHOT DETECTED", {
          description: `${data.userName} attempted to capture the frequency. Trust score compromised.`,
        });
      }
    });

    const handleScreenshot = () => {
      if (!socketRef.current || !user) return;
      
      socketRef.current.emit('screenshot', {
        roomId: conversationId,
        userId: user.uid,
        userName: profile?.displayName || 'Ghost'
      });
      
      PrivacyService.handleScreenshotAttempt();
    };

    window.addEventListener('keydown', (e) => {
      if (e.key === 'PrintScreen' || (e.ctrlKey && e.key === 'p')) {
        handleScreenshot();
      }
    });

    const unsubscribe = MessageService.subscribeToMessages(conversationId, (msgs) => {
      // Deduplicate messages by ID to prevent any double-render echoes
      const uniqueMsgs = Array.from(new Map(msgs.map(m => [m.id, m])).values());
      setMessages(uniqueMsgs);
    });

    // Fetch conversation details
    const fetchConversationMetadata = async () => {
      if (conversationId === 'global') return;
      try {
        const conv = await MessageService.getConversation(conversationId);
        setConversation(conv);
        
        if (conv.type === 'private') {
          const otherId = conv.participants.find(p => p !== user?.uid) || user?.uid;
          if (otherId) {
            const otherProfile = await UserService.getUserProfile(otherId);
            setRecipient(otherProfile);
          }
        }
      } catch (err) {
        console.error("Failed to fetch conversation metadata", err);
      }
    };

    fetchConversationMetadata();

    // Commenting out blur listeners because they break the AI Studio code editor preview
    // const handleVisibility = () => setIsBlurry(document.hidden);
    // window.addEventListener('visibilitychange', handleVisibility);
    // window.addEventListener('blur', () => setIsBlurry(true));
    // window.addEventListener('focus', () => setIsBlurry(false));

    return () => {
      unsubscribe();
      socket.emit('leave', conversationId);
      socket.disconnect();
      // window.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [conversationId, user?.uid]);

  useEffect(() => {
    if (scrollRef.current) {
      const scrollArea = scrollRef.current;
      if (scrollArea) {
        scrollArea.scrollTo({
          top: scrollArea.scrollHeight,
          behavior: 'smooth'
        });
      }
    }
  }, [messages, typingUsers]);

  const handleTyping = () => {
    if (!socketRef.current || !user) return;

    socketRef.current.emit('typing', {
      roomId: conversationId,
      userId: user.uid,
      userName: profile?.displayName || 'Ghost',
      isTyping: true
    });

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);

    typingTimeoutRef.current = setTimeout(() => {
      socketRef.current?.emit('typing', {
        roomId: conversationId,
        userId: user.uid,
        userName: profile?.displayName || 'Ghost',
        isTyping: false
      });
    }, 2000);
  };

  const handleSend = async () => {
    if (!inputValue.trim()) return;
    const text = inputValue.trim();
    setInputValue('');
    
    // Stop typing immediately when sending
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    socketRef.current?.emit('typing', {
      roomId: conversationId,
      userId: user?.uid,
      userName: profile?.displayName || 'Ghost',
      isTyping: false
    });

    try {
      await MessageService.sendMessage(conversationId, text, 'text', timer);
    } catch (error) {
      console.error("Message send failed", error);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: true, 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        const file = new File([blob], 'shadow_video.webm', { type: 'video/webm' });
        const url = URL.createObjectURL(file);
        
        setPendingFile(file);
        setPreviewUrl(url);
        setPreviewType('video');
        stream.getTracks().forEach(t => t.stop());
      };

      recorder.start();
      setIsRecording(true);
    } catch (e) {
      console.error(e);
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
  };

  const handleCameraCapture = async () => {
    try {
      // First try Capacitor Camera for native-like experience (works with PWA elements if configured)
      // Check if we are on web and avoid some permission checks that might throw "Not implemented"
      const isWeb = !window.hasOwnProperty('Capacitor') || (window as any).Capacitor.getPlatform() === 'web';
      
      let canUseCapacitor = true;
      if (!isWeb) {
        const permissions = await CapCamera.checkPermissions();
        if (permissions.camera !== 'granted') {
          const result = await CapCamera.requestPermissions();
          if (result.camera !== 'granted') {
            toast.error("Camera access denied");
            return;
          }
        }
      }

      try {
        const image = await CapCamera.getPhoto({
          quality: 90,
          allowEditing: false,
          resultType: CameraResultType.Uri,
        });

        if (image.webPath) {
          const response = await fetch(image.webPath);
          const blob = await response.blob();
          const file = new File([blob], `shadow_capture.${image.format}`, { type: `image/${image.format}` });
          
          setPendingFile(file);
          setPreviewUrl(image.webPath);
          setPreviewType('image');
          return; // Success
        }
      } catch (capError: any) {
        console.warn("Capacitor camera failed, falling back to web capture:", capError);
        // If it says "Not implemented on web", we proceed to fallback
        if (capError.message === 'Not implemented on web') {
          canUseCapacitor = false;
        } else {
          throw capError;
        }
      }

      // Web Fallback: Use hidden input with capture attribute
      if (!canUseCapacitor || isWeb) {
        if (cameraInputRef.current) {
          cameraInputRef.current.click();
        }
      }
    } catch (e: any) {
      console.error("Camera access terminated", e);
      // Final fallback if everything fails
      if (e.message !== 'User cancelled photos app') {
        toast.error("Camera Protocol Failed", { description: e.message || "Manual upload required." });
      }
    }
  };

  const handleCameraInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    setPendingFile(file);
    setPreviewUrl(url);
    setPreviewType('image');
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  const startAudioRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
      recorder.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        const file = new File([blob], 'shadow_voice.webm', { type: 'audio/webm' });
        
        setIsUploading(true);
        try {
          const url = await MediaService.uploadMedia(file, conversationId);
          await MessageService.sendMessage(conversationId, 'Voice Secret', 'audio', timer, url);
          toast.success("Voice Data Transmitted");
        } catch (error: any) {
          console.error("Voice broadcast failed", error);
        } finally {
          setIsUploading(false);
          stream.getTracks().forEach(t => t.stop());
        }
      };

      recorder.start();
      setIsRecordingAudio(true);
    } catch (e) {
      console.error(e);
      toast.error("Frequency Blocked", { description: "Mic access denied." });
    }
  };

  const stopAudioRecording = () => {
    mediaRecorderRef.current?.stop();
    setIsRecordingAudio(false);
  };


  const formatTypingMessage = (names: string[]) => {
    if (names.length === 0) return null;
    if (names.length === 1) return `${names[0]} is typing...`;
    if (names.length === 2) return `${names[0]} and ${names[1]} are typing...`;
    if (names.length === 3) return `${names[0]}, ${names[1]} and ${names[2]} are typing...`;
    return `${names[0]}, ${names[1]} and ${names.length - 2} others are typing...`;
  };

  return (
    <div className="flex flex-1 min-h-0 flex-col bg-phantom-black relative overflow-hidden">
      <AnimatePresence>
        {isBlurry && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-[100] flex flex-col items-center justify-center bg-black/80 backdrop-blur-3xl overflow-hidden font-mono cursor-pointer"
            onClick={() => setIsBlurry(false)}
          >
            {/* Hazard Stripes Background */}
            <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, #ff0000 10px, #ff0000 20px)' }} />
            
            {/* Grid */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none" />
            
            <motion.div 
              animate={{ 
                scale: [1, 1.05, 1],
                filter: ["drop-shadow(0 0 20px rgba(239,68,68,0.5))", "drop-shadow(0 0 50px rgba(239,68,68,0.8))", "drop-shadow(0 0 20px rgba(239,68,68,0.5))"]
              }}
              transition={{ duration: 2, repeat: Infinity }}
              className="relative z-10 flex flex-col items-center"
            >
              <div className="relative flex items-center justify-center mb-8">
                <motion.div 
                  animate={{ rotate: 360 }} 
                  transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-[-40px] border border-red-500/30 rounded-full border-dashed"
                />
                <motion.div 
                  animate={{ rotate: -360 }} 
                  transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-[-20px] border border-red-500/50 rounded-full"
                />
                <div className="relative w-20 h-20 rounded-full overflow-hidden border-2 border-red-500/50 flex items-center justify-center">
                  <img 
                    src="https://i.imgur.com/KjaXBWH.png" 
                    alt="Ghozt" 
                    className="absolute inset-0 w-full h-full object-cover object-center opacity-50 mix-blend-luminosity"
                  />
                  <div className="absolute inset-0 bg-red-500/20" />
                  <Lock size={32} className="text-red-100 relative z-10 drop-shadow-[0_0_10px_rgba(239,68,68,1)]" />
                </div>
              </div>
              
              <h2 className="text-3xl md:text-5xl font-black text-red-500 tracking-widest uppercase mb-2 text-center" style={{ textShadow: "0 0 20px rgba(239,68,68,0.8)" }}>
                Security Lock
              </h2>
              <div className="flex items-center gap-2 mb-6">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                <p className="text-sm md:text-base text-red-400/80 uppercase tracking-[0.3em]">Privacy Shield Engaged</p>
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              </div>

              <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 max-w-sm text-center backdrop-blur-md">
                <p className="text-[10px] md:text-sm text-red-200/70 tracking-widest leading-relaxed">
                  DISPLAY CAPTURE ATTEMPT DETECTED OR APP IN BACKGROUND. CONTENTS HIDDEN TO PROTECT IDENTITY INTEGRITY.
                </p>
              </div>
            </motion.div>
            
            {/* Scanning Line */}
            <motion.div
              animate={{ top: ["-10%", "110%"] }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              className="absolute left-0 right-0 h-[2px] bg-red-500/50 blur-[2px] z-20 pointer-events-none shadow-[0_0_20px_rgba(239,68,68,1)]"
            />
          </motion.div>
        )}
      </AnimatePresence>

      <div className={cn(
        "flex flex-1 min-h-0 flex-col relative transition-all duration-500",
        isBlurry ? "blur-[50px] scale-105 pointer-events-none" : "blur-0 scale-100"
      )}>
        {/* Background Watermark Branding */}
        <motion.div 
          initial={{ opacity: 0.04 }}
          animate={{ opacity: [0.04, 0.12, 0.04] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none select-none z-0"
        >
          <h2 className="text-[16vw] font-black uppercase tracking-tighter text-white/10" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>GHOZT</h2>
          <p className="text-[2.2vw] font-black uppercase tracking-[0.5em] -mt-2 text-phantom-purple text-glow-purple">Chat without echoes</p>
          <p className="text-[1.1vw] font-mono mt-4 text-phantom-cyan/60 text-glow-cyan">v4.0.2 // SECURE_NODE</p>
        </motion.div>

        {/* Header */}
      <div className="flex justify-between items-center px-6 py-4 border-b border-white/5 bg-phantom-black/80 backdrop-blur-xl relative z-30">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-white/5 transition-colors">
            <ChevronLeft size={24} className="text-white/70 hover:text-white" />
          </button>
          
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10 border border-white/10 shadow-[0_0_15px_rgba(0,0,0,0.5)]">
              {conversationId === 'global' ? (
                <AvatarFallback className="bg-phantom-purple/20 text-phantom-purple"><Activity size={20} /></AvatarFallback>
              ) : recipient?.photoURL ? (
                <AvatarImage src={recipient.photoURL} />
              ) : (
                <AvatarFallback className="bg-phantom-black text-white font-medium uppercase">
                  {conversationId === 'global' ? 'G' : conversation?.name?.[0] || recipient?.displayName?.[0] || recipient?.email?.[0] || 'S'}
                </AvatarFallback>
              )}
            </Avatar>
            <div className="flex flex-col">
              <span className="text-[9px] font-bold text-white/40 uppercase tracking-[0.2em] mb-0.5">Chatting With</span>
              <h1 className="text-sm font-semibold text-white tracking-wide">
                {conversationId === 'global' ? 'Global Frequency' : conversation?.name || recipient?.displayName || recipient?.email || 'Ghost Session'}
              </h1>
              <div className="flex items-center gap-1.5 mt-0.5">
                 <div className="w-1.5 h-1.5 rounded-full bg-phantom-purple shadow-[0_0_8px_rgba(157,80,187,0.8)]" />
                 <span className="text-[10px] font-medium text-phantom-purple uppercase tracking-widest">Encrypted</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-1">
          <button
            title="Test Privacy Shield (Local Only)"
            className={`p-2 rounded-full transition-all text-red-500 hover:text-red-400 hover:bg-white/5`}
            onClick={() => setIsBlurry(!isBlurry)}
          >
            <Shield size={20} />
          </button>
          <button
            title="Observer Visibility"
            className={`p-2 rounded-full transition-all ${profile?.visibility === 'invisible' ? 'text-white/40 hover:text-white' : 'text-phantom-purple'}`}
            onClick={async () => {
              if (!user) return;
              try {
                const newVisibility = profile?.visibility === 'invisible' ? 'online' : 'invisible';
                await UserService.updateProfile(user.uid, { visibility: newVisibility });
                toast.success(newVisibility === 'invisible' ? 'You have slipped into the shadows' : 'You are now visible');
              } catch (e) {
                // error-handler.ts handleFirestoreError already called in UserService
              }
            }}
          >
            <Eye size={20} strokeWidth={1.5} />
          </button>
          
          <button
            title="Themes / Settings"
            className="p-2 rounded-full text-white/40 hover:text-white hover:bg-white/5 transition-all"
            onClick={onOpenProfile}
          >
            <Palette size={20} strokeWidth={1.5} />
          </button>

          <button
            title="Privacy Sounds"
            className={`p-2 rounded-full transition-all ${profile?.dndMode ? 'text-red-500 hover:text-red-400' : 'text-phantom-purple hover:text-purple-400'}`}
            onClick={async () => {
              if (!user) return;
              try {
                const newDnd = !profile?.dndMode;
                await UserService.updateProfile(user.uid, { dndMode: newDnd });
                toast.success(newDnd ? 'Do Not Disturb Activated' : 'Receiving shadow frequencies.');
              } catch (e) {
                // error-handler.ts handleFirestoreError already called in UserService
              }
            }}
          >
            {profile?.dndMode ? <BellOff size={20} strokeWidth={1.5} /> : <Bell size={20} strokeWidth={1.5} />}
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 min-h-0 flex flex-col relative bg-phantom-black">
        <div className="flex-1 p-6 overflow-y-auto overflow-x-hidden custom-scrollbar" ref={scrollRef}>
          <div className="flex flex-col min-h-full">
            <div className="flex items-center gap-4 my-8 px-6 mt-auto">
              <div className="h-[1px] flex-1 bg-white/[0.03]" />
              <span className="text-[10px] font-medium text-white/[0.1] uppercase tracking-[0.4em]">Secure Chat Initialized</span>
              <div className="h-[1px] flex-1 bg-white/[0.03]" />
            </div>

            {messages.length === 0 && (
              <div className="my-auto text-center py-12 flex flex-col items-center justify-center">
                <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-6 border border-white/5 shadow-[0_0_30px_rgba(0,229,255,0.05)]">
                  <Lock size={24} className="text-white/20" strokeWidth={1.5} />
                </div>
                <h3 className="text-sm font-medium text-white/50 tracking-wide mb-1">End-to-End Encrypted</h3>
                <p className="text-[11px] text-white/30 max-w-[200px] leading-relaxed">No logs. No traces. Messages expire upon reveal.</p>
              </div>
            )}

            <AnimatePresence initial={false}>
              {messages.map((msg) => (
                <MessageBubble key={msg.id} message={msg} conversationId={conversationId} />
              ))}
            </AnimatePresence>

            {/* Upgraded Typing Indicator in Chat Flow */}
            <AnimatePresence>
              {typingUsers.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9, y: 10, transformOrigin: 'bottom left' }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9, y: 10 }}
                  className="flex items-start gap-3 mt-6 mb-2 max-w-[85%]"
                >
                  <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center shrink-0 mt-2">
                    <Activity size={14} className="text-phantom-purple animate-pulse" />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <span className="text-[10px] text-phantom-purple/70 uppercase tracking-widest pl-1 font-semibold">
                      {formatTypingMessage(typingUsers)}
                    </span>
                    <div className="bg-phantom-black/80 border border-white/5 rounded-2xl rounded-tl-sm px-4 py-3.5 flex items-center gap-2 backdrop-blur-md self-start relative">
                      {/* Subdued animated glow for typing bubble */}
                      <div className="absolute inset-0 bg-phantom-purple/5 opacity-50 rounded-2xl rounded-tl-sm blur-md pointer-events-none" />
                      
                      {[0, 1, 2].map((i) => (
                        <motion.div
                          key={i}
                          animate={{ y: [0, -4, 0], opacity: [0.5, 1, 0.5] }}
                          transition={{
                            duration: 0.8,
                            repeat: Infinity,
                            delay: i * 0.15,
                            ease: "easeInOut"
                          }}
                          className="w-1.5 h-1.5 rounded-full bg-phantom-purple shadow-[0_0_8px_rgba(157,80,187,0.8)]"
                        />
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
        
        {/* Sleek Ad Banner Footer */}
        {!profile?.isPremium && (
          <div className="shrink-0 w-full bg-black border-t border-white/5 flex flex-col justify-center items-center h-[60px] relative overflow-hidden group">
             <div className="absolute inset-0 bg-gradient-to-r from-phantom-purple/5 via-phantom-purple/5 to-phantom-purple/5 opacity-50" />
             <div className="flex items-center gap-3 relative z-10">
               <div className="w-6 h-6 rounded-md bg-white/10 flex items-center justify-center text-white/50">
                 <Zap size={12} />
               </div>
               <div className="flex flex-col items-start leading-tight">
                 <span className="text-[10px] font-semibold text-white/70 uppercase tracking-wider">Upgrade to Premium</span>
                 <span className="text-[9px] text-white/40">Remove all ads & unlock themes</span>
               </div>
             </div>
             <button className="absolute right-4 px-3 py-1.5 rounded-md bg-white/10 text-[9px] font-bold text-white uppercase tracking-wider hover:bg-white/20 transition-all opacity-0 group-hover:opacity-100">
               Get Premium
             </button>
             <span className="absolute top-1 right-1 text-[7px] text-white/20 uppercase tracking-widest">Ad Placeholder</span>
          </div>
        )}
      </div>

      {/* Input Bar */}
      <div className="shrink-0 px-4 pt-3 pb-6 sm:pb-4 bg-black border-t border-white/5 relative z-50">
        <AnimatePresence>
          {previewUrl && (
            <motion.div 
              initial={{ opacity: 0, y: 10, height: 0 }}
              animate={{ opacity: 1, y: 0, height: 'auto' }}
              exit={{ opacity: 0, y: 10, height: 0 }}
              className="mb-3"
            >
              <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex flex-col gap-3 relative">
                <button 
                  onClick={cancelPendingMedia}
                  className="absolute top-2 right-2 p-1.5 rounded-full bg-black/50 text-white/50 hover:text-white hover:bg-black/80 transition-colors z-10"
                >
                  <X size={14} />
                </button>
                
                <div className="flex items-center gap-3">
                  {previewType === 'image' && previewUrl && (
                    <img src={previewUrl} alt="Preview" className="w-16 h-16 object-cover rounded-lg bg-black" />
                  )}
                  {previewType === 'video' && previewUrl && (
                    <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-black flex items-center justify-center">
                      <video src={previewUrl} className="w-full h-full object-cover opacity-60" muted playsInline />
                      <Play size={12} className="text-white absolute z-10" fill="currentColor" />
                    </div>
                  )}
                  {previewType === 'audio' && (
                    <div className="w-16 h-16 rounded-lg bg-phantom-purple/20 flex items-center justify-center">
                      <Music size={24} className="text-phantom-purple" />
                    </div>
                  )}
                  {previewType === 'pdf' && (
                    <div className="w-16 h-16 rounded-lg bg-red-500/20 flex items-center justify-center">
                      <FileText size={24} className="text-red-500" />
                    </div>
                  )}
                  {previewType === 'file' && (
                    <div className="w-16 h-16 rounded-lg bg-white/10 flex items-center justify-center">
                      <File size={24} className="text-white/50" />
                    </div>
                  )}
                  
                  <div className="flex flex-col flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                       <span className="text-sm font-medium text-white truncate w-full">{pendingFile?.name || 'Attachment'}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                       <span className="text-[10px] text-white/40 uppercase tracking-wider">
                         {pendingFile ? (pendingFile.size / 1024 / 1024).toFixed(2) : '0'} MB
                       </span>
                       <span className="text-[10px] text-white/20">•</span>
                       <span className="text-[10px] text-phantom-purple font-bold uppercase tracking-wider">Ready to send</span>
                    </div>
                  </div>
                  
                  <button 
                    onClick={sendPendingMedia}
                    disabled={isUploading}
                    className="h-10 px-4 rounded-lg bg-phantom-purple text-black font-semibold text-xs tracking-wide hover:bg-white transition-colors flex items-center justify-center shrink-0 disabled:opacity-50"
                  >
                    {isUploading ? 'Sending...' : 'Send'}
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>



        <div className="flex flex-col gap-2">
          {/* Top row: timers & privacy */}
          <div className="flex items-center justify-between px-1">
             <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                {([5, 10, 30, 60, 300] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setTimer(t as any)}
                    className={`px-3 py-1 rounded-md text-[10px] font-bold transition-all whitespace-nowrap ${
                      timer === t 
                      ? 'bg-phantom-purple/20 text-phantom-purple border border-phantom-purple/30' 
                      : 'bg-transparent text-white/40 hover:text-white/80 hover:bg-white/5'
                    }`}
                  >
                    {t === 300 ? '5M' : t === 60 ? '1M' : `${t}S`}
                  </button>
                ))}
             </div>
             
             <div className="flex items-center gap-2 text-white/30 shrink-0 ml-4 hidden sm:flex">
                <Shield size={12} strokeWidth={2} />
                <span className="text-[10px] font-medium uppercase tracking-wider">Privacy On</span>
             </div>
          </div>

          {/* Bottom row: Input area */}
          <div className="flex items-center gap-2 relative">
            {isRecordingAudio ? (
              <div className="flex-1 flex items-center justify-between bg-red-500/10 border border-red-500/20 rounded-full h-11 px-4 animate-pulse">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
                  <span className="text-xs font-bold text-red-500 uppercase tracking-widest">Recording Voice...</span>
                </div>
                <button 
                  onClick={stopAudioRecording}
                  className="px-4 py-1 rounded-full bg-red-500 text-white text-[10px] font-black uppercase tracking-widest hover:bg-red-600 transition-colors"
                >
                  Intercept & Send
                </button>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-1">
                  <button 
                    onClick={handleCameraCapture}
                    className="p-2.5 rounded-full text-white/50 hover:text-phantom-purple hover:bg-white/5 transition-colors shrink-0"
                  >
                    <Camera size={20} strokeWidth={2} />
                  </button>
                  <button 
                    onClick={() => {
                      if (fileInputRef.current) {
                        fileInputRef.current.click();
                      }
                    }}
                    className="p-2.5 rounded-full text-white/50 hover:text-phantom-purple hover:bg-white/5 transition-colors shrink-0 -ml-1 h-10 w-10 flex items-center justify-center"
                  >
                    <Paperclip size={18} strokeWidth={2} />
                  </button>
                </div>
                
                <input 
                  type="file" 
                  ref={fileInputRef}
                  className="hidden" 
                  onChange={handleFileUpload}
                />
                
                <input 
                  type="file" 
                  accept="image/*"
                  capture="environment"
                  ref={cameraInputRef}
                  className="hidden" 
                  onChange={handleCameraInputChange}
                />
                
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => {
                      setInputValue(e.target.value);
                      handleTyping();
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSend();
                      }
                    }}
                    placeholder={`Transmit to ${conversationId === 'global' ? 'Global Frequency' : conversation?.name || recipient?.displayName || recipient?.email?.split('@')[0] || 'Shadow'}...`}
                    className="w-full h-11 bg-white/5 border border-white/10 rounded-full pl-5 pr-12 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-phantom-purple/50 focus:bg-white/10 transition-all font-medium backdrop-blur-md"
                  />
                </div>

                <div className="flex items-center gap-2">
                  {!inputValue.trim() ? (
                    <button 
                      onClick={startAudioRecording}
                      className="w-11 h-11 rounded-full bg-white/5 text-white/50 flex items-center justify-center hover:bg-phantom-purple hover:text-black transition-all border border-white/10 shrink-0"
                    >
                      <Mic size={20} strokeWidth={2} />
                    </button>
                  ) : (
                    <button 
                      onClick={handleSend}
                      className="w-11 h-11 rounded-full bg-phantom-purple text-black flex items-center justify-center hover:bg-white transition-all shadow-[0_0_15px_rgba(0,229,255,0.3)] shrink-0"
                    >
                      <Send size={18} strokeWidth={2.5} className="-ml-0.5" />
                    </button>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
      </div>
    </div>
  );
};

const GhostIcon = ({ size = 24, className = "" }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M9 10h.01M15 10h.01M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z" />
  </svg>
);

