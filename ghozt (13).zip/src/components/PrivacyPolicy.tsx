import React from 'react';
import { motion } from 'motion/react';
import { ChevronLeft } from 'lucide-react';

export const PrivacyPolicy: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  return (
    <div className="min-h-screen bg-phantom-deep text-white font-sans p-6 md:p-12 overflow-y-auto">
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-white/50 hover:text-white transition-colors group mb-8"
      >
        <ChevronLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
        <span className="text-sm font-medium tracking-wider uppercase">Return</span>
      </button>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-3xl mx-auto bg-white/[0.02] border border-white/5 p-8 md:p-12 rounded-3xl"
      >
        <h1 className="text-3xl md:text-5xl font-bold uppercase tracking-tight mb-8" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
          Privacy Protocol
        </h1>

        <div className="space-y-6 text-white/70 font-light leading-relaxed">
          <section>
            <h2 className="text-xl text-white font-bold mb-3 underline decoration-phantom-purple">1. Zero-Trust Architecture</h2>
            <p>At GHOZT, we believe your data is yours. Our platform is built on a zero-trust architecture, meaning we cannot access, read, or decrypt your messages. Once a message expires, it is permanently scrubbed from our servers.</p>
          </section>
          
          <section>
            <h2 className="text-xl text-white font-bold mb-3 underline decoration-phantom-purple">2. Ephemeral Data Storage</h2>
            <p>All communications transmitted through the Phantom Network are temporary. Timers are strictly enforced. Upon expiration, the payload is destroyed and the cryptographic keys are discarded. We maintain no historical logs of your conversations.</p>
          </section>
          
          <section>
            <h2 className="text-xl text-white font-bold mb-3 underline decoration-phantom-purple">3. Screenshot Deterrents & Privacy Screen</h2>
            <p>We employ advanced APIs to prevent screenshots and screen recording. If a breach of the privacy screen is detected, connection may be terminated and the offending party's Trust Score will reflect the violation. We do not store screenshots; we simply block them locally.</p>
          </section>

          <section>
            <h2 className="text-xl text-white font-bold mb-3 underline decoration-phantom-purple">4. Analytics & Monetization</h2>
            <p>For non-premium users, generic ad banners are provided by AdMob. We do not sell your personal identifiers to third-party brokers. Upgrading to Premium via Stripe removes all advertising modules and disconnects you from ad-based telemetry.</p>
          </section>

          <section>
            <h2 className="text-xl text-white font-bold mb-3 underline decoration-phantom-purple">5. Contact Information</h2>
            <p>If you have questions about our privacy practices, you can initiate contact through our secure channels or email privacy@ghozt.app.</p>
          </section>
        </div>
      </motion.div>
    </div>
  );
};
