import { PrivacyScreen } from '@capacitor-community/privacy-screen';
import { Capacitor } from '@capacitor/core';
import { UserService } from './UserService';
import { toast } from 'sonner';

export class PrivacyService {
  private static isInitialized = false;

  static async initialize() {
    if (this.isInitialized) return;

    if (Capacitor.isNativePlatform()) {
      try {
        await PrivacyScreen.enable();
        console.log('Privacy Screen enabled on native platform');
      } catch (error) {
        console.error('Failed to enable Privacy Screen:', error);
      }
    } else {
      // Web fallback: Detect visibility changes
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') {
          console.log('App backgrounded on web');
        }
      });

      // Attempt to detect PrintScreen (limited effectiveness)
      window.addEventListener('keydown', (e) => {
        if (e.key === 'PrintScreen') {
          this.handleScreenshotAttempt();
          // We can't really block it, but we can notify
        }
      });
    }

    this.isInitialized = true;
  }

  static async handleScreenshotAttempt() {
    toast.error('SCREENSHOT DETECTED: Trust Score Penalized', {
      description: 'Your identity integrity has been compromised.',
    });
    
    await UserService.penalizeTrustScore(15);
    
    // In a real app with Socket.io or Firestore, 
    // we would emit an event to the current chat room here.
  }

  static async enable() {
    if (Capacitor.isNativePlatform()) {
      await PrivacyScreen.enable();
    }
  }

  static async disable() {
    if (Capacitor.isNativePlatform()) {
      await PrivacyScreen.disable();
    }
  }
}
