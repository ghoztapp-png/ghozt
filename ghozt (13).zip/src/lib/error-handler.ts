import { auth } from './firebase';
import { toast } from 'sonner';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
  AUTH = 'auth'
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

type ErrorListener = (error: FirestoreErrorInfo) => void;
const listeners = new Set<ErrorListener>();

export const errorBus = {
  subscribe: (listener: ErrorListener) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },
  emit: (error: FirestoreErrorInfo) => {
    listeners.forEach(l => l(error));
  }
};

export function getFriendlyErrorMessage(error: string): { title: string, description: string } {
  const err = error.toLowerCase();
  
  if (err.includes('insufficient permissions') || err.includes('permission-denied')) {
    return { title: "Protocol Breach", description: "The grid has rejected your authentication key." };
  }
  if (err.includes('no document to update') || err.includes('not-found')) {
    return { title: "Node Vanished", description: "The target frequency is no longer active." };
  }
  if (err.includes('unavailable') || err.includes('could not reach')) {
    return { title: "Signal Lost", description: "Cannot connect to the shadow network." };
  }
  if (err.includes('quota exceeded')) {
    return { title: "Network Saturated", description: "Daily bandwidth limit reached. Protocol offline." };
  }
  if (err.includes('timeout')) {
    return { title: "Signal Timeout", description: "The transmission took too long to complete." };
  }
  if (err.includes('not authenticated')) {
    return { title: "Unauthorized", description: "Identity verification required to continue." };
  }
  
  return { title: "Transmission Error", description: "An unexpected glitch occurred in the matrix." };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMessage = error instanceof Error ? error.message : String(error);
  
  const errInfo: FirestoreErrorInfo = {
    error: errMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  };

  console.error('[GHOZT ERROR]', operationType.toUpperCase(), 'at', path, ':', errMessage);
  
  // Emit to listeners (Context)
  errorBus.emit(errInfo);

  // Directly show toast if we are in a context where no ErrorProvider is active
  // but usually we'll have one. To avoid double toasts, the Context will manage this.
  // For now, let's keep the throw so services can re-throw.
  
  throw new Error(JSON.stringify(errInfo));
}
