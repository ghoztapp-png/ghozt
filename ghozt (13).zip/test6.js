fetch('http://localhost:3000/api/upload', { 
  method: 'GET'
}).then(r => r.text().then(t => console.log(r.status, t.substring(0, 150))));
