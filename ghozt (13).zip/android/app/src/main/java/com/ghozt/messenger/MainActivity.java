package com.ghozt.messenger;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
