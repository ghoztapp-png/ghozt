import { User as FirebaseUser } from "firebase/auth";

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

export interface UserProfile {
  uid: string;
  displayName: string;
  photoURL?: string;
  phoneNumber?: string;
  isPremium?: boolean;
  theme?: string;
  lastScreenshotAttempt?: number;
  screenshotCount?: number;
  trustScore?: number;
  isOnline?: boolean;
  isInvisible?: boolean;
  lastSeen?: number;
  createdAt?: any;
  role?: string;
  isMuted?: boolean;
  notificationSettings?: NotificationSettings;
  directMessages?: string[];
}

export interface NotificationSettings {
  global: boolean;
  globalChat: boolean;
  groups: boolean;
  directMessages: boolean;
  mutedGroups: string[];
  mutedContacts: string[];
}

export interface Message {
  id: string;
  text?: string;
  imageUrl?: string;
  fileUrl?: string;
  fileName?: string;
  fileType?: string;
  senderId: string;
  senderName: string;
  timestamp: number;
  duration: number;
  openedAt?: number;
  expiresAt: number;
  roomId: string;
  reactions?: { [emoji: string]: string[] };
}

export interface Group {
  id: string;
  name: string;
  createdBy: string;
  createdAt: number;
  members: string[];
}

export interface MessageBubbleProps {
  message: Message;
  onExpire: (id: string) => void;
  isChatBlurred: boolean;
}

export interface ErrorBoundaryProps {
  children: React.ReactNode;
}

export interface ErrorBoundaryState {
  hasError: boolean;
  errorInfo: string | null;
}
