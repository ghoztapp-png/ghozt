import { Message, UserProfile, Group } from "./types";

export const FAKE_USER_PROFILE: UserProfile = {
  uid: "Ghozt-dev",
  displayName: "Ghozt Admin",
  photoURL: "https://picsum.photos/seed/Ghozt/200/200",
  isOnline: true,
  lastSeen: Date.now(),
  createdAt: new Date(),
  isPremium: true,
  trustScore: 99,
  notificationSettings: {
    global: true,
    globalChat: true,
    groups: true,
    directMessages: true,
    mutedGroups: [],
    mutedContacts: []
  }
};

export const FAKE_CONTACTS: UserProfile[] = [
  {
    uid: "user-1",
    displayName: "Phantom",
    photoURL: "https://picsum.photos/seed/phantom/200/200",
    isOnline: true,
    lastSeen: Date.now(),
    createdAt: new Date(),
    isPremium: true
  },
  {
    uid: "user-2",
    displayName: "Spectre",
    photoURL: "https://picsum.photos/seed/spectre/200/200",
    isOnline: true,
    lastSeen: Date.now(),
    createdAt: new Date()
  },
  {
    uid: "user-3",
    displayName: "Echo",
    photoURL: "https://picsum.photos/seed/echo/200/200",
    isOnline: false,
    lastSeen: Date.now() - 3600000,
    createdAt: new Date()
  },
  {
    uid: "user-4",
    displayName: "Wraith",
    photoURL: "https://picsum.photos/seed/wraith/200/200",
    isOnline: true,
    lastSeen: Date.now(),
    createdAt: new Date(),
    isPremium: true
  }
];

export const FAKE_GROUPS: Group[] = [
  {
    id: "group-1",
    name: "The Void",
    createdBy: "Ghozt-dev",
    createdAt: Date.now(),
    members: ["Ghozt-dev", "user-1", "user-2", "user-3"]
  },
  {
    id: "group-2",
    name: "Ghost Protocol",
    createdBy: "user-1",
    createdAt: Date.now(),
    members: ["Ghozt-dev", "user-1", "user-4"]
  },
  {
    id: "group-3",
    name: "Shadow Network",
    createdBy: "user-2",
    createdAt: Date.now(),
    members: ["Ghozt-dev", "user-2"]
  }
];

export const FAKE_MESSAGES: Message[] = [
  {
    id: "msg-1",
    text: "Welcome to the Phantom Network. Your connection is now fully encrypted.",
    senderId: "system",
    senderName: "System",
    timestamp: Date.now() - 10000,
    duration: 60,
    expiresAt: Date.now() + 3600000,
    roomId: "global-chat"
  },
  {
    id: "msg-2",
    text: "Did you see the new Solar theme? It looks amazing on OLED screens.",
    senderId: "user-1",
    senderName: "Phantom",
    timestamp: Date.now() - 8000,
    duration: 60,
    expiresAt: Date.now() + 3600000,
    roomId: "global-chat"
  },
  {
    id: "msg-3",
    text: "I've enabled screenshot protection. No one can leak our protocol details.",
    senderId: "user-4",
    senderName: "Wraith",
    timestamp: Date.now() - 5000,
    duration: 60,
    expiresAt: Date.now() + 3600000,
    roomId: "global-chat"
  },
  {
    id: "msg-4",
    text: "Check out this encrypted asset I just uploaded.",
    senderId: "Ghozt-dev",
    senderName: "Ghozt Admin",
    timestamp: Date.now() - 2000,
    duration: 60,
    expiresAt: Date.now() + 3600000,
    roomId: "global-chat",
    imageUrl: "https://picsum.photos/seed/Ghozt-asset/800/600"
  }
];
