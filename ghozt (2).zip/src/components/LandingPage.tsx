import * as React from "react";
import { motion } from "motion/react";
import { 
  Shield, 
  Zap, 
  EyeOff, 
  Smartphone, 
  ArrowRight, 
  Lock,
  Clock,
  MessageSquare
} from "lucide-react";
import { cn } from "../lib/utils";

interface LandingPageProps {
  onLaunch: () => void;
}

export const LandingPage = ({ onLaunch }: LandingPageProps) => {
  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans selection:bg-Ghozt-cyan selection:text-black overflow-x-hidden relative">
      {/* Immersive Atmospheric Background (Recipe 7) */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#1a1a1a_0%,#050505_100%)]" />
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.2, 0.1],
            x: [-50, 50, -50],
            y: [-50, 50, -50]
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-Ghozt-cyan/10 rounded-full blur-[120px]" 
        />
        <motion.div 
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.05, 0.15, 0.05],
            x: [50, -50, 50],
            y: [50, -50, 50]
          }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-Ghozt-purple/10 rounded-full blur-[120px]" 
        />
      </div>

      {/* Massive Editorial Background Typography (Recipe 2) */}
      <div className="fixed inset-0 flex items-center justify-center pointer-events-none overflow-hidden select-none z-0 opacity-[0.03]">
        <div className="flex flex-col items-center">
          <motion.h1
            initial={{ scale: 1.1, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 2, ease: [0.16, 1, 0.3, 1] }}
            className="text-[40vw] font-black text-white uppercase leading-[0.8] tracking-tighter"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            GHOZT
          </motion.h1>
          <motion.span 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.5, delay: 1, ease: "easeOut" }}
            className="text-2xl font-display italic text-white tracking-[0.5em] mt-[-2vw]"
          >
            THE PHANTOM NETWORK
          </motion.span>
        </div>
      </div>

      {/* Vertical Rail Text (Recipe 11) */}
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 1, delay: 2.8 }}
        className="fixed left-6 md:left-12 top-1/2 -translate-y-1/2 hidden lg:flex flex-col items-center gap-12 pointer-events-none select-none z-10"
      >
        <span className="writing-mode-vertical-rl rotate-180 text-[10px] font-mono tracking-[0.5em] text-white/20 uppercase">
          Privacy First Protocol
        </span>
        <div className="w-[1px] h-24 bg-gradient-to-b from-transparent via-white/20 to-transparent" />
        <span className="writing-mode-vertical-rl rotate-180 text-[10px] font-mono tracking-[0.5em] text-white/20 uppercase">
          v4.0.2 // 2026
        </span>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 1, delay: 3 }}
        className="fixed right-6 md:right-12 top-1/2 -translate-y-1/2 hidden lg:flex flex-col items-center gap-12 pointer-events-none select-none z-10"
      >
        <span className="writing-mode-vertical-rl text-[10px] font-mono tracking-[0.5em] text-white/20 uppercase">
          Encrypted End-to-End
        </span>
        <div className="w-[1px] h-24 bg-gradient-to-b from-transparent via-white/20 to-transparent" />
        <span className="writing-mode-vertical-rl text-[10px] font-mono tracking-[0.5em] text-white/20 uppercase">
          Ephemeral Messaging
        </span>
      </motion.div>

      {/* Navigation */}
      <motion.nav 
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, delay: 2.2, ease: [0.16, 1, 0.3, 1] }}
        className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-6 md:px-12 backdrop-blur-md bg-black/20 border-b border-white/5"
      >
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 2.4 }}
          className="flex items-center gap-2"
        >
          <div className="w-8 h-8 bg-Ghozt-cyan rounded-lg flex items-center justify-center glow-cyan overflow-hidden">
            <img src="/logo.jpg" alt="Ghozt" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
          <span className="text-xl font-black tracking-tighter uppercase">Ghozt</span>
        </motion.div>
        <motion.button 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 2.6 }}
          onClick={onLaunch}
          className="px-6 py-2 bg-white text-black text-xs font-black uppercase tracking-widest rounded-full hover:bg-Ghozt-cyan transition-all active:scale-95"
        >
          Launch App
        </motion.button>
      </motion.nav>

      {/* Hero Section - Split Layout (Recipe 11) */}
      <main className="grid lg:grid-cols-2 min-h-screen pt-24 relative z-10">
        <div className="flex flex-col justify-center px-6 md:px-12 py-12 lg:py-0">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-Ghozt-cyan/10 border border-Ghozt-cyan/20 text-Ghozt-cyan text-[10px] font-bold uppercase tracking-widest mb-6">
              <Zap size={12} />
              <span>The Future of Private Chat</span>
            </div>
            <h1 className="text-6xl md:text-8xl lg:text-[112px] font-black leading-[0.88] tracking-tighter mb-8 uppercase">
              <motion.span 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.8 }}
                className="block"
              >
                Chat like a
              </motion.span>
              <motion.span 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 1 }}
                className="text-Ghozt-cyan text-glow-cyan block"
              >
                Ghozt.
              </motion.span>
            </h1>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 1.2 }}
              className="text-lg md:text-xl text-white/60 max-w-md mb-10 leading-relaxed font-medium"
            >
              Ephemeral messaging for the privacy-obsessed. Your words vanish, your identity stays shielded, and your screen remains yours alone.
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1.4 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <button 
                onClick={onLaunch}
                className="group flex items-center justify-center gap-3 px-8 py-5 bg-Ghozt-cyan text-black font-black uppercase tracking-[0.2em] rounded-2xl glow-cyan hover:scale-[1.02] active:scale-95 transition-all"
              >
                Start Chatting
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </button>
              <div className="flex items-center gap-4 px-6 py-4 rounded-2xl border border-white/10 bg-white/5">
                <div className="flex -space-x-2">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="w-8 h-8 rounded-full border-2 border-black bg-zinc-800 flex items-center justify-center overflow-hidden">
                      <img src={`https://picsum.photos/seed/user${i}/100/100`} alt="" referrerPolicy="no-referrer" />
                    </div>
                  ))}
                </div>
                <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">
                  Join 10k+ <br /> Privacy Seekers
                </p>
              </div>
            </motion.div>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1.2, delay: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="relative flex items-center justify-center bg-Ghozt-purple/5 border-l border-white/5 overflow-hidden"
        >
          {/* Floating Feature Cards */}
          <div className="relative z-10 w-full max-w-md p-6 space-y-6">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, rotate: -10 }}
              animate={{ opacity: 1, scale: 1, rotate: -2 }}
              transition={{ duration: 1, delay: 1.6, ease: [0.16, 1, 0.3, 1] }}
              className="glass p-6 rounded-3xl border-Ghozt-cyan/20 glow-cyan/5 transform -rotate-2"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-Ghozt-cyan/10 rounded-2xl flex items-center justify-center border border-Ghozt-cyan/20">
                  <Clock size={24} className="text-Ghozt-cyan" />
                </div>
                <div>
                  <h3 className="font-black uppercase tracking-tighter">Ephemeral</h3>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">Self-Destructing</p>
                </div>
              </div>
              <p className="text-sm text-white/60 leading-relaxed">
                Every message has a heartbeat. Once the timer hits zero, it's purged from existence. No logs, no traces.
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9, rotate: 10 }}
              animate={{ opacity: 1, scale: 1, rotate: 3 }}
              transition={{ duration: 1, delay: 1.8, ease: [0.16, 1, 0.3, 1] }}
              className="glass p-6 rounded-3xl border-Ghozt-pink/20 glow-pink/5 transform rotate-3"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-Ghozt-pink/10 rounded-2xl flex items-center justify-center border border-Ghozt-pink/20">
                  <EyeOff size={24} className="text-Ghozt-pink" />
                </div>
                <div>
                  <h3 className="font-black uppercase tracking-tighter">Stealth Mode</h3>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">Privacy Cloak</p>
                </div>
              </div>
              <p className="text-sm text-white/60 leading-relaxed">
                Blur your chat feed instantly. Peek at messages with a single tap. Perfect for commuting or public spaces.
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9, rotate: -5 }}
              animate={{ opacity: 1, scale: 1, rotate: -1 }}
              transition={{ duration: 1, delay: 2, ease: [0.16, 1, 0.3, 1] }}
              className="glass p-6 rounded-3xl border-Ghozt-purple/20 glow-purple/5 transform -rotate-1"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-Ghozt-purple/10 rounded-2xl flex items-center justify-center border border-Ghozt-purple/20">
                  <Shield size={24} className="text-Ghozt-purple" />
                </div>
                <div>
                  <h3 className="font-black uppercase tracking-tighter">Privacy Shield</h3>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">Native Protection</p>
                </div>
              </div>
              <p className="text-sm text-white/60 leading-relaxed">
                Native protection against screenshots and task-switcher peeking. Your content stays inside the app.
              </p>
            </motion.div>
          </div>
        </motion.div>
      </main>

      {/* Features Grid (Recipe 1) */}
      <section className="py-24 px-6 md:px-12 bg-[#080808] border-t border-white/5">
        <div className="max-w-7xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="mb-16"
          >
            <h2 className="text-4xl md:text-6xl font-black uppercase tracking-tighter mb-4">Engineered for <span className="text-Ghozt-pink text-glow-pink">Anonymity.</span></h2>
            <div className="h-px w-full bg-white/5" />
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
            {[
              { id: "01", label: "PERSISTENCE", title: "Zero-Trace Logic", desc: "Messages are purged from existence the moment they expire. No logs, no traces, and no recovery. Your data dies when you say it does.", color: "text-Ghozt-cyan" },
              { id: "02", label: "PRIVACY", title: "Stealth Mode", desc: "Instantly blur your entire feed with one tap. Peek at messages privately, keeping your conversations safe from prying eyes in public.", color: "text-Ghozt-pink" },
              { id: "03", label: "PROTECTION", title: "Native Shield", desc: "Built-in protection against screenshots and task-switcher peeking. Your content stays inside the app, protected by native OS hooks.", color: "text-Ghozt-purple" },
              { id: "04", label: "INFRASTRUCTURE", title: "RBAC Security", desc: "Strict Role-Based Access Control and 'Default Deny' policies ensure your data is only accessible to authorized participants.", color: "text-Ghozt-cyan" }
            ].map((feature, i) => (
              <motion.div 
                key={feature.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: i * 0.1 }}
                className="space-y-4 group"
              >
                <div className={`${feature.color} font-mono text-[10px] tracking-[0.2em]`}>{feature.id} // {feature.label}</div>
                <h3 className={`text-xl font-bold uppercase tracking-tighter group-hover:${feature.color} transition-colors`}>{feature.title}</h3>
                <p className="text-sm text-white/40 leading-relaxed">
                  {feature.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 px-6 text-center relative overflow-hidden">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="relative z-10"
        >
          <h2 className="text-5xl md:text-7xl font-black uppercase tracking-tighter mb-8">Ready to go <span className="italic serif text-Ghozt-cyan">Dark?</span></h2>
          <button 
            onClick={onLaunch}
            className="px-12 py-6 bg-white text-black font-black uppercase tracking-[0.3em] rounded-2xl hover:bg-Ghozt-cyan transition-all glow-cyan/50"
          >
            Enter the Void
          </button>
        </motion.div>
      </section>

      {/* Footer */}
      <motion.footer 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="py-12 px-6 md:px-12 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-8"
      >
        <div className="flex items-center gap-2 opacity-50">
          <img src="/logo.jpg" alt="Ghozt" className="w-4 h-4 rounded-sm object-cover" referrerPolicy="no-referrer" />
          <span className="text-xs font-bold uppercase tracking-widest">Ghozt © 2026</span>
        </div>
        <div className="flex gap-8">
          <a href="#" className="text-[10px] font-bold uppercase tracking-widest text-white/40 hover:text-Ghozt-cyan transition-colors">Privacy Policy</a>
          <a href="#" className="text-[10px] font-bold uppercase tracking-widest text-white/40 hover:text-Ghozt-cyan transition-colors">Terms of Service</a>
          <a href="#" className="text-[10px] font-bold uppercase tracking-widest text-white/40 hover:text-Ghozt-cyan transition-colors">Security Audit</a>
        </div>
      </motion.footer>

      <style dangerouslySetInnerHTML={{ __html: `
        .text-glow-cyan {
          text-shadow: 0 0 20px rgba(0, 229, 255, 0.5);
        }
        .text-glow-pink {
          text-shadow: 0 0 20px rgba(255, 51, 102, 0.5);
        }
        .serif {
          font-family: 'Georgia', serif;
        }
        .writing-mode-vertical-rl {
          writing-mode: vertical-rl;
        }
      `}} />
    </div>
  );
};
