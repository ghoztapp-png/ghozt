package com.ghozt.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
