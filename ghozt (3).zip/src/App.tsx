import React, { useState, useEffect, useRef, Component, ReactNode } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Toaster, toast } from "sonner";
import { 
  Trash2,
  Send, 
  Clock, 
  Shield, 
  ShieldCheck,
  ShieldAlert,
  LogOut, 
  User, 
  MessageSquare, 
  Plus,
  Eye,
  EyeOff,
  AlertCircle,
  LogIn,
  Smartphone,
  Check,
  Ghost,
  UserPlus,
  X,
  Camera as CameraIcon,
  Image as ImageIcon,
  FileText,
  Download,
  Paperclip,
  Bell,
  BellOff,
  Palette,
  Zap,
  Moon,
  Cloud,
  Sun,
  Monitor,
  UserX,
  ExternalLink,
  HelpCircle
} from "lucide-react";
import { cn } from "./lib/utils";
import { auth, db, testConnection } from "./firebase";
import { App as CapApp } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { PrivacyScreen } from '@capacitor-community/privacy-screen';
import { AdMob, BannerAdPosition, BannerAdSize } from '@capacitor-community/admob';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut, 
  onAuthStateChanged,
  User as FirebaseUser,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  ConfirmationResult,
  deleteUser
} from "firebase/auth";
import { 
  collection, 
  addDoc, 
  query, 
  orderBy, 
  onSnapshot, 
  limit, 
  Timestamp, 
  serverTimestamp,
  where,
  deleteDoc,
  doc,
  setDoc,
  getDoc,
  getDocs,
  increment
} from "firebase/firestore";
import { FAKE_USER_PROFILE, FAKE_CONTACTS, FAKE_GROUPS, FAKE_MESSAGES } from "./screenshotData";

// --- Components ---

const SplashScreen = ({ onFinish }: { onFinish: () => void }) => {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1.5, ease: "easeInOut" }}
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#050505] overflow-hidden"
    >
      {/* Immersive Atmospheric Background (Recipe 7) */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#1a1a1a_0%,#050505_100%)]" />
        <motion.div 
          animate={{ 
            scale: [1, 1.5, 1],
            opacity: [0.1, 0.3, 0.1],
            x: [-100, 100, -100],
            y: [-100, 100, -100]
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute top-[-20%] left-[-20%] w-[80%] h-[80%] bg-Ghozt-cyan/20 rounded-full blur-[160px]" 
        />
        <motion.div 
          animate={{ 
            scale: [1.5, 1, 1.5],
            opacity: [0.1, 0.2, 0.1],
            x: [100, -100, 100],
            y: [100, -100, 100]
          }}
          transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-[-20%] right-[-20%] w-[80%] h-[80%] bg-Ghozt-purple/15 rounded-full blur-[160px]" 
        />
      </div>

      {/* Split Layout Elements (Recipe 11) */}
      <div className="absolute inset-0 flex pointer-events-none">
        <div className="w-1/2 h-full border-r border-white/5" />
        <div className="w-1/2 h-full" />
      </div>

      {/* Vertical Rail Text */}
      <div className="absolute left-6 md:left-12 top-1/2 -translate-y-1/2 hidden sm:flex flex-col items-center gap-12 pointer-events-none select-none">
        <span className="writing-mode-vertical-rl rotate-180 text-[8px] md:text-[10px] font-mono tracking-[0.5em] text-white/20 uppercase">
          Established 2026
        </span>
        <div className="w-[1px] h-16 md:h-24 bg-gradient-to-b from-transparent via-white/20 to-transparent" />
        <span className="writing-mode-vertical-rl rotate-180 text-[8px] md:text-[10px] font-mono tracking-[0.5em] text-white/20 uppercase">
          Protocol v4.0.2
        </span>
      </div>

      {/* Massive Editorial Background Typography (Recipe 2) */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden select-none">
        <motion.div
          initial={{ scale: 1.2, opacity: 0, letterSpacing: "0.5em" }}
          animate={{ scale: 1, opacity: 0.05, letterSpacing: "-0.02em" }}
          transition={{ duration: 4, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col items-center"
        >
          <h1 className="text-[45vw] md:text-[35vw] font-black text-white uppercase leading-[0.8] tracking-tighter" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            GHOZT
          </h1>
          <span className="text-lg md:text-2xl font-display italic text-white/40 tracking-widest mt-[-2vw]">
            The Phantom Network
          </span>
        </motion.div>
      </div>

      {/* Central Hero Content */}
      <motion.div
        initial={{ opacity: 0, y: 60 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ 
          duration: 2.5, 
          ease: [0.16, 1, 0.3, 1],
          delay: 0.8
        }}
        className="relative z-10 flex flex-col items-center"
      >
        <div className="relative mb-8 md:mb-16 group">
          <motion.div
            animate={{ 
              y: [0, -10, 0],
              filter: [
                "drop-shadow(0 0 20px rgba(0,229,255,0.3))",
                "drop-shadow(0 0 40px rgba(0,229,255,0.6))",
                "drop-shadow(0 0 20px rgba(0,229,255,0.3))"
              ]
            }}
            transition={{ 
              duration: 5, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
            className="relative z-20"
          >
            <img 
              src="/logo.jpg" 
              alt="Ghozt Logo" 
              className="w-32 h-32 md:w-48 md:h-48 object-contain rounded-full"
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.target as HTMLImageElement).src = "/icon.svg";
              }}
            />
          </motion.div>
          
          {/* Decorative Rings */}
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute inset-[-20px] border border-white/5 rounded-full"
          />
          <motion.div 
            animate={{ rotate: -360 }}
            transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
            className="absolute inset-[-40px] border border-white/5 rounded-full border-dashed"
          />
        </div>

        <div className="flex flex-col items-center gap-6 md:gap-8">
          <div className="flex flex-col items-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.5, duration: 2, ease: [0.16, 1, 0.3, 1] }}
              className="relative"
            >
              <h2 
                className="text-5xl md:text-8xl font-black text-white uppercase tracking-[-0.05em] leading-none text-glow-cyan"
                style={{ fontFamily: "'Space Grotesk', sans-serif" }}
              >
                GHOZT
              </h2>
              <motion.div
                initial={{ scaleX: 0, opacity: 0 }}
                animate={{ scaleX: 1, opacity: 1 }}
                transition={{ delay: 2.2, duration: 1.5, ease: "easeOut" }}
                className="absolute -bottom-2 md:-bottom-4 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-Ghozt-cyan/50 to-transparent origin-center"
              />
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 2.8, duration: 1.5 }}
              className="flex items-center gap-4 md:gap-6 mt-6 md:mt-10"
            >
              <div className="w-8 md:w-12 h-[1px] bg-white/10" />
              <p className="text-[10px] md:text-sm font-display italic text-Ghozt-purple tracking-[0.3em] md:tracking-[0.5em] uppercase text-center text-glow-purple">
                Chat without echoes
              </p>
              <div className="w-8 md:w-12 h-[1px] bg-white/10" />
            </motion.div>
          </div>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 3.5, duration: 1.5 }}
            className="flex flex-col items-center gap-4 md:gap-6 mt-4 md:mt-8"
          >
            <div className="flex items-center gap-6 md:gap-10 text-[8px] md:text-[10px] font-mono uppercase tracking-[0.3em] md:tracking-[0.5em] text-white/20">
              <span className="hover:text-Ghozt-cyan transition-colors duration-500 cursor-default">Encrypted</span>
              <div className="w-1 h-1 bg-white/10 rounded-full" />
              <span className="hover:text-Ghozt-cyan transition-colors duration-500 cursor-default">Ephemeral</span>
              <div className="w-1 h-1 bg-white/10 rounded-full" />
              <span className="hover:text-Ghozt-cyan transition-colors duration-500 cursor-default">Secure</span>
            </div>
          </motion.div>
        </div>
      </motion.div>

      {/* Technical Metadata Footer (Recipe 1) */}
      <div className="absolute bottom-8 md:bottom-16 left-8 md:left-16 right-8 md:right-16 flex flex-col md:flex-row justify-between items-center md:items-end gap-4 md:gap-0 pointer-events-none">
        <div className="flex flex-col items-center md:items-start gap-2">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 bg-Ghozt-cyan rounded-full animate-pulse shadow-[0_0_10px_rgba(0,229,255,0.5)]" />
            <span className="text-[10px] md:text-[11px] font-mono text-white/60 uppercase tracking-[0.2em]">System Active</span>
          </div>
          <span className="text-[8px] md:text-[9px] font-mono text-white/20 uppercase tracking-[0.3em]">Node: US-EAST-01</span>
        </div>
        
        <div className="flex flex-col items-center md:items-end gap-2">
          <span className="text-[10px] md:text-[11px] font-display italic text-white/40 tracking-widest">Phantom Encryption v4.0</span>
          <div className="flex gap-4">
            <span className="text-[8px] md:text-[9px] font-mono text-white/20 uppercase tracking-[0.3em]">Lat: 40.7128° N</span>
            <span className="text-[8px] md:text-[9px] font-mono text-white/20 uppercase tracking-[0.3em]">Lon: 74.0060° W</span>
          </div>
        </div>
      </div>

      {/* Scanning Line */}
      <motion.div
        animate={{ top: ["-10%", "110%"] }}
        transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
        className="absolute left-0 right-0 h-[1px] bg-Ghozt-cyan/20 blur-[2px] z-20 pointer-events-none"
      />

      {/* Progress Trigger */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        onAnimationComplete={() => {
          setTimeout(onFinish, 5000);
        }}
      />
    </motion.div>
  );
};

// --- Types ---

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  
  // If it's a permission error and we don't have a user, it's likely a race condition during logout/login
  if (errInfo.error.includes('insufficient permissions') && !auth.currentUser) {
    console.warn(`Firestore permission denied for ${path} during unauthenticated state. Ignoring.`);
    return;
  }

  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  errorInfo: string | null;
}

class ErrorBoundary extends Component<any, any> {
  constructor(props: any) {
    super(props);
    (this as any).state = { hasError: false, errorInfo: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, errorInfo: error.message };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("ErrorBoundary caught an error", error, errorInfo);
  }

  render() {
    if ((this as any).state.hasError) {
      let displayMessage = "Something went wrong.";
      try {
        const parsed = JSON.parse((this as any).state.errorInfo || "");
        if (parsed.error && parsed.error.includes("insufficient permissions")) {
          displayMessage = "You don't have permission to perform this action. Please check your account status.";
        }
      } catch (e) {
        // Not a JSON error
      }

      return (
        <div className="min-h-screen bg-Ghozt-bg flex flex-col items-center justify-center p-6 text-center">
          <AlertCircle size={48} className="text-Ghozt-pink mb-4" />
          <h2 className="text-2xl font-bold mb-2 text-white">Oops!</h2>
          <p className="text-white/60 mb-6">{displayMessage}</p>
          <button 
            onClick={() => window.location.reload()}
            className="px-6 py-3 bg-Ghozt-cyan text-black font-bold rounded-2xl glow-cyan"
          >
            Reload App
          </button>
        </div>
      );
    }

    return (this as any).props.children;
  }
}

export interface Message {
  id: string;
  text?: string;
  imageUrl?: string;
  fileUrl?: string;
  fileName?: string;
  fileType?: string;
  senderId: string;
  senderName: string;
  timestamp: number;
  duration: number;
  openedAt?: number;
  expiresAt: number;
  roomId: string;
  reactions?: Record<string, string[]>;
}

export interface NotificationSettings {
  global: boolean;
  globalChat: boolean;
  groups: boolean;
  directMessages: boolean;
  mutedGroups: string[];
  mutedContacts: string[];
}

export interface UserProfile {
  uid: string;
  displayName: string;
  photoURL: string | null;
  phoneNumber?: string;
  isPremium?: boolean;
  isOnline: boolean;
  lastSeen: number;
  createdAt: any;
  theme?: string;
  screenshotCount?: number;
  lastScreenshotAttempt?: number;
  trustScore?: number;
  isInvisible?: boolean;
  notificationSettings?: NotificationSettings;
  isMuted?: boolean;
  directMessages?: string[]; // Array of contact UIDs
}

export interface Group {
  id: string;
  name: string;
  createdBy: string;
  createdAt: number;
  members: string[];
}

interface MessageBubbleProps {
  message: Message;
  onExpire: (id: string) => void;
  isChatBlurred?: boolean;
  key?: string;
}

// --- Components ---

const AdBanner = ({ onRemoveAds }: { onRemoveAds: () => void }) => (
  <motion.div 
    initial={{ opacity: 0, scale: 0.9 }}
    animate={{ opacity: 1, scale: 1 }}
    className="w-full p-6 glass border-Ghozt-cyan/20 rounded-3xl flex flex-col gap-4 mb-8 relative overflow-hidden group glow-cyan/10"
  >
    <div className="absolute -top-10 -right-10 w-32 h-32 bg-Ghozt-cyan/10 blur-3xl rounded-full" />
    
    <div className="flex items-center justify-between relative z-10">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-Ghozt-cyan/10 rounded-xl flex items-center justify-center border border-Ghozt-cyan/20">
          <Smartphone size={20} className="text-Ghozt-cyan" />
        </div>
        <div>
          <p className="text-[10px] font-bold uppercase tracking-widest text-Ghozt-cyan">AdMob Simulator</p>
          <p className="text-xs font-bold text-white/90">Inline Adaptive Banner</p>
        </div>
      </div>
      <div className="px-2 py-1 bg-white/5 rounded border border-white/10">
        <span className="text-[8px] font-black uppercase tracking-tighter text-white/40">Test Ad</span>
      </div>
    </div>

    <div className="h-32 bg-white/5 rounded-2xl border border-dashed border-white/10 flex flex-col items-center justify-center text-center p-4">
      <p className="text-[10px] font-bold uppercase tracking-widest text-white/20 mb-2">Real Ad Content Will Render Here</p>
      <p className="text-[9px] text-white/10 max-w-[200px]">On your phone, this area will be replaced by a live Google AdMob banner.</p>
    </div>

    <button 
      onClick={onRemoveAds}
      className="w-full py-3 bg-Ghozt-cyan text-black rounded-xl text-[10px] font-black uppercase tracking-widest transition-all hover:scale-[1.02] active:scale-95 glow-cyan"
    >
      Remove All Ads
    </button>
  </motion.div>
);

const MessageBubble = ({ message, onExpire, isChatBlurred }: MessageBubbleProps) => {
  const [localOpenedAt, setLocalOpenedAt] = useState<number | null>(null);
  const [localExpiresAt, setLocalExpiresAt] = useState<number | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isTemporarilyRevealed, setIsTemporarilyRevealed] = useState(false);
  const [timeLeft, setTimeLeft] = useState(() => {
    const openedAt = message.openedAt || localOpenedAt;
    const expiresAt = message.expiresAt || localExpiresAt;
    if (!openedAt) {
      return Math.round(message.duration / 1000);
    }
    return Math.max(0, Math.round(((expiresAt || 0) - Date.now()) / 1000));
  });
  
  const isMe = auth.currentUser?.uid === message.senderId;
  const isBlurred = isChatBlurred && !isTemporarilyRevealed;

  useEffect(() => {
    const calculateTimeLeft = () => {
      const openedAt = message.openedAt || localOpenedAt;
      const expiresAt = message.expiresAt || localExpiresAt;
      if (!openedAt) {
        return Math.round(message.duration / 1000);
      }
      return Math.max(0, Math.round(((expiresAt || 0) - Date.now()) / 1000));
    };

    // Set initial time left
    setTimeLeft(calculateTimeLeft());

    const openedAt = message.openedAt || localOpenedAt;
    if (!openedAt) return;

    const timer = setInterval(() => {
      const remaining = calculateTimeLeft();
      setTimeLeft(remaining);
      if (remaining <= 0) {
        onExpire(message.id);
        clearInterval(timer);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [message.openedAt, message.expiresAt, message.duration, message.id, onExpire, localOpenedAt, localExpiresAt]);

  const handleReveal = async () => {
    if (isChatBlurred && !isTemporarilyRevealed) {
      setIsTemporarilyRevealed(true);
      return;
    }
    if (isMe) {
      // You can't reveal your own messages, but we can show a hint
      return;
    }
    if (message.openedAt || localOpenedAt) return;
    
    const now = Date.now();
    const expiresAt = now + message.duration;
    
    // Optimistic update
    setLocalOpenedAt(now);
    setLocalExpiresAt(expiresAt);
    
    try {
      await setDoc(doc(db, "messages", message.id), {
        openedAt: now,
        expiresAt: expiresAt
      }, { merge: true });
    } catch (error) {
      // Rollback on error
      setLocalOpenedAt(null);
      setLocalExpiresAt(null);
      handleFirestoreError(error, OperationType.WRITE, `messages/${message.id}`);
    }
  };

  const handleReaction = async (emoji: string) => {
    if (!auth.currentUser) return;
    const userId = auth.currentUser.uid;
    const currentReactions = message.reactions || {};
    const userIds = currentReactions[emoji] || [];
    
    let newUserIds;
    if (userIds.includes(userId)) {
      newUserIds = userIds.filter(id => id !== userId);
    } else {
      newUserIds = [...userIds, userId];
    }
    
    const newReactions = { ...currentReactions };
    if (newUserIds.length === 0) {
      delete newReactions[emoji];
    } else {
      newReactions[emoji] = newUserIds;
    }
    
    try {
      await setDoc(doc(db, "messages", message.id), {
        reactions: newReactions
      }, { merge: true });
      setShowEmojiPicker(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `messages/${message.id}`);
    }
  };

  const commonEmojis = ['👻', '🔥', '💀', '👀', '💯', '😂', '❤️', '👍'];

  return (
    <motion.div
      layout
      initial={{ 
        opacity: 0, 
        x: isMe ? 50 : -50, 
        scale: 0.8, 
        rotate: isMe ? 5 : -5,
        filter: "blur(10px)" 
      }}
      animate={{ 
        opacity: 1, 
        x: 0, 
        scale: 1, 
        rotate: 0,
        filter: "blur(0px)" 
      }}
      exit={{ 
        opacity: 0, 
        scale: 0.5, 
        filter: "blur(20px)",
        transition: { duration: 0.2 } 
      }}
      whileHover={{ 
        scale: 1.01, 
        y: -2,
        transition: { duration: 0.2 } 
      }}
      whileTap={{ scale: 0.98 }}
      transition={{ 
        type: "spring", 
        stiffness: 350, 
        damping: 25,
        opacity: { duration: 0.3 },
        filter: { duration: 0.3 }
      }}
      className={cn(
        "max-w-[85%] p-4 rounded-[1.5rem] mb-4 relative group transition-all duration-300",
        isMe 
          ? "bg-gradient-to-br from-Ghozt-cyan via-Ghozt-cyan to-[#00b8cc] text-black self-end rounded-tr-none shadow-[0_8px_30px_-10px_rgba(0,229,255,0.5)] border border-white/20" 
          : "glass bg-white/5 backdrop-blur-2xl text-white self-start rounded-tl-none border border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)]",
        ((!message.openedAt && !isMe) || isBlurred) && "cursor-pointer hover:shadow-2xl active:scale-95"
      )}
      onClick={handleReveal}
    >
      {!isMe && <p className="text-[10px] font-bold uppercase tracking-widest text-Ghozt-cyan mb-1">{message.senderName}</p>}
      
      <div className={cn(
        "transition-all duration-500",
        ((!message.openedAt && !isMe) || isBlurred) && "blur-xl select-none opacity-20 scale-95"
      )}>
        {message.imageUrl ? (
          <div className="relative rounded-lg overflow-hidden mb-2">
            <img 
              src={message.imageUrl} 
              alt="Ghozt Photo" 
              className="w-full h-auto max-h-64 object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        ) : message.fileUrl ? (
          <div className="flex flex-col gap-2 mb-2">
            {message.fileType?.startsWith('image/') && (
              <div className="relative rounded-lg overflow-hidden">
                <img 
                  src={message.fileUrl} 
                  alt="Attachment Preview" 
                  className="w-full h-auto max-h-64 object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            )}
            <div className="flex items-center gap-3 p-3 bg-black/10 rounded-xl border border-white/5">
              <div className="w-10 h-10 bg-Ghozt-purple/20 rounded-lg flex items-center justify-center text-Ghozt-cyan">
                <FileText size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold truncate">{message.fileName}</p>
                <p className="text-[8px] uppercase tracking-widest opacity-40">{message.fileType}</p>
              </div>
              <a 
                href={message.fileUrl} 
                download={message.fileName}
                onClick={(e) => e.stopPropagation()}
                className="p-2 hover:bg-white/10 rounded-full transition-colors text-Ghozt-cyan"
              >
                <Download size={16} />
              </a>
            </div>
          </div>
        ) : (
          <p className="text-sm leading-relaxed break-words font-medium">{message.text}</p>
        )}
      </div>

      {/* Reactions Display */}
      {message.reactions && Object.keys(message.reactions).length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2">
          {Object.entries(message.reactions).map(([emoji, userIds]) => (
            <button
              key={emoji}
              onClick={(e) => {
                e.stopPropagation();
                handleReaction(emoji);
              }}
              className={cn(
                "flex items-center gap-1.5 px-1.5 py-0.5 rounded-full text-[10px] font-bold transition-all",
                userIds.includes(auth.currentUser?.uid || "")
                  ? isMe ? "bg-black/20 text-black" : "bg-Ghozt-cyan/20 text-Ghozt-cyan border border-Ghozt-cyan/30"
                  : isMe ? "bg-black/5 text-black/40" : "bg-white/5 text-white/40 border border-white/10"
              )}
            >
              <span>{emoji}</span>
              <span>{userIds.length}</span>
            </button>
          ))}
        </div>
      )}

      {/* Reaction Picker Trigger */}
      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          onClick={(e) => {
            e.stopPropagation();
            setShowEmojiPicker(!showEmojiPicker);
          }}
          className={cn(
            "p-1 rounded-full transition-colors",
            isMe ? "hover:bg-black/10 text-black/40" : "hover:bg-white/10 text-white/40"
          )}
        >
          <Plus size={14} />
        </button>
      </div>

      {/* Emoji Picker Popover */}
      <AnimatePresence>
        {showEmojiPicker && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 10 }}
            className={cn(
              "absolute z-20 bottom-full mb-2 p-2 rounded-2xl border shadow-2xl flex gap-1",
              isMe ? "right-0 bg-Ghozt-cyan border-black/10" : "left-0 bg-Ghozt-bg border-Ghozt-purple/30"
            )}
            onClick={(e) => e.stopPropagation()}
          >
            {commonEmojis.map(emoji => (
              <button
                key={emoji}
                onClick={() => handleReaction(emoji)}
                className="w-8 h-8 flex items-center justify-center hover:bg-white/10 rounded-lg transition-colors text-lg"
              >
                {emoji}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {!message.openedAt && !isMe && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="bg-Ghozt-purple/20 backdrop-blur-md px-3 py-1.5 rounded-full border border-Ghozt-purple/30 flex items-center gap-2 glow-purple">
            <Eye size={12} className="text-Ghozt-cyan" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-Ghozt-cyan">Reveal</span>
          </div>
        </div>
      )}
      
      <div className={cn(
        "flex items-center gap-2 mt-3 pt-2 border-t",
        isMe ? "text-black/40 border-black/5" : "text-white/40 border-white/5"
      )}>
        <div className={cn(
          "flex items-center gap-1.5 px-2 py-0.5 rounded-full",
          isMe ? "bg-black/5" : "bg-white/5"
        )}>
          <Clock size={10} className="animate-pulse" />
          <span className="text-[10px] font-mono tabular-nums font-bold">
            {!message.openedAt && !isMe ? `${Math.round(message.duration / 1000)}s` : `${timeLeft}s`}
          </span>
        </div>
        
        {message.openedAt && (
          <div className={cn(
            "flex items-center gap-1 px-2 py-0.5 rounded-full text-[8px] uppercase tracking-widest font-black",
            !isMe ? "bg-Ghozt-cyan/20 text-Ghozt-cyan" : "bg-black/10 text-black/60"
          )}>
            <div className="w-1 h-1 rounded-full bg-current animate-ping" />
            Active
          </div>
        )}
        
        {isMe && (
          <div className="flex items-center gap-1 ml-auto">
            {!message.openedAt ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-1 bg-black/5 px-2 py-0.5 rounded-full"
              >
                <Check size={10} className="text-black/40" />
                <span className="text-[8px] uppercase tracking-widest font-black opacity-40">Sent</span>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-1 bg-black/10 px-2 py-0.5 rounded-full"
              >
                <div className="flex -space-x-1">
                  <Check size={10} className="text-black/60" />
                  <Check size={10} className="text-black/60" />
                </div>
                <span className="text-[8px] uppercase tracking-widest font-black text-black/60">Opened</span>
              </motion.div>
            )}
          </div>
        )}
        
        {isMe && (
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onExpire(message.id);
            }}
            className="ml-1 p-1 hover:bg-black/10 rounded-full transition-colors text-black/40 hover:text-red-600"
          >
            <Trash2 size={12} />
          </button>
        )}
      </div>

      {/* Expiry Progress Bar (only after opening) */}
      {message.openedAt && (
        <div className="absolute bottom-0 left-0 h-0.5 bg-black/10 w-full overflow-hidden">
          <motion.div 
            initial={{ width: "100%" }}
            animate={{ width: "0%" }}
            transition={{ duration: (message.expiresAt - message.openedAt) / 1000, ease: "linear" }}
            className={cn(
              "h-full",
              isMe ? "bg-black/20" : "bg-Ghozt-cyan"
            )}
          />
        </div>
      )}
    </motion.div>
  );
};

const TypingIndicator = ({ users }: { users: {[key: string]: string} }) => {
  const userNames = Object.values(users);
  if (userNames.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      className="flex items-center gap-2 px-4 py-2 mb-2"
    >
      <div className="flex gap-1">
        <motion.div
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ repeat: Infinity, duration: 0.6, delay: 0 }}
          className="w-1.5 h-1.5 bg-Ghozt-cyan rounded-full"
        />
        <motion.div
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }}
          className="w-1.5 h-1.5 bg-Ghozt-cyan rounded-full"
        />
        <motion.div
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }}
          className="w-1.5 h-1.5 bg-Ghozt-cyan rounded-full"
        />
      </div>
      <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">
        {userNames.length === 1 
          ? `${userNames[0]} is typing...` 
          : `${userNames.length} people are typing...`}
      </span>
    </motion.div>
  );
};

const RippleOverlay = ({ isWarning }: { isWarning: boolean }) => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Intermittent flashing overlay */}
      {isWarning && (
        <motion.div
          animate={{ opacity: [0, 0.15, 0] }}
          transition={{ duration: 0.8, repeat: Infinity, repeatDelay: 1.2 }}
          className="absolute inset-0 bg-Ghozt-pink"
        />
      )}
      
      {/* Expanding ripple rings */}
      <div className="absolute inset-0 flex items-center justify-center">
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ scale: 0.3, opacity: 0 }}
            animate={{ 
              scale: [0.3, 2.5], 
              opacity: [0, 0.6, 0] 
            }}
            transition={{ 
              duration: 4, 
              repeat: Infinity, 
              delay: i * 1.3,
              ease: "easeOut" 
            }}
            className={cn(
              "absolute w-[50vh] h-[50vh] border-[6px] rounded-full",
              isWarning ? "border-Ghozt-pink/60" : "border-Ghozt-cyan/50"
            )}
          />
        ))}
      </div>
    </div>
  );
};

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState("");
  const [timerSeconds, setTimerSeconds] = useState(10);
  const [isBlurred, setIsBlurred] = useState(false);
  const [showScreenshotWarning, setShowScreenshotWarning] = useState(false);
  const [showPreScreenshotWarning, setShowPreScreenshotWarning] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState<UserProfile[]>([]);
  const [showContacts, setShowContacts] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [showPhonePrompt, setShowPhonePrompt] = useState(false);
  const [syncedContacts, setSyncedContacts] = useState<any[]>([]);
  const [userContacts, setUserContacts] = useState<string[]>([]);
  const [fullContacts, setFullContacts] = useState<UserProfile[]>([]);
  const [selectedGroupMembers, setSelectedGroupMembers] = useState<string[]>([]);
  const [showGroupSettings, setShowGroupSettings] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [typingUsers, setTypingUsers] = useState<{[key: string]: string}>({});
  const [isPremium, setIsPremium] = useState(false);
  const [isAdMobInitialized, setIsAdMobInitialized] = useState(false);
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [currentTheme, setCurrentTheme] = useState("phantom");
  const [showThemeSelector, setShowThemeSelector] = useState(false);
  const [otp, setOtp] = useState("");
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<{ url: string; name: string; type: string } | null>(null);
  const [privacyEnabled, setPrivacyEnabled] = useState(false);
  const [isChatBlurred, setIsChatBlurred] = useState(false);
  const [isNative] = useState(Capacitor.isNativePlatform());
  const [isInteractingWithSystem, setIsInteractingWithSystem] = useState(false);
  const isInteractingWithSystemRef = useRef(false);

  useEffect(() => {
    isInteractingWithSystemRef.current = isInteractingWithSystem;
  }, [isInteractingWithSystem]);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>("default");
  const [groups, setGroups] = useState<Group[]>([]);
  const [currentRoomId, setCurrentRoomId] = useState("global-chat");
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");
  const [showSplash, setShowSplash] = useState(true);
  const [loading, setLoading] = useState(true);
  const [isScreenshotMode, setIsScreenshotMode] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem('Ghozt_onboarding_seen');
    if (!hasSeenOnboarding && auth.currentUser) {
      setShowOnboarding(true);
      localStorage.setItem('Ghozt_onboarding_seen', 'true');
    }
  }, [auth.currentUser]);

  const deleteAccount = async () => {
    if (!user) return;
    try {
      // Delete user profile from Firestore
      await deleteDoc(doc(db, "users", user.uid));
      // Delete user from Firebase Auth
      await deleteUser(user);
      toast.success("Account Deleted", {
        description: "Your account and data have been permanently removed."
      });
    } catch (error) {
      console.error("Error deleting account:", error);
      toast.error("Deletion Failed", {
        description: "Please re-authenticate and try again."
      });
    }
  };

  const effectiveUserProfile = isScreenshotMode ? FAKE_USER_PROFILE : userProfile;
  const effectiveMessages = isScreenshotMode ? FAKE_MESSAGES : messages;
  const effectiveGroups = isScreenshotMode ? FAKE_GROUPS : groups;
  const effectiveContacts = isScreenshotMode ? FAKE_CONTACTS : fullContacts;
  const effectiveOnlineUsers = isScreenshotMode ? FAKE_CONTACTS.filter(c => c.isOnline) : onlineUsers;

  const recaptchaRef = useRef<HTMLDivElement>(null);
  const lastMessageIdRef = useRef<string | null>(null);
  const lastNotifiedMessageIdRef = useRef<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if ("Notification" in window) {
      setNotificationPermission(Notification.permission);
    }
  }, []);

  const requestNotificationPermission = async () => {
    if (!("Notification" in window)) {
      toast.error("Notifications not supported", {
        description: "Your browser doesn't support native notifications. We'll use in-app alerts instead."
      });
      return;
    }
    
    try {
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);
      
      if (permission === "granted") {
        toast.success("Notifications Enabled!", {
          description: "You'll now get alerts for new Ghozt messages."
        });
        // Send a test notification
        new Notification("Ghozt Notifications Active", {
          body: "You're all set to receive alerts!",
          icon: "/icon.svg"
        });
      } else if (permission === "denied") {
        toast.error("Permission Denied", {
          description: "Please enable notifications in your browser settings to receive alerts."
        });
      }
    } catch (error) {
      console.error("Notification permission error:", error);
      toast.error("Notification Error", {
        description: "Failed to request notification permission."
      });
    }
  };

  useEffect(() => {
    if (!user || !auth.currentUser || user.uid !== auth.currentUser.uid) return;

    // Listen to user profile for premium status and theme
    const unsub = onSnapshot(doc(db, "users", user.uid), (doc) => {
      if (doc.exists()) {
        const data = doc.data();
        setIsPremium(data.isPremium || false);
        if (data.theme) {
          setCurrentTheme(data.theme);
        }
      }
    });

    // Listen to user's contacts
    const unsubContacts = onSnapshot(collection(db, "users", user.uid, "contacts"), async (snapshot) => {
      const contactData = snapshot.docs.map(doc => ({ uid: doc.data().uid, isMuted: doc.data().isMuted }));
      setUserContacts(contactData.map(c => c.uid));
      
      // Fetch full profiles for these contacts
      const profiles: UserProfile[] = [];
      for (const contact of contactData) {
        try {
          const userDoc = await getDoc(doc(db, "users", contact.uid));
          if (userDoc.exists()) {
            profiles.push({ uid: contact.uid, ...userDoc.data(), isMuted: contact.isMuted } as UserProfile);
          }
        } catch (error) {
          console.error("Error fetching contact profile:", error);
        }
      }
      setFullContacts(profiles);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}/contacts`);
    });

    // Listen to user's groups
    const qGroups = query(collection(db, "groups"), where("members", "array-contains", user.uid));
    const unsubGroups = onSnapshot(qGroups, (snapshot) => {
      const groupsList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Group));
      setGroups(groupsList);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "groups");
    });

    // Handle Stripe success redirect
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get("premium_success") === "true") {
      const updatePremium = async () => {
        try {
          await setDoc(doc(db, "users", user.uid), { 
            uid: user.uid,
            displayName: user.displayName || "Anonymous",
            photoURL: user.photoURL,
            isPremium: true 
          }, { merge: true });
          // Clear URL params
          window.history.replaceState({}, document.title, "/");
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
        }
      };
      updatePremium();
    }

    return () => unsub();
  }, [user]);

  // Initialize Store for In-App Purchases (Google Play Billing)
  useEffect(() => {
    if (!Capacitor.isNativePlatform() || !(window as any).CdvPurchase) return;

    const { store, ProductType, Platform } = (window as any).CdvPurchase;

    if (!store) return;

    // Register our premium product
    store.register({
      id: "Ghozt_premium_upgrade",
      type: ProductType.NON_CONSUMABLE,
      platform: Platform.GOOGLE_PLAY,
    });

    // Handle successful purchase
    store.when("Ghozt_premium_upgrade")
      .approved((transaction: any) => {
        console.log("Purchase approved:", transaction);
        transaction.verify();
      })
      .verified((receipt: any) => {
        console.log("Purchase verified:", receipt);
        receipt.finish();
        
        // Update user profile in Firestore
        if (user) {
          setDoc(doc(db, "users", user.uid), { isPremium: true }, { merge: true })
            .then(() => {
              toast.success("Premium Activated", {
                description: "Thank you for supporting Ghozt! Ads are now removed."
              });
              setIsPremium(true);
            })
            .catch(err => handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`));
        }
      });

    store.initialize([Platform.GOOGLE_PLAY]);

    return () => {
      // Store cleanup if needed
    };
  }, [user]);

  // Initialize AdMob
  useEffect(() => {
    if (!isNative) return;

    const initAdMob = async () => {
      try {
        await AdMob.initialize();
        setIsAdMobInitialized(true);
      } catch (error) {
        console.error("AdMob initialization failed:", error);
      }
    };

    initAdMob();
  }, [isNative]);

  // Show/Hide Banner Ad based on Premium status
  useEffect(() => {
    if (!isNative || !isAdMobInitialized) return;

    const handleBanner = async () => {
      if (isPremium) {
        await AdMob.hideBanner().catch(console.error);
        await AdMob.removeBanner().catch(console.error);
      } else {
        const adId = Capacitor.getPlatform() === 'ios' 
          ? 'ca-app-pub-3940256099942544/2934735716' // iOS Test ID
          : 'ca-app-pub-3940256099942544/6300978111'; // Android Test ID

        await AdMob.showBanner({
          adId,
          adSize: BannerAdSize.ADAPTIVE_BANNER,
          position: BannerAdPosition.BOTTOM_CENTER,
          margin: 0,
          isTesting: true
        }).catch(console.error);
      }
    };

    handleBanner();

    return () => {
      if (isNative) {
        AdMob.hideBanner().catch(console.error);
        AdMob.removeBanner().catch(console.error);
      }
    };
  }, [isNative, isAdMobInitialized, isPremium]);

  const handleUpgrade = async () => {
    if (!user) return;
    setIsUpgrading(true);

    // If on native platform, use Google Play Billing
    if (Capacitor.isNativePlatform() && (window as any).CdvPurchase) {
      try {
        const { store } = (window as any).CdvPurchase;
        const product = store.get("Ghozt_premium_upgrade");
        if (product && product.canPurchase) {
          product.getOffer().order();
        } else {
          toast.error("Store Error", {
            description: "Product not available for purchase at this time."
          });
        }
      } catch (error) {
        console.error("Store error:", error);
        toast.error("Upgrade Failed", {
          description: "Failed to connect to the Play Store."
        });
      } finally {
        setIsUpgrading(false);
      }
      return;
    }

    // Fallback to Stripe for Web
    try {
      const response = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.uid }),
      });
      const session = await response.json();
      if (session.url) {
        window.location.href = session.url;
      }
    } catch (error) {
      console.error("Error initiating upgrade:", error);
      toast.error("Upgrade Failed", {
        description: "Failed to initiate upgrade. Please try again."
      });
    } finally {
      setIsUpgrading(false);
    }
  };

  const updateNotificationSettings = async (settings: Partial<NotificationSettings>) => {
    if (!user || !userProfile) return;
    const currentSettings = userProfile.notificationSettings || {
      global: true,
      globalChat: true,
      groups: true,
      directMessages: true,
      mutedGroups: [],
      mutedContacts: []
    };
    const newSettings = { ...currentSettings, ...settings };
    try {
      await setDoc(doc(db, "users", user.uid), { 
        notificationSettings: newSettings 
      }, { merge: true });
      toast.success("Settings Updated", {
        description: "Your notification preferences have been saved.",
        icon: <Bell className="w-4 h-4 text-Ghozt-cyan" />
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
    }
  };

  const toggleMuteGroup = async (groupId: string) => {
    if (!user || !userProfile) return;
    const currentMuted = userProfile.notificationSettings?.mutedGroups || [];
    const isMuted = currentMuted.includes(groupId);
    const newMuted = isMuted 
      ? currentMuted.filter(id => id !== groupId)
      : [...currentMuted, groupId];
    
    await updateNotificationSettings({ mutedGroups: newMuted });
  };

  const toggleMuteContact = async (contactUid: string) => {
    if (!user || !userProfile) return;
    const currentMuted = userProfile.notificationSettings?.mutedContacts || [];
    const isMuted = currentMuted.includes(contactUid);
    const newMuted = isMuted 
      ? currentMuted.filter(id => id !== contactUid)
      : [...currentMuted, contactUid];
    
    await updateNotificationSettings({ mutedContacts: newMuted });
  };

  const startDirectMessage = async (contactUid: string) => {
    if (!user || !userProfile) return;
    
    // Room ID for DM is always "dm_uid1_uid2" where uids are sorted alphabetically
    const roomId = [user.uid, contactUid].sort().join("_");
    const dmRoomId = `dm_${roomId}`;
    
    // Add to active DMs if not already there
    const currentDMs = userProfile.directMessages || [];
    if (!currentDMs.includes(contactUid)) {
      try {
        await setDoc(doc(db, "users", user.uid), {
          directMessages: [...currentDMs, contactUid]
        }, { merge: true });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
      }
    }
    
    setCurrentRoomId(dmRoomId);
    setShowContacts(false);
    setShowCreateGroup(false);
  };

  const deleteDirectMessage = async (contactUid: string) => {
    if (!user || !userProfile) return;
    const currentDMs = userProfile.directMessages || [];
    const newDMs = currentDMs.filter(id => id !== contactUid);
    try {
      await setDoc(doc(db, "users", user.uid), {
        directMessages: newDMs
      }, { merge: true });
      if (currentRoomId.includes(contactUid)) {
        setCurrentRoomId("global-chat");
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  // Auth listener and presence
  useEffect(() => {
    testConnection();
    
    // Safety timeout: if auth doesn't respond in 3 seconds, stop loading
    const loadingTimeout = setTimeout(() => {
      setLoading(false);
    }, 3000);

    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      clearTimeout(loadingTimeout);
      setUser(u);
      setLoading(false);

      if (u) {
        try {
          // Update user profile and status
          const userRef = doc(db, "users", u.uid);
          const userDoc = await getDoc(userRef);
          
          const profileData: any = {
            uid: u.uid,
            displayName: u.displayName || "Anonymous",
            photoURL: u.photoURL,
            isOnline: userDoc.exists() ? (userDoc.data().isInvisible ? false : true) : true,
            lastSeen: Date.now(),
            createdAt: userDoc.exists() ? userDoc.data().createdAt : serverTimestamp()
          };

          if (userDoc.exists() && userDoc.data().phoneNumber) {
            profileData.phoneNumber = userDoc.data().phoneNumber;
          } else {
            setShowPhonePrompt(true);
          }

          await setDoc(userRef, profileData, { merge: true });
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, `users/${u.uid}`);
        }
      }
    });
    return () => unsubscribe();
  }, []);

  // Listen to user's own profile for trust score and screenshot count
  useEffect(() => {
    if (!user || !auth.currentUser || user.uid !== auth.currentUser.uid) {
      setUserProfile(null);
      return;
    }
    const unsub = onSnapshot(doc(db, "users", user.uid), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data() as UserProfile;
        // Calculate trust score: starts at 100, drops by 15 per screenshot
        // Premium users lose only 5 per attempt
        const penalty = data.isPremium ? 5 : 15;
        const calculatedScore = 100 - ((data.screenshotCount ?? 0) * penalty);
        setUserProfile({ ...data, trustScore: Math.max(0, calculatedScore) });
      }
    });
    return () => unsub();
  }, [user]);

  // Monitor screenshot count for severe warnings
  useEffect(() => {
    const count = userProfile?.screenshotCount ?? 0;
    if (count > 0) {
      if (count >= 5) {
        toast.error("SECURITY ALERT: Critical Trust Score", {
          description: "Your account is flagged for excessive screenshot attempts. Access may be restricted.",
          duration: 8000
        });
      } else if (count >= 3) {
        toast.warning("Security Warning", {
          description: "Multiple screenshot attempts detected. Your trust score is dropping.",
          duration: 5000
        });
      }
    }
  }, [userProfile?.screenshotCount]);

  // Centralized Privacy Screen Controller
  useEffect(() => {
    if (!isNative) return;

    const handlePrivacy = async (active: boolean) => {
      try {
        if (active && privacyEnabled && !isInteractingWithSystemRef.current) {
          // Only enable when app goes to background
          await PrivacyScreen.enable();
          console.log("Privacy Screen: Enabled for background");
        } else {
          // Always disable when app is active
          await PrivacyScreen.disable();
          console.log("Privacy Screen: Disabled for foreground");
        }
      } catch (e) {
        console.error("Privacy Screen Error:", e);
      }
    };

    const listener = CapApp.addListener('appStateChange', (state) => {
      handlePrivacy(!state.isActive);
    });

    // Initial state: disable for foreground
    handlePrivacy(false);

    return () => {
      listener.then(l => l.remove());
    };
  }, [isNative, privacyEnabled]);

  // Update online status on focus/blur
  useEffect(() => {
    const updateStatus = async (online: boolean) => {
      if (!user) return;
      // If invisible, we never set isOnline to true
      const shouldBeOnline = userProfile?.isInvisible ? false : online;
      
      try {
        const userRef = doc(db, "users", user.uid);
        await setDoc(userRef, { 
          uid: user.uid,
          displayName: user.displayName || "Anonymous",
          photoURL: user.photoURL,
          isOnline: shouldBeOnline,
          lastSeen: Date.now()
        }, { merge: true });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
      }
    };

    const handleBlur = () => {
      updateStatus(false);
    };

    const handleFocus = () => {
      updateStatus(true);
      setIsBlurred(false);
      document.body.classList.remove("blurred");
      if (isNative) {
        // Force disable privacy screen on focus just in case
        PrivacyScreen.disable().catch(console.error);
        
        const delay = isInteractingWithSystemRef.current ? 3500 : 1500;
        setTimeout(() => {
          setIsInteractingWithSystem(false);
        }, delay);
      }
    };

    const handleAppStateChange = (state: { isActive: boolean }) => {
      if (state.isActive) {
        handleFocus();
      } else {
        handleBlur();
      }
    };

    let appStateListener: any = null;
    if (isNative) {
      appStateListener = CapApp.addListener('appStateChange', handleAppStateChange);
    }

    window.addEventListener("focus", handleFocus);
    window.addEventListener("blur", handleBlur);

    // Initial security toast
    if (user) {
      toast.info("Secure Session Active", {
        description: "Screenshot protection and ephemeral messaging enabled.",
        duration: 3000,
        icon: <Shield className="text-Ghozt-cyan" size={16} />
      });
    }

    return () => {
      window.removeEventListener("focus", handleFocus);
      window.removeEventListener("blur", handleBlur);
      if (appStateListener) {
        appStateListener.remove();
      }
    };
  }, [user, userProfile?.isInvisible]);

  // Screenshot deterrent: detect PrintScreen and handle Visibility API
  useEffect(() => {
    const handleVisibilityChange = async () => {
      if (document.visibilityState === "hidden") {
        setIsBlurred(true);
        document.body.classList.add("blurred");
        if (user) {
          try {
            await setDoc(doc(db, "users", user.uid), { 
              uid: user.uid,
              displayName: user.displayName || "Anonymous",
              photoURL: user.photoURL,
              isOnline: false, 
              lastSeen: Date.now() 
            }, { merge: true });
          } catch (error) {
            handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
          }
        }
      } else {
        // Always unblur when visible
        setIsBlurred(false);
        document.body.classList.remove("blurred");
        
        if (isNative) {
          PrivacyScreen.disable().catch(console.error);
        }

        if (user) {
          try {
            // Respect invisible mode
            const shouldBeOnline = userProfile?.isInvisible ? false : true;
            await setDoc(doc(db, "users", user.uid), { 
              uid: user.uid,
              displayName: user.displayName || "Anonymous",
              photoURL: user.photoURL,
              isOnline: shouldBeOnline, 
              lastSeen: Date.now() 
            }, { merge: true });
          } catch (error) {
            handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
          }
        }
      }
    };
    
    const handleKeyDown = async (e: KeyboardEvent) => {
      // Pre-screenshot warning: detect if user starts a known screenshot sequence
      const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
      const isStartingShortcut = (e.metaKey || e.ctrlKey) && e.shiftKey;
      
      if (isStartingShortcut && !showPreScreenshotWarning && !showScreenshotWarning) {
        setShowPreScreenshotWarning(true);
        setTimeout(() => setShowPreScreenshotWarning(false), 3000);
      }

      // Detect PrintScreen key (keyCode 44)
      // Detect Mac screenshot shortcuts (Cmd+Shift+3/4/5)
      // Detect Windows screenshot shortcuts (Win+Shift+S)
      // Detect ChromeOS screenshot shortcuts (Ctrl+F5 / Ctrl+Shift+F5)
      const isScreenshotKey = e.key === "PrintScreen" || e.keyCode === 44;
      const isMacShortcut = isMac && e.metaKey && e.shiftKey && (e.key === "3" || e.key === "4" || e.key === "5");
      const isWinShortcut = !isMac && e.key === "s" && e.shiftKey && (e.metaKey || e.ctrlKey);
      const isChromeOSShortcut = e.ctrlKey && (e.key === "F5" || e.keyCode === 116);
      
      // Detect common screen recording shortcuts
      const isRecordingShortcut = (e.metaKey || e.ctrlKey) && e.shiftKey && e.key === "5";

      if (isScreenshotKey || isMacShortcut || isWinShortcut || isChromeOSShortcut || isRecordingShortcut) {
        setShowScreenshotWarning(true);
        setIsBlurred(true);
        document.body.classList.add("blurred");
        
        // Log the potential screenshot attempt to Firestore
        if (user) {
          try {
            await setDoc(doc(db, "users", user.uid), { 
              uid: user.uid,
              displayName: user.displayName || "Anonymous",
              photoURL: user.photoURL,
              lastScreenshotAttempt: Date.now(),
              screenshotCount: increment(1)
            }, { merge: true });
          } catch (error) {
            handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
          }
        }

        setTimeout(() => {
          setShowScreenshotWarning(false);
          if (document.hasFocus()) {
            setIsBlurred(false);
            document.body.classList.remove("blurred");
          }
        }, 5000);
      }
    };

    const handleBeforePrint = async () => {
      setIsBlurred(true);
      setShowScreenshotWarning(true);
      document.body.classList.add("blurred");
      
      if (user) {
        try {
          await setDoc(doc(db, "users", user.uid), { 
            uid: user.uid,
            displayName: user.displayName || "Anonymous",
            photoURL: user.photoURL,
            lastScreenshotAttempt: Date.now(),
            screenshotCount: increment(1)
          }, { merge: true });
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
        }
      }

      setTimeout(() => {
        setShowScreenshotWarning(false);
        if (document.hasFocus()) {
          setIsBlurred(false);
          document.body.classList.remove("blurred");
        }
      }, 5000);
    };

    const handleResize = () => {
      // Sudden window resize often indicates a screenshot tool or devtools opening
      // We'll skip blurring here as it's too disruptive for normal use
    };

    const handleMouseLeave = () => {
      // Relaxed deterrent: we won't blur on mouse leave anymore
    };

    const handleMouseEnter = () => {
      // Relaxed deterrent: we won't blur on mouse enter anymore
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    window.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("contextmenu", handleContextMenu);
    window.addEventListener("beforeprint", handleBeforePrint);
    window.addEventListener("resize", handleResize);
    window.addEventListener("pagehide", handleVisibilityChange);
    window.addEventListener("pageshow", handleVisibilityChange);
    document.addEventListener("mouseleave", handleMouseLeave);
    document.addEventListener("mouseenter", handleMouseEnter);

    return () => {
      window.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("contextmenu", handleContextMenu);
      window.removeEventListener("beforeprint", handleBeforePrint);
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("pagehide", handleVisibilityChange);
      window.removeEventListener("pageshow", handleVisibilityChange);
      document.removeEventListener("mouseleave", handleMouseLeave);
      document.removeEventListener("mouseenter", handleMouseEnter);
    };
  }, [user, userProfile?.isInvisible]);

  // Global notification listener
  useEffect(() => {
    if (!user || !userProfile || !auth.currentUser || user.uid !== auth.currentUser.uid) return;

    const q = query(
      collection(db, "messages"),
      where("expiresAt", ">", Date.now()),
      orderBy("expiresAt", "asc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const settings = userProfile.notificationSettings;
      const isGlobalEnabled = settings?.global ?? true;
      if (!isGlobalEnabled) return;

      snapshot.docChanges().forEach((change) => {
        if (change.type === "added") {
          const msg = { id: change.doc.id, ...change.doc.data() } as Message;
          
          // Don't notify for our own messages or already notified messages
          if (msg.senderId === user.uid || msg.id === lastNotifiedMessageIdRef.current) return;
          
          // Don't notify if we are currently in the room and the tab is visible
          if (msg.roomId === currentRoomId && document.visibilityState === "visible") return;

          lastNotifiedMessageIdRef.current = msg.id;

          let shouldNotify = false;
          if (msg.roomId === 'global-chat') {
            shouldNotify = settings?.globalChat ?? true;
          } else if (msg.roomId.startsWith('group-')) {
            const isGroupMuted = settings?.mutedGroups?.includes(msg.roomId);
            shouldNotify = (settings?.groups ?? true) && !isGroupMuted;
          } else if (msg.roomId.startsWith('dm_')) {
            // Direct message: roomId is dm_uid1_uid2
            const otherUid = msg.roomId.replace('dm_', '').split('_').find(id => id !== user.uid);
            const isContactMuted = settings?.mutedContacts?.includes(otherUid || "");
            shouldNotify = (settings?.directMessages ?? true) && !isContactMuted;
          }

          if (shouldNotify) {
            if (document.visibilityState !== "visible" && Notification.permission === "granted") {
              new Notification(`Ghozt: ${msg.senderName}`, {
                body: msg.text || (msg.imageUrl ? "Sent an image" : "Sent a Ghozt!"),
                icon: "/icon.svg"
              });
            } else {
              // In-app fallback toast
              toast.info(`New Ghozt from ${msg.senderName}`, {
                description: msg.text ? (msg.text.length > 30 ? msg.text.substring(0, 30) + "..." : msg.text) : "Tap to view",
                duration: 5000,
                icon: <Bell className="text-Ghozt-cyan" size={16} />
              });
            }
          }
        }
      });
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "messages");
    });

    return () => unsubscribe();
  }, [user, userProfile?.notificationSettings, currentRoomId]);

  // Firestore messages listener for current room UI
  useEffect(() => {
    if (!user || !auth.currentUser || user.uid !== auth.currentUser.uid) return;

    const q = query(
      collection(db, "messages"),
      where("roomId", "==", currentRoomId),
      where("expiresAt", ">", Date.now()),
      orderBy("expiresAt", "asc"),
      limit(50)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs: Message[] = [];
      snapshot.forEach((doc) => {
        msgs.push({ id: doc.id, ...doc.data() } as Message);
      });
      
      const newMsgs = msgs.filter(m => m.expiresAt > Date.now());
      setMessages(newMsgs);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "messages");
    });

    // Listen to typing status
    const qTyping = query(collection(db, "typing"), where("roomId", "==", currentRoomId));
    const unsubTyping = onSnapshot(qTyping, (snapshot) => {
      const typing: {[key: string]: string} = {};
      const now = Date.now();
      snapshot.docs.forEach(doc => {
        const data = doc.data();
        // Only show typing if it's not the current user and updated in the last 3 seconds
        if (data.userId !== user.uid && now - data.lastUpdated < 3000 && data.isTyping) {
          typing[data.userId] = data.displayName;
        }
      });
      setTypingUsers(typing);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "typing");
    });

    return () => {
      unsubscribe();
      unsubTyping();
    };
  }, [user, currentRoomId, userProfile?.notificationSettings, fullContacts]);

  const handleTyping = async (isTyping: boolean) => {
    if (!user || !currentRoomId) return;
    try {
      await setDoc(doc(db, "typing", `${currentRoomId}_${user.uid}`), {
        roomId: currentRoomId,
        userId: user.uid,
        displayName: user.displayName || "Ghozt",
        isTyping,
        lastUpdated: Date.now()
      }, { merge: true });
    } catch (error) {
      // Silent error for typing
    }
  };

  // Cleanup expired messages from local state periodically
  useEffect(() => {
    const interval = setInterval(() => {
      setMessages((prev) => {
        const now = Date.now();
        const filtered = prev.filter((m) => m.expiresAt > now);
        if (filtered.length !== prev.length) return filtered;
        return prev;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Online users listener
  useEffect(() => {
    if (!user || !auth.currentUser || user.uid !== auth.currentUser.uid) return;

    const q = query(
      collection(db, "users"),
      where("isOnline", "==", true),
      limit(20)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const users: UserProfile[] = [];
      snapshot.forEach((doc) => {
        users.push(doc.data() as UserProfile);
      });
      setOnlineUsers(users);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "users");
    });

    return () => unsubscribe();
  }, [user]);

  // Auto-scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [effectiveMessages]);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("theme-void", "theme-mist", "theme-solar");
    if (currentTheme !== "phantom") {
      root.classList.add(`theme-${currentTheme}`);
    }
  }, [currentTheme]);

  const handleThemeChange = async (theme: string) => {
    if (!user) return;
    setCurrentTheme(theme);
    try {
      await setDoc(doc(db, "users", user.uid), { 
        uid: user.uid,
        displayName: user.displayName || "Anonymous",
        photoURL: user.photoURL,
        theme 
      }, { merge: true });
      toast.success(`Theme updated to ${theme.charAt(0).toUpperCase() + theme.slice(1)}`);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
    }
  };

  const handleLogin = async () => {
    setAuthError(null);
    const provider = new GoogleAuthProvider();
    try {
      setIsInteractingWithSystem(true);
      // Temporarily disable privacy screen to avoid blackout during Google login popup
      if (isNative) {
        await PrivacyScreen.disable().catch(console.error);
      }
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      console.error("Login Error:", error);
      if (error.code === 'auth/popup-closed-by-user') {
        setAuthError("Sign-in popup was closed before completion. Please try again.");
      } else if (error.code === 'auth/cancelled-popup-request') {
        setAuthError("Sign-in was cancelled. Please try again.");
      } else if (error.code === 'auth/popup-blocked') {
        setAuthError("Sign-in popup was blocked by your browser. Please allow popups for this site.");
      } else {
        setAuthError(error.message || "Failed to sign in with Google.");
      }
    } finally {
      setIsInteractingWithSystem(false);
    }
  };

  const setupRecaptcha = () => {
    if (!(window as any).recaptchaVerifier) {
      try {
        (window as any).recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
          'size': 'invisible',
          'callback': () => {
            console.log("Recaptcha resolved");
          },
          'expired-callback': () => {
            console.log("Recaptcha expired");
            (window as any).recaptchaVerifier?.clear();
            (window as any).recaptchaVerifier = null;
          }
        });
      } catch (error) {
        console.error("Error setting up Recaptcha:", error);
      }
    }
  };

  const handlePhoneLogin = async () => {
    setAuthError(null);
    
    // Basic E.164 validation: must start with + and have at least 7 digits
    const cleaned = phoneNumber.replace(/\s+/g, '');
    if (!cleaned.startsWith('+')) {
      setAuthError("Phone number must start with '+' and include country code (e.g., +1234567890)");
      return;
    }
    
    if (cleaned.length < 8) {
      setAuthError("Invalid phone number length.");
      return;
    }

    setupRecaptcha();
    const appVerifier = (window as any).recaptchaVerifier;
    if (!appVerifier) {
      setAuthError("Authentication service is temporarily unavailable. Please refresh and try again.");
      return;
    }

    try {
      const confirmation = await signInWithPhoneNumber(auth, cleaned, appVerifier);
      setConfirmationResult(confirmation);
      setIsOtpSent(true);
    } catch (error: any) {
      console.error("Error sending OTP:", error);
      
      if (error.code === 'auth/invalid-phone-number') {
        setAuthError("The phone number format is invalid. Please use E.164 format (e.g., +12223334444).");
      } else if (error.code === 'auth/too-many-requests') {
        setAuthError("Too many attempts. Please try again later.");
      } else if (error.code === 'auth/internal-error') {
        setAuthError("An internal error occurred. This may be due to a network issue or Recaptcha failure. Please refresh and try again.");
      } else if (error.code === 'auth/operation-not-allowed') {
        setAuthError("SMS authentication is not enabled for this region. Please contact the app developer or enable it in the Firebase Console under Authentication > Settings > User sign-in > Phone > SMS Region Policy.");
      } else {
        setAuthError(error.message || "Failed to send verification code.");
      }
      
      if (appVerifier) {
        try {
          appVerifier.clear();
        } catch (e) {}
      }
      (window as any).recaptchaVerifier = null;
    }
  };

  const handleVerifyOtp = async () => {
    if (!otp.trim() || !confirmationResult) return;
    setAuthError(null);
    try {
      await confirmationResult.confirm(otp);
    } catch (error: any) {
      console.error("Error verifying OTP:", error);
      setAuthError("Invalid verification code. Please try again.");
    }
  };

  const handleLogout = () => signOut(auth);

  const savePhoneNumber = async () => {
    if (!user || !phoneNumber.trim()) return;
    
    // Simple normalization
    const normalized = phoneNumber.replace(/\D/g, "");
    if (normalized.length < 10) return;

    try {
      const userRef = doc(db, "users", user.uid);
      await setDoc(userRef, { 
        uid: user.uid,
        displayName: user.displayName || "Anonymous",
        photoURL: user.photoURL,
        phoneNumber: normalized 
      }, { merge: true });
      
      // Update lookup
      await setDoc(doc(db, "phone_lookup", normalized), { uid: user.uid });
      
      setShowPhonePrompt(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "users/phone_lookup");
    }
  };

  const syncContacts = async () => {
    if (!("contacts" in navigator && "select" in (navigator as any).contacts)) {
      toast.error("Not Supported", {
        description: "Contact Picker API is not supported on this device/browser."
      });
      return;
    }
    
    setIsInteractingWithSystem(true);
    setIsSyncing(true);
    try {
      // Temporarily disable privacy screen to avoid blackout during contact picker prompt
      if (isNative) {
        await PrivacyScreen.disable().catch(console.error);
      }

      const props = ["name", "tel"];
      const opts = { multiple: true };
      const contacts = await (navigator as any).contacts.select(props, opts);
      
      if (contacts.length > 0) {
        const matched: any[] = [];
        const seenUids = new Set<string>();

        for (const contact of contacts) {
          if (contact.tel && contact.tel.length > 0) {
            let foundMatch = false;
            for (const tel of contact.tel) {
              if (foundMatch) break;

              const rawNum = tel.replace(/\D/g, "");
              if (rawNum.length < 10) continue;

              // Try different variations (e.g., with/without leading 1 for US)
              const variations = [rawNum];
              if (rawNum.length === 11 && rawNum.startsWith("1")) {
                variations.push(rawNum.substring(1));
              } else if (rawNum.length === 10) {
                variations.push("1" + rawNum);
              }

              for (const num of variations) {
                try {
                  const lookupDoc = await getDoc(doc(db, "phone_lookup", num));
                  if (lookupDoc.exists()) {
                    const uid = lookupDoc.data().uid;
                    
                    // Don't add yourself or duplicates
                    if (uid === user?.uid || seenUids.has(uid)) {
                      foundMatch = true;
                      break;
                    }

                    const userDoc = await getDoc(doc(db, "users", uid));
                    if (userDoc.exists()) {
                      matched.push({
                        ...userDoc.data(),
                        contactName: contact.name?.[0] || "Unknown"
                      });
                      seenUids.add(uid);
                      foundMatch = true;
                      break; 
                    }
                  }
                } catch (error) {
                  console.error("Error looking up phone:", error);
                }
              }
            }
          }
        }
        setSyncedContacts(matched);
        if (matched.length === 0) {
          toast.info("No contacts found on Ghozt", {
            description: "Invite your friends to join the Ghozt network!"
          });
        } else {
          toast.success(`Found ${matched.length} contacts on Ghozt!`);
        }
      }
    } catch (error) {
      console.error("Error syncing contacts:", error);
      toast.error("Sync Failed", {
        description: "Could not access your contacts. Please check permissions."
      });
    } finally {
      setIsSyncing(false);
      setIsInteractingWithSystem(false);
    }
  };

  const addContact = async (contactUser: any) => {
    if (!user) return;
    try {
      await setDoc(doc(db, "users", user.uid, "contacts", contactUser.uid), {
        uid: contactUser.uid,
        displayName: contactUser.displayName,
        photoURL: contactUser.photoURL || null,
        addedAt: Date.now()
      });
      toast.success(`Added ${contactUser.displayName} to contacts!`);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}/contacts/${contactUser.uid}`);
    }
  };

  const createGroup = async () => {
    if (!user || !newGroupName.trim()) return;
    
    const groupId = `group-${Date.now()}`;
    const newGroup: Group = {
      id: groupId,
      name: newGroupName.trim(),
      createdBy: user.uid,
      createdAt: Date.now(),
      members: [user.uid, ...selectedGroupMembers]
    };

    try {
      await setDoc(doc(db, "groups", groupId), newGroup);
      setNewGroupName("");
      setSelectedGroupMembers([]);
      setShowCreateGroup(false);
      setCurrentRoomId(groupId);
      toast.success(`Group "${newGroup.name}" created!`);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `groups/${groupId}`);
    }
  };

  const inviteToGroup = async (groupId: string, userIds: string[]) => {
    if (!user) return;
    const group = groups.find(g => g.id === groupId);
    if (!group) return;

    const newMembers = [...new Set([...group.members, ...userIds])];
    try {
      await setDoc(doc(db, "groups", groupId), { members: newMembers }, { merge: true });
      toast.success("Members invited!");
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `groups/${groupId}`);
    }
  };

  const leaveGroup = async (groupId: string) => {
    if (!user) return;
    const group = groups.find(g => g.id === groupId);
    if (!group) return;

    const newMembers = group.members.filter(id => id !== user.uid);
    try {
      if (newMembers.length === 0) {
        await deleteDoc(doc(db, "groups", groupId));
      } else {
        await setDoc(doc(db, "groups", groupId), { members: newMembers }, { merge: true });
      }
      setCurrentRoomId("global-chat");
      setShowGroupSettings(false);
      toast.success(`Left group "${group.name}"`);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `groups/${groupId}`);
    }
  };

  const takePhoto = async () => {
    try {
      setIsInteractingWithSystem(true);
      // Temporarily disable privacy screen to avoid blackout during camera/gallery prompt
      if (isNative) {
        await PrivacyScreen.disable().catch(console.error);
        // Small delay to ensure the flag is cleared
        await new Promise(resolve => setTimeout(resolve, 150));
      }

      const image = await Camera.getPhoto({
        quality: 80,
        allowEditing: false,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Prompt // Allows choosing from gallery or camera
      });
      
      if (image.dataUrl) {
        setCapturedImage(image.dataUrl);
      }
    } catch (error) {
      console.error("Error taking photo:", error);
    } finally {
      setIsInteractingWithSystem(false);
    }
  };

  const triggerFileSelect = async () => {
    setIsInteractingWithSystem(true);
    if (isNative) {
      await PrivacyScreen.disable().catch(console.error);
    }
    // Small delay to ensure the flag is cleared before the system dialog opens
    setTimeout(() => {
      fileInputRef.current?.click();
    }, 150);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    setIsInteractingWithSystem(false);
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (file.size > 800000) { // ~800KB limit for base64 in Firestore
      toast.error("File Too Large", {
        description: "Please select a file under 800KB."
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      
      // If it's an image, treat it as a captured image for preview
      if (file.type.startsWith('image/')) {
        setCapturedImage(base64);
        setSelectedFile(null);
      } else {
        setSelectedFile({
          url: base64,
          name: file.name,
          type: file.type || "unknown"
        });
        setCapturedImage(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const sendMessage = async () => {
    try {
      const textToSend = inputText.trim();
      const imageToSend = capturedImage;
      const fileToSend = selectedFile;
      
      if (!textToSend && !imageToSend && !fileToSend) return;
      if (!user) return;

      const timestamp = Date.now();
      const duration = timerSeconds * 1000;
      // Fallback expiration if never opened (24 hours)
      const expiresAt = timestamp + 86400000;

      const newMessage: any = {
        senderId: user.uid,
        senderName: user.displayName || "Anonymous",
        timestamp,
        duration,
        expiresAt,
        roomId: currentRoomId,
      };

      if (textToSend) newMessage.text = textToSend;
      if (imageToSend) newMessage.imageUrl = imageToSend;
      if (fileToSend) {
        newMessage.fileUrl = fileToSend.url;
        newMessage.fileName = fileToSend.name;
        newMessage.fileType = fileToSend.type;
      }

      setInputText("");
      setCapturedImage(null);
      setSelectedFile(null);
      
      await addDoc(collection(db, "messages"), newMessage);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "messages");
    }
  };

  const removeMessage = async (id: string) => {
    try {
      await deleteDoc(doc(db, "messages", id));
      setMessages((prev) => prev.filter((m) => m.id !== id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `messages/${id}`);
    }
  };

  if (showSplash) {
    return (
      <ErrorBoundary>
        <AnimatePresence mode="wait">
          <SplashScreen key="splash" onFinish={() => setShowSplash(false)} />
        </AnimatePresence>
      </ErrorBoundary>
    );
  }

  if (loading) {
    return (
      <ErrorBoundary>
        <div className="min-h-screen bg-[#0f0f0f] flex flex-col items-center justify-center">
          <img 
            src="/logo.jpg" 
            alt="Ghozt" 
            className="w-16 h-16 object-contain rounded-full animate-pulse drop-shadow-[0_0_10px_rgba(0,229,255,0.5)] mb-8"
            referrerPolicy="no-referrer"
            onError={(e) => {
              (e.target as HTMLImageElement).src = "/icon.svg";
            }}
          />
          <button 
            onClick={() => setLoading(false)}
            className="text-white/20 text-xs hover:text-white/40 transition-colors"
          >
            Taking too long? Click to force load
          </button>
        </div>
      </ErrorBoundary>
    );
  }

  if (!user) {
    return (
      <ErrorBoundary>
        <div className={cn(
          "min-h-screen bg-Ghozt-bg flex flex-col items-center justify-center p-6 text-center relative overflow-hidden screenshot-protection",
          isBlurred && "blurred pointer-events-none"
        )}>
        {/* Background Glows */}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-Ghozt-purple/20 blur-[100px] rounded-full" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-Ghozt-cyan/10 blur-[100px] rounded-full" />

        <div className="w-32 h-32 mb-8 relative z-10 group">
          <div className="absolute inset-0 bg-Ghozt-purple/30 blur-2xl rounded-full group-hover:bg-Ghozt-cyan/30 transition-all duration-700" />
          <img 
            src="/logo.jpg" 
            alt="Ghozt Logo" 
            className="w-full h-full object-contain rounded-full relative z-10 drop-shadow-[0_0_15px_rgba(157,80,187,0.5)]"
            referrerPolicy="no-referrer"
            onError={(e) => {
              // Fallback if logo.png is not found
              (e.target as HTMLImageElement).src = "/icon.svg";
            }}
          />
        </div>
        <h1 className="text-5xl md:text-6xl font-black tracking-tighter mb-4 text-glow-cyan relative z-10">GHOZT</h1>
        <p className="text-white/60 text-sm md:text-base max-w-xs mb-12 font-medium relative z-10">Secure, ephemeral messaging. Messages disappear forever in seconds.</p>
        
        <div className="w-full max-w-xs flex flex-col gap-4 relative z-10">
          <button 
            onClick={handleLogin}
            className="w-full py-4 bg-Ghozt-cyan text-black font-black uppercase tracking-widest text-xs rounded-2xl flex items-center justify-center gap-3 hover:bg-white transition-all glow-cyan"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Continue with Google
          </button>

          <div className="flex items-center gap-4 my-2 opacity-20">
            <div className="h-px flex-1 bg-white" />
            <span className="text-[10px] font-bold uppercase tracking-widest">or</span>
            <div className="h-px flex-1 bg-white" />
          </div>

          {!isOtpSent ? (
            <div className="flex flex-col gap-3">
              <div className="relative">
                <input 
                  type="tel"
                  placeholder="+1 234 567 8900"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full bg-Ghozt-purple/5 border border-Ghozt-purple/20 rounded-2xl py-4 px-6 text-sm focus:outline-none focus:border-Ghozt-cyan/40 transition-colors text-white placeholder:text-white/20"
                />
                <Smartphone size={18} className="absolute right-6 top-1/2 -translate-y-1/2 text-Ghozt-cyan/40" />
              </div>
              <button 
                onClick={handlePhoneLogin}
                disabled={!phoneNumber.trim()}
                className="w-full py-4 bg-Ghozt-purple/10 border border-Ghozt-purple/20 text-Ghozt-cyan font-bold rounded-2xl flex items-center justify-center gap-3 hover:bg-Ghozt-purple/20 transition-colors disabled:opacity-50"
              >
                Send Code
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              <div className="relative">
                <input 
                  type="text"
                  placeholder="Enter 6-digit code"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  className="w-full bg-Ghozt-purple/5 border border-Ghozt-purple/20 rounded-2xl py-4 px-6 text-sm focus:outline-none focus:border-Ghozt-cyan/40 transition-colors text-center tracking-[0.5em] font-mono text-white"
                  maxLength={6}
                />
              </div>
              <button 
                onClick={handleVerifyOtp}
                disabled={otp.length !== 6}
                className="w-full py-4 bg-Ghozt-cyan text-black font-black uppercase tracking-widest text-xs rounded-2xl flex items-center justify-center gap-3 hover:bg-white transition-all glow-cyan"
              >
                Verify & Login
              </button>
              <button 
                onClick={() => setIsOtpSent(false)}
                className="text-[10px] font-bold uppercase tracking-widest text-Ghozt-cyan/60 hover:text-Ghozt-cyan transition-colors"
              >
                Change Phone Number
              </button>
            </div>
          )}
        </div>

        {authError && (
          <p className="mt-4 text-xs text-Ghozt-pink font-bold max-w-xs relative z-10">{authError}</p>
        )}

        <div id="recaptcha-container" ref={recaptchaRef}></div>

        <div className="mt-12 flex flex-col gap-4 text-[10px] uppercase tracking-widest font-bold text-white/20 relative z-10">
          <div className="flex items-center gap-2">
            <Shield size={12} className="text-Ghozt-cyan" />
            <span>End-to-End Encrypted</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock size={12} className="text-Ghozt-purple" />
            <span>Timed Disappearance</span>
          </div>
        </div>

        {/* Pre-Screenshot Warning Banner */}
        <AnimatePresence>
          {showPreScreenshotWarning && !showScreenshotWarning && (
            <motion.div
              initial={{ y: -100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -100, opacity: 0 }}
              className="fixed top-6 left-1/2 -translate-x-1/2 z-[60] w-[90%] max-w-xs"
            >
              <div className="bg-Ghozt-pink/90 backdrop-blur-xl border border-Ghozt-pink/30 rounded-2xl p-4 flex items-center gap-4 shadow-2xl glow-pink">
                <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center shrink-0">
                  <Shield size={20} className="text-white animate-pulse" />
                </div>
                <div className="flex-1">
                  <p className="text-[10px] font-black uppercase tracking-widest text-white/60 mb-0.5">Security Alert</p>
                  <p className="text-xs font-bold text-white leading-tight">Screenshotting is prohibited. Attempts are logged.</p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Screenshot Warning Overlay */}
        <AnimatePresence>
          {(isBlurred || showScreenshotWarning) && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                if (showScreenshotWarning) {
                  setShowScreenshotWarning(false);
                  setIsBlurred(false);
                  document.body.classList.remove("blurred");
                }
              }}
              className={cn(
                "fixed inset-0 z-50 flex items-center justify-center bg-white/98 backdrop-blur-2xl cursor-pointer",
                showScreenshotWarning && "cursor-pointer"
              )}
            >
              <div className="absolute inset-0 z-0">
                <RippleOverlay isWarning={showScreenshotWarning} />
              </div>
              <div className="relative z-10 text-center p-8 max-w-xs">
                <div className={cn(
                  "w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 border rotate-12 transition-all duration-500 shadow-xl",
                  showScreenshotWarning 
                    ? "bg-Ghozt-pink/10 border-Ghozt-pink/40" 
                    : "bg-Ghozt-purple/10 border-Ghozt-purple/40"
                )}>
                  {showScreenshotWarning ? (
                    <AlertCircle size={40} className="text-Ghozt-pink animate-pulse" />
                  ) : (
                    <Shield size={40} className="text-Ghozt-cyan" />
                  )}
                </div>
                <h2 className={cn(
                  "text-4xl font-black tracking-tighter mb-2 uppercase italic",
                  showScreenshotWarning ? "text-Ghozt-pink drop-shadow-[0_0_15px_rgba(255,68,104,0.5)]" : "text-Ghozt-purple"
                )}>
                  {showScreenshotWarning ? "Breach Detected" : "Protected"}
                </h2>
                <p className="text-sm text-black/60 font-bold leading-relaxed uppercase tracking-tighter">
                  {showScreenshotWarning 
                    ? "Unauthorized screenshot attempt identified. Protocol restricted." 
                    : "Privacy mode active. Content is hidden for your security."}
                </p>
                
                {showScreenshotWarning && (
                  <div className="mt-8 px-4 py-2 bg-Ghozt-pink/10 border border-Ghozt-pink/20 rounded-full inline-flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-Ghozt-pink rounded-full animate-ping" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-Ghozt-pink">Security Alert Level 5</span>
                  </div>
                )}
                
                {!showScreenshotWarning && (
                  <div className="mt-8 flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-widest text-Ghozt-purple/40">
                    <div className="w-1 h-1 bg-Ghozt-purple/60 rounded-full animate-ping" />
                    <span>Waiting for focus...</span>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <div 
        className={cn(
          "min-h-screen flex flex-col w-full max-w-lg mx-auto md:border-x border-white/5 bg-black screenshot-protection select-none",
          isBlurred && "blurred pointer-events-none"
        )}
      >
        <Toaster 
          theme="dark" 
          position="top-center" 
          toastOptions={{
            style: {
              background: '#0a0a0a',
              border: '1px solid rgba(139, 92, 246, 0.2)',
              color: '#fff',
              borderRadius: '16px',
              fontFamily: 'inherit'
            }
          }}
        />
      {/* Header */}
      <header className="p-4 md:p-6 flex items-center justify-between border-b border-Ghozt-purple/10 sticky top-0 bg-Ghozt-bg/80 backdrop-blur-xl z-10">
        <div className="flex items-center gap-2 md:gap-3">
          <div className="w-8 h-8 md:w-10 md:h-10">
            <img 
              src="/logo.jpg" 
              alt="Ghozt" 
              className="w-full h-full object-contain rounded-full drop-shadow-[0_0_8px_rgba(0,229,255,0.4)]"
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.target as HTMLImageElement).src = "/icon.svg";
              }}
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5 md:gap-2">
              <h1 className="text-lg md:text-xl font-black tracking-tighter text-glow-cyan">GHOZT</h1>
              {isPremium && (
                <span className="px-1 py-0.5 md:px-1.5 md:py-0.5 bg-Ghozt-pink text-white text-[7px] md:text-[8px] font-black uppercase tracking-tighter rounded glow-pink">Pro</span>
              )}
              {effectiveUserProfile && (
                <div className="flex items-center gap-1 px-1 py-0.5 md:px-1.5 md:py-0.5 bg-white/5 rounded border border-white/10">
                  <Shield className={cn(
                    "w-1.5 h-1.5 md:w-2 md:h-2",
                    (effectiveUserProfile.trustScore ?? 100) > 70 ? "text-green-400" : 
                    (effectiveUserProfile.trustScore ?? 100) > 40 ? "text-yellow-400" : "text-red-400"
                  )} />
                  <span className="text-[7px] md:text-[8px] font-bold text-white/60">{(effectiveUserProfile.trustScore ?? 100)}%</span>
                </div>
              )}
              <div className="hidden xs:flex items-center gap-1 px-1 py-0.5 md:px-1.5 md:py-0.5 bg-Ghozt-cyan/10 rounded border border-Ghozt-cyan/20">
                <div className="w-1 h-1 bg-Ghozt-cyan rounded-full animate-pulse" />
                <span className="text-[7px] md:text-[8px] font-bold text-Ghozt-cyan uppercase tracking-tighter">Secure</span>
              </div>
            </div>
            <div className="flex items-center gap-1 md:gap-1.5">
              <div className="w-1 h-1 md:w-1.5 md:h-1.5 bg-green-500 rounded-full animate-pulse" />
              <span className="text-[8px] md:text-[10px] uppercase tracking-widest text-white/40 font-bold">
                {currentRoomId === "global-chat" ? "Live" : "Private"}
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1 md:gap-2">
          <div className="hidden sm:flex flex-col items-end mr-2">
            <span className="text-[8px] font-black uppercase tracking-tighter text-white/20">Room</span>
            <span className="text-[10px] font-bold text-Ghozt-cyan truncate max-w-[80px]">
              {currentRoomId === "global-chat" ? "Global" : effectiveGroups.find(g => g.id === currentRoomId)?.name}
            </span>
          </div>
          <button 
            onClick={() => setIsChatBlurred(!isChatBlurred)}
            className={cn(
              "p-1.5 md:p-2 hover:bg-white/10 rounded-full transition-colors relative",
              isChatBlurred ? "text-Ghozt-pink" : "text-white/60"
            )}
            title={isChatBlurred ? "Stealth Mode Active" : "Enable Stealth Mode"}
          >
            {isChatBlurred ? <EyeOff size={18} className="md:w-5 md:h-5" /> : <Eye size={18} className="md:w-5 md:h-5" />}
          </button>
          <button 
            onClick={() => setShowThemeSelector(true)}
            className="p-1.5 md:p-2 hover:bg-white/10 rounded-full transition-colors text-white/60"
          >
            <Palette size={18} className="md:w-5 md:h-5" />
          </button>
          {currentRoomId !== "global-chat" && effectiveGroups.some(g => g.id === currentRoomId) && (
            <button 
              onClick={() => setShowGroupSettings(true)}
              className="p-1.5 md:p-2 hover:bg-white/10 rounded-full transition-colors text-Ghozt-purple"
              title="Group Settings"
            >
              <ShieldCheck size={18} className="md:w-5 md:h-5" />
            </button>
          )}
          <button 
            onClick={() => setShowContacts(true)}
            className="p-1.5 md:p-2 hover:bg-white/10 rounded-full transition-colors text-white/60 relative"
          >
            <User size={18} className="md:w-5 md:h-5" />
            {(effectiveOnlineUsers.length > 0 || effectiveGroups.length > 0) && (
              <span className="absolute top-1 right-1 w-1.5 h-1.5 md:w-2 md:h-2 bg-green-500 rounded-full border-2 border-black" />
            )}
          </button>
          <button 
            onClick={requestNotificationPermission}
            className={cn(
              "p-1.5 md:p-2 hover:bg-white/10 rounded-full transition-colors relative",
              notificationPermission === "granted" ? "text-Ghozt-cyan" : "text-white/40"
            )}
            title={notificationPermission === "granted" ? "Notifications Enabled" : "Enable Notifications"}
          >
            {notificationPermission === "granted" ? <Bell size={18} className="md:w-5 md:h-5" /> : <BellOff size={18} className="md:w-5 md:h-5" />}
          </button>
          <button 
            onClick={handleLogout}
            className="p-1.5 md:p-2 hover:bg-white/10 rounded-full transition-colors text-white/60"
          >
            <LogOut size={18} className="md:w-5 md:h-5" />
          </button>
        </div>
      </header>

      {/* Chat Area */}
      <main 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 md:p-6 flex flex-col scroll-smooth"
      >
        {!isPremium && !isNative && <AdBanner onRemoveAds={handleUpgrade} />}

        <div className="flex flex-col gap-2 mb-8">
          <div className="flex items-center gap-2 text-white/20 mb-4">
            <div className="h-px flex-1 bg-white/5" />
            <span className="text-[10px] font-bold uppercase tracking-widest">
              {currentRoomId === "global-chat" ? "Global Chat" : effectiveGroups.find(g => g.id === currentRoomId)?.name}
            </span>
            <div className="h-px flex-1 bg-white/5" />
          </div>
          
          <div className="flex flex-col">
            <AnimatePresence mode="popLayout">
              {effectiveMessages.map((msg) => (
                <MessageBubble 
                  key={msg.id} 
                  message={msg} 
                  onExpire={removeMessage} 
                  isChatBlurred={isChatBlurred}
                />
              ))}
            </AnimatePresence>
            <AnimatePresence>
              {Object.keys(typingUsers).length > 0 && (
                <TypingIndicator users={typingUsers} />
              )}
            </AnimatePresence>
          </div>
        </div>

        {effectiveMessages.length === 0 && (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-12 opacity-20">
            <img 
              src="/icon.svg" 
              alt="No messages" 
              className="w-16 h-16 mb-4 object-contain"
              referrerPolicy="no-referrer"
            />
            <p className="text-sm font-medium">No active messages</p>
            <p className="text-xs mt-1">Be the first to send a Ghozt</p>
          </div>
        )}
      </main>

      {/* Input Area */}
      <footer className="p-4 md:p-6 bg-Ghozt-bg border-t border-Ghozt-purple/10">
        {(capturedImage || selectedFile) && (
          <div className="mb-4 relative inline-block">
            <div className="w-20 h-20 md:w-24 md:h-24 rounded-2xl overflow-hidden border-2 border-Ghozt-cyan glow-cyan flex items-center justify-center bg-Ghozt-purple/5">
              {capturedImage ? (
                <img src={capturedImage} alt="Preview" className="w-full h-full object-cover" />
              ) : (
                <div className="flex flex-col items-center justify-center p-2 text-center">
                  <FileText size={28} className="text-Ghozt-cyan mb-1" />
                  <p className="text-[7px] md:text-[8px] font-bold truncate w-full">{selectedFile?.name}</p>
                </div>
              )}
            </div>
            <button 
              onClick={() => {
                setCapturedImage(null);
                setSelectedFile(null);
              }}
              className="absolute -top-2 -right-2 w-6 h-6 bg-Ghozt-pink text-white rounded-full flex items-center justify-center border-2 border-Ghozt-bg"
            >
              <X size={12} />
            </button>
          </div>
        )}

        <div className="flex items-center gap-1.5 md:gap-2 mb-4 overflow-x-auto pb-2 no-scrollbar">
          {[5, 10, 30, 60, 300].map((s) => (
            <button
              key={s}
              onClick={() => setTimerSeconds(s)}
              className={cn(
                "px-2.5 py-1 md:px-3 md:py-1.5 rounded-full text-[9px] md:text-[10px] font-bold uppercase tracking-widest transition-all whitespace-nowrap",
                timerSeconds === s 
                  ? "bg-Ghozt-cyan text-black glow-cyan" 
                  : "bg-Ghozt-purple/10 text-white/40 hover:text-white/60 border border-Ghozt-purple/20"
              )}
            >
              {s < 60 ? `${s}s` : `${s/60}m`}
            </button>
          ))}
          <div className="ml-auto flex items-center gap-1 text-[9px] md:text-[10px] font-bold text-Ghozt-cyan/40 uppercase tracking-widest">
            <Clock size={10} />
            <span className="hidden xs:inline">Timer</span>
          </div>
        </div>

        <div className="relative flex items-center gap-2">
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            onChange={handleFileSelect}
          />
          <button
            onClick={takePhoto}
            className="w-11 h-11 md:w-14 md:h-14 bg-white/5 text-Ghozt-cyan rounded-2xl flex items-center justify-center hover:bg-white/10 hover:border-Ghozt-cyan/30 transition-all duration-300 border border-white/10 shrink-0 active:scale-90 group"
          >
            <CameraIcon size={20} className="md:w-6 md:h-6 group-hover:scale-110 transition-transform" />
          </button>
          <div className="flex-1 relative group">
            <input
              type="text"
              value={inputText}
              onChange={(e) => {
                setInputText(e.target.value);
                handleTyping(e.target.value.length > 0);
              }}
              onBlur={() => handleTyping(false)}
              onKeyPress={(e) => e.key === "Enter" && sendMessage()}
              placeholder={capturedImage || selectedFile ? "Add a caption..." : "Send a Ghozt..."}
              className="w-full bg-white/5 border border-white/10 rounded-2xl py-3.5 md:py-4.5 pl-5 md:pl-7 pr-12 md:pr-14 text-sm md:text-base focus:outline-none focus:border-Ghozt-cyan/50 focus:ring-4 focus:ring-Ghozt-cyan/5 transition-all duration-300 text-white placeholder:text-white/20 hover:bg-white/10 hover:border-white/20"
            />
            <button 
              onClick={triggerFileSelect}
              className="absolute right-4 md:right-5 top-1/2 -translate-y-1/2 text-white/20 hover:text-Ghozt-cyan transition-all duration-300 hover:scale-110"
            >
              <Paperclip size={20} className="md:w-6 md:h-6" />
            </button>
          </div>
          <button
            onClick={sendMessage}
            disabled={!inputText.trim() && !capturedImage && !selectedFile}
            className="w-11 h-11 md:w-14 md:h-14 bg-Ghozt-cyan text-black rounded-2xl flex items-center justify-center hover:bg-white hover:scale-105 active:scale-90 transition-all duration-300 glow-cyan disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:scale-100 disabled:glow-none shrink-0 group"
          >
            <Send size={20} className="md:w-6 md:h-6 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </button>
        </div>
        
        <div className="mt-4 flex items-center justify-center gap-4 text-[10px] uppercase tracking-widest font-bold text-white/20">
          <div className="flex items-center gap-1">
            <Clock size={10} className="text-Ghozt-cyan" />
            <span>{timerSeconds}s Expiry</span>
          </div>
          <div className="flex items-center gap-1">
            <Shield size={10} className="text-Ghozt-purple" />
            <span>Screenshot deterrent active</span>
          </div>
        </div>
      </footer>

      {/* Screenshot Warning Overlay */}
      <AnimatePresence>
        {(isBlurred || showScreenshotWarning) && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              if (showScreenshotWarning) {
                setShowScreenshotWarning(false);
                setIsBlurred(false);
                document.body.classList.remove("blurred");
              }
            }}
            className={cn(
              "fixed inset-0 z-50 flex items-center justify-center bg-white/98 backdrop-blur-2xl cursor-pointer",
              showScreenshotWarning && "cursor-pointer"
            )}
          >
            <div className="absolute inset-0 z-0">
              <RippleOverlay isWarning={showScreenshotWarning} />
            </div>
            <div className="relative z-10 text-center p-8 max-w-xs">
              <div className={cn(
                "w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 border rotate-12 transition-all duration-500 shadow-xl",
                showScreenshotWarning 
                  ? "bg-Ghozt-pink/10 border-Ghozt-pink/40" 
                  : "bg-Ghozt-purple/10 border-Ghozt-purple/40"
              )}>
                {showScreenshotWarning ? (
                  <AlertCircle size={40} className="text-Ghozt-pink animate-pulse" />
                ) : (
                  <Shield size={40} className="text-Ghozt-cyan" />
                )}
              </div>
              <h2 className={cn(
                "text-4xl font-black tracking-tighter mb-2 uppercase italic",
                showScreenshotWarning ? "text-Ghozt-pink drop-shadow-[0_0_15px_rgba(255,68,104,0.5)]" : "text-Ghozt-purple"
              )}>
                {showScreenshotWarning ? "Breach Detected" : "Protected"}
              </h2>
              <p className="text-sm text-black/60 font-bold leading-relaxed uppercase tracking-tighter">
                {showScreenshotWarning 
                  ? "Unauthorized screenshot attempt identified. Protocol restricted." 
                  : "Privacy mode active. Content is hidden for your security."}
              </p>
              
              {showScreenshotWarning && (
                <div className="mt-8 px-4 py-2 bg-Ghozt-pink/10 border border-Ghozt-pink/20 rounded-full inline-flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-Ghozt-pink rounded-full animate-ping" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-Ghozt-pink">Security Alert Level 5</span>
                </div>
              )}
              
              {!showScreenshotWarning && (
                <div className="mt-8 flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-widest text-Ghozt-purple/40">
                  <div className="w-1 h-1 bg-Ghozt-purple/60 rounded-full animate-ping" />
                  <span>Waiting for focus...</span>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Theme Selector Modal */}
      <AnimatePresence>
        {showThemeSelector && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowThemeSelector(false)}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[60]"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] max-w-sm bg-zinc-950 border border-white/10 rounded-3xl p-6 md:p-8 z-[70] shadow-2xl"
            >
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-2xl font-black tracking-tighter uppercase text-glow-cyan">Spectral Settings</h2>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">Configure your apparition</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setIsScreenshotMode(!isScreenshotMode);
                      toast.info(isScreenshotMode ? "Screenshot Mode Disabled" : "Screenshot Mode Enabled", {
                        description: isScreenshotMode ? "Returning to live data." : "Showing high-quality fake data for screenshots."
                      });
                    }}
                    className={cn(
                      "p-2 rounded-full transition-all duration-300",
                      isScreenshotMode ? "bg-Ghozt-cyan text-black shadow-[0_0_15px_rgba(0,229,255,0.5)]" : "bg-white/5 text-white/40 hover:text-white"
                    )}
                    title="Toggle Screenshot Mode"
                  >
                    <CameraIcon size={20} />
                  </button>
                  <button 
                    onClick={() => setShowThemeSelector(false)}
                    className="p-2 hover:bg-white/5 rounded-full transition-colors text-white/40"
                  >
                    <X size={20} />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {[
                  { id: 'phantom', name: 'Neon Phantom', icon: Zap, color: 'text-Ghozt-cyan', bg: 'bg-Ghozt-cyan/10' },
                  { id: 'void', name: 'Deep Void', icon: Moon, color: 'text-white', bg: 'bg-white/10' },
                  { id: 'mist', name: 'Ethereal Mist', icon: Cloud, color: 'text-Ghozt-purple', bg: 'bg-Ghozt-purple/10' },
                  { id: 'solar', name: 'Solar Flare', icon: Sun, color: 'text-orange-500', bg: 'bg-orange-500/10' },
                ].map((theme) => (
                  <button
                    key={theme.id}
                    onClick={() => handleThemeChange(theme.id)}
                    className={cn(
                      "flex flex-col items-center gap-3 p-6 rounded-2xl border transition-all duration-300 group",
                      currentTheme === theme.id 
                        ? "bg-white/5 border-Ghozt-cyan shadow-[0_0_15px_rgba(0,229,255,0.2)]" 
                        : "bg-transparent border-white/5 hover:border-white/20"
                    )}
                  >
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center transition-transform group-hover:scale-110",
                      theme.bg,
                      theme.color
                    )}>
                      <theme.icon size={24} />
                    </div>
                    <span className={cn(
                      "text-[10px] font-bold uppercase tracking-widest",
                      currentTheme === theme.id ? "text-white" : "text-white/40"
                    )}>
                      {theme.name}
                    </span>
                  </button>
                ))}
              </div>

              <div className="mt-8 pt-8 border-t border-white/5 space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-black tracking-tighter uppercase text-white/60">Privacy Cloak</h3>
                    <p className="text-[10px] font-bold uppercase tracking-widest text-white/20">Hide your presence</p>
                  </div>
                  <button
                    onClick={async () => {
                      if (!user) return;
                      const newStatus = !effectiveUserProfile?.isInvisible;
                      try {
                        await setDoc(doc(db, "users", user.uid), { 
                          uid: user.uid,
                          displayName: user.displayName || "Anonymous",
                          photoURL: user.photoURL,
                          isInvisible: newStatus,
                          // If going invisible, set isOnline to false immediately for others
                          isOnline: !newStatus 
                        }, { merge: true });
                        toast.success(newStatus ? "Cloak Activated" : "Cloak Deactivated", {
                          description: newStatus ? "You are now invisible to others." : "Your online status is now visible.",
                          icon: newStatus ? <EyeOff className="w-4 h-4 text-Ghozt-purple" /> : <Eye className="w-4 h-4 text-Ghozt-cyan" />
                        });
                      } catch (error) {
                        handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
                      }
                    }}
                    className={cn(
                      "flex items-center gap-2 px-4 py-2 rounded-xl border transition-all duration-300",
                      effectiveUserProfile?.isInvisible 
                        ? "bg-Ghozt-purple/10 border-Ghozt-purple text-Ghozt-purple shadow-[0_0_15px_rgba(139,92,246,0.2)]" 
                        : "bg-white/5 border-white/5 text-white/40 hover:border-white/20"
                    )}
                  >
                    {effectiveUserProfile?.isInvisible ? <EyeOff size={16} /> : <Eye size={16} />}
                    <span className="text-[10px] font-black uppercase tracking-widest">
                      {effectiveUserProfile?.isInvisible ? "Invisible" : "Visible"}
                    </span>
                  </button>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-black tracking-tighter uppercase text-white/60">Stealth Mode</h3>
                    <p className="text-[10px] font-bold uppercase tracking-widest text-white/20">Blur messages until clicked</p>
                  </div>
                  <button
                    onClick={() => {
                      const newState = !isChatBlurred;
                      setIsChatBlurred(newState);
                      toast.info(newState ? "Stealth Mode On" : "Stealth Mode Off", {
                        description: newState ? "Messages are now blurred for extra privacy." : "Messages are now visible by default.",
                        icon: newState ? <EyeOff className="w-4 h-4 text-Ghozt-pink" /> : <Eye className="w-4 h-4 text-Ghozt-cyan" />
                      });
                    }}
                    className={cn(
                      "flex items-center gap-2 px-4 py-2 rounded-xl border transition-all duration-300",
                      isChatBlurred 
                        ? "bg-Ghozt-pink/10 border-Ghozt-pink text-Ghozt-pink shadow-[0_0_15px_rgba(255,51,102,0.2)]" 
                        : "bg-white/5 border-white/5 text-white/40 hover:border-white/20"
                    )}
                  >
                    {isChatBlurred ? <EyeOff size={16} /> : <Eye size={16} />}
                    <span className="text-[10px] font-black uppercase tracking-widest">
                      {isChatBlurred ? "Active" : "Inactive"}
                    </span>
                  </button>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-black tracking-tighter uppercase text-white/60">Privacy Shield</h3>
                    <p className="text-[10px] font-bold uppercase tracking-widest text-white/20">Task switcher protection</p>
                  </div>
                  <button
                    onClick={() => {
                      const newState = !privacyEnabled;
                      setPrivacyEnabled(newState);
                      toast.info(newState ? "Shield Activated" : "Shield Deactivated", {
                        description: newState ? "App content is now hidden in task switcher." : "App content is now visible in task switcher.",
                        icon: newState ? <ShieldCheck className="w-4 h-4 text-Ghozt-cyan" /> : <ShieldAlert className="w-4 h-4 text-Ghozt-purple" />
                      });
                    }}
                    className={cn(
                      "flex items-center gap-2 px-4 py-2 rounded-xl border transition-all duration-300",
                      privacyEnabled 
                        ? "bg-Ghozt-cyan/10 border-Ghozt-cyan text-Ghozt-cyan shadow-[0_0_15px_rgba(0,229,255,0.2)]" 
                        : "bg-white/5 border-white/5 text-white/40 hover:border-white/20"
                    )}
                  >
                    {privacyEnabled ? <ShieldCheck size={16} /> : <ShieldAlert size={16} />}
                    <span className="text-[10px] font-black uppercase tracking-widest">
                      {privacyEnabled ? "Active" : "Inactive"}
                    </span>
                  </button>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-black tracking-tighter uppercase text-white/60">Security Shield</h3>
                    <p className="text-[10px] font-bold uppercase tracking-widest text-white/20">Test protection</p>
                  </div>
                  <button
                    onClick={() => {
                      setShowThemeSelector(false);
                      setTimeout(() => {
                        setShowScreenshotWarning(true);
                        setIsBlurred(true);
                        document.body.classList.add("blurred");
                        // Removed the auto-hide timer to make it "sticky"
                        toast.info("Sticky Warning Active. Click the screen to dismiss.", {
                          duration: 4000,
                          icon: <Shield className="text-Ghozt-pink" />
                        });
                      }, 300);
                    }}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl border border-Ghozt-pink/20 bg-Ghozt-pink/5 text-Ghozt-pink hover:bg-Ghozt-pink/10 transition-all duration-300"
                  >
                    <Shield size={16} />
                    <span className="text-[10px] font-black uppercase tracking-widest">
                      Sticky Warning UI
                    </span>
                  </button>
                </div>


                <div className="space-y-4 pt-4 border-t border-white/5">
                  <div className="flex items-center gap-2 mb-2">
                    <Bell size={12} className="text-Ghozt-cyan" />
                    <h3 className="text-xs font-black tracking-tighter uppercase text-white/60">Notification Alerts</h3>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">Master Switch</p>
                    </div>
                    <button
                      onClick={() => updateNotificationSettings({ global: !(effectiveUserProfile?.notificationSettings?.global ?? true) })}
                      className={cn(
                        "w-10 h-5 rounded-full relative transition-all duration-300",
                        (effectiveUserProfile?.notificationSettings?.global ?? true) ? "bg-Ghozt-cyan" : "bg-white/10"
                      )}
                    >
                      <div className={cn(
                        "absolute top-1 w-3 h-3 rounded-full bg-white transition-all duration-300",
                        (effectiveUserProfile?.notificationSettings?.global ?? true) ? "right-1" : "left-1"
                      )} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between opacity-80">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">Global Chat</p>
                    </div>
                    <button
                      disabled={!(effectiveUserProfile?.notificationSettings?.global ?? true)}
                      onClick={() => updateNotificationSettings({ globalChat: !(effectiveUserProfile?.notificationSettings?.globalChat ?? true) })}
                      className={cn(
                        "w-10 h-5 rounded-full relative transition-all duration-300",
                        (effectiveUserProfile?.notificationSettings?.globalChat ?? true) ? "bg-Ghozt-purple" : "bg-white/10",
                        !(effectiveUserProfile?.notificationSettings?.global ?? true) && "opacity-50 cursor-not-allowed"
                      )}
                    >
                      <div className={cn(
                        "absolute top-1 w-3 h-3 rounded-full bg-white transition-all duration-300",
                        (effectiveUserProfile?.notificationSettings?.globalChat ?? true) ? "right-1" : "left-1"
                      )} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between opacity-80">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">Group Messages</p>
                    </div>
                    <button
                      disabled={!(effectiveUserProfile?.notificationSettings?.global ?? true)}
                      onClick={() => updateNotificationSettings({ groups: !(effectiveUserProfile?.notificationSettings?.groups ?? true) })}
                      className={cn(
                        "w-10 h-5 rounded-full relative transition-all duration-300",
                        (effectiveUserProfile?.notificationSettings?.groups ?? true) ? "bg-Ghozt-purple" : "bg-white/10",
                        !(effectiveUserProfile?.notificationSettings?.global ?? true) && "opacity-50 cursor-not-allowed"
                      )}
                    >
                      <div className={cn(
                        "absolute top-1 w-3 h-3 rounded-full bg-white transition-all duration-300",
                        (effectiveUserProfile?.notificationSettings?.groups ?? true) ? "right-1" : "left-1"
                      )} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between opacity-80">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">Direct Messages</p>
                    </div>
                    <button
                      disabled={!(effectiveUserProfile?.notificationSettings?.global ?? true)}
                      onClick={() => updateNotificationSettings({ directMessages: !(effectiveUserProfile?.notificationSettings?.directMessages ?? true) })}
                      className={cn(
                        "w-10 h-5 rounded-full relative transition-all duration-300",
                        (effectiveUserProfile?.notificationSettings?.directMessages ?? true) ? "bg-Ghozt-purple" : "bg-white/10",
                        !(effectiveUserProfile?.notificationSettings?.global ?? true) && "opacity-50 cursor-not-allowed"
                      )}
                    >
                      <div className={cn(
                        "absolute top-1 w-3 h-3 rounded-full bg-white transition-all duration-300",
                        (effectiveUserProfile?.notificationSettings?.directMessages ?? true) ? "right-1" : "left-1"
                      )} />
                    </button>
                  </div>

                  {((effectiveUserProfile?.notificationSettings?.mutedGroups?.length || 0) > 0 || (effectiveUserProfile?.notificationSettings?.mutedContacts?.length || 0) > 0) && (
                    <div className="pt-4 space-y-2">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-white/20">Muted Chats</h4>
                      <div className="max-h-32 overflow-y-auto space-y-1 pr-2 custom-scrollbar">
                        {effectiveUserProfile?.notificationSettings?.mutedGroups?.map(groupId => {
                          const group = effectiveGroups.find(g => g.id === groupId);
                          return (
                            <div key={groupId} className="flex items-center justify-between p-2 rounded-lg bg-white/5">
                              <span className="text-[10px] font-bold truncate text-white/60">{group?.name || "Unknown Group"}</span>
                              <button onClick={() => toggleMuteGroup(groupId)} className="text-Ghozt-cyan hover:text-Ghozt-cyan/80">
                                <Bell size={10} />
                              </button>
                            </div>
                          );
                        })}
                        {effectiveUserProfile?.notificationSettings?.mutedContacts?.map(contactUid => {
                          const contact = effectiveContacts.find(c => c.uid === contactUid);
                          return (
                            <div key={contactUid} className="flex items-center justify-between p-2 rounded-lg bg-white/5">
                              <span className="text-[10px] font-bold truncate text-white/60">{contact?.displayName || "Unknown User"}</span>
                              <button onClick={() => toggleMuteContact(contactUid)} className="text-Ghozt-cyan hover:text-Ghozt-cyan/80">
                                <Bell size={10} />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-4 pt-4 border-t border-white/5">
                  <div className="flex items-center gap-2 mb-2">
                    <Shield size={12} className="text-Ghozt-cyan" />
                    <h3 className="text-xs font-black tracking-tighter uppercase text-white/60">Legal & Support</h3>
                  </div>
                  
                  <div className="grid grid-cols-1 gap-2">
                    <a 
                      href="https://Ghozt.app/privacy" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all group"
                    >
                      <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">Privacy Policy</span>
                      <ExternalLink size={12} className="text-white/20 group-hover:text-Ghozt-cyan transition-colors" />
                    </a>
                    <a 
                      href="https://Ghozt.app/terms" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all group"
                    >
                      <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">Terms of Service</span>
                      <ExternalLink size={12} className="text-white/20 group-hover:text-Ghozt-cyan transition-colors" />
                    </a>
                    <a 
                      href="mailto:support@Ghozt.app" 
                      className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all group"
                    >
                      <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">Contact Support</span>
                      <MessageSquare size={12} className="text-white/20 group-hover:text-Ghozt-cyan transition-colors" />
                    </a>
                    <button 
                      onClick={() => setShowOnboarding(true)}
                      className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all group"
                    >
                      <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">How it works</span>
                      <HelpCircle size={12} className="text-white/20 group-hover:text-Ghozt-cyan transition-colors" />
                    </button>
                  </div>
                </div>

                <div className="pt-8 border-t border-white/5">
                  <button 
                    onClick={() => setShowDeleteConfirm(true)}
                    className="w-full py-4 bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] font-black uppercase tracking-widest rounded-2xl hover:bg-red-500/20 transition-all flex items-center justify-center gap-2"
                  >
                    <Trash2 size={14} />
                    Delete Account
                  </button>
                  <p className="text-[8px] text-center text-white/20 uppercase tracking-widest mt-4 font-bold">
                    Warning: This action is irreversible.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowThemeSelector(false)}
                className="w-full mt-8 py-4 bg-white/5 hover:bg-white/10 text-white text-[10px] font-bold uppercase tracking-widest rounded-2xl transition-all"
              >
                Close
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Contacts Drawer */}
      <AnimatePresence>
        {showContacts && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowContacts(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              className="fixed right-0 top-0 bottom-0 w-full max-w-[280px] bg-zinc-950 border-l border-white/5 z-50 p-6 flex flex-col"
            >
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-xl font-bold tracking-tighter uppercase">Ghozt</h2>
                <button 
                  onClick={() => setShowContacts(false)}
                  className="p-2 hover:bg-white/5 rounded-full transition-colors"
                >
                  <Plus size={20} className="rotate-45" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-[10px] font-bold uppercase tracking-widest text-white/20">Rooms</h3>
                  <button 
                    onClick={() => setShowCreateGroup(true)}
                    className="p-1 hover:bg-white/5 rounded-md transition-colors text-Ghozt-cyan"
                  >
                    <Plus size={14} />
                  </button>
                </div>

                <div className="space-y-2 mb-8">
                  <button
                    onClick={() => {
                      setCurrentRoomId("global-chat");
                      setShowContacts(false);
                    }}
                    className={cn(
                      "w-full p-3 rounded-xl border flex items-center gap-3 transition-all",
                      currentRoomId === "global-chat" 
                        ? "bg-Ghozt-cyan/10 border-Ghozt-cyan text-Ghozt-cyan" 
                        : "bg-white/5 border-white/5 text-white/60 hover:bg-white/10"
                    )}
                  >
                    <MessageSquare size={16} />
                    <span className="text-xs font-bold">Global Chat</span>
                  </button>

                  {effectiveGroups.map((group) => {
                    const isMuted = effectiveUserProfile?.notificationSettings?.mutedGroups?.includes(group.id);
                    return (
                      <div key={group.id} className="group relative">
                        <button
                          onClick={() => {
                            setCurrentRoomId(group.id);
                            setShowContacts(false);
                          }}
                          className={cn(
                            "w-full p-3 rounded-xl border flex items-center gap-3 transition-all",
                            currentRoomId === group.id 
                              ? "bg-Ghozt-purple/10 border-Ghozt-purple text-Ghozt-purple" 
                              : "bg-white/5 border-white/5 text-white/60 hover:bg-white/10"
                          )}
                        >
                          <div className="w-5 h-5 rounded-lg bg-Ghozt-purple/20 flex items-center justify-center text-[8px] font-bold border border-Ghozt-purple/30">
                            {group.name[0].toUpperCase()}
                          </div>
                          <span className="text-xs font-bold truncate flex-1 text-left">{group.name}</span>
                          {isMuted && <BellOff size={10} className="text-white/20" />}
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleMuteGroup(group.id);
                          }}
                          className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 opacity-0 group-hover:opacity-100 hover:bg-white/10 rounded-lg transition-all"
                        >
                          {isMuted ? <Bell size={10} className="text-Ghozt-cyan" /> : <BellOff size={10} className="text-white/40" />}
                        </button>
                      </div>
                    );
                  })}
                </div>

                <div className="flex items-center justify-between mb-2 mt-6">
                  <h3 className="text-[10px] font-bold uppercase tracking-widest text-white/20">Direct Messages</h3>
                  <button 
                    onClick={() => setShowContacts(true)}
                    className="p-1 hover:bg-white/5 rounded-md transition-colors text-Ghozt-cyan"
                  >
                    <Plus size={14} />
                  </button>
                </div>

                <div className="space-y-2 mb-8">
                  {effectiveUserProfile?.directMessages?.map((contactUid) => {
                    const contact = effectiveContacts.find(c => c.uid === contactUid);
                    if (!contact) return null;
                    const roomId = [user?.uid, contactUid].sort().join("_");
                    const dmRoomId = `dm_${roomId}`;
                    const isMuted = effectiveUserProfile?.notificationSettings?.mutedContacts?.includes(contactUid);
                    
                    return (
                      <div key={contactUid} className="group relative">
                        <button
                          onClick={() => {
                            setCurrentRoomId(dmRoomId);
                            setShowContacts(false);
                          }}
                          className={cn(
                            "w-full p-3 rounded-xl border flex items-center gap-3 transition-all",
                            currentRoomId === dmRoomId 
                              ? "bg-Ghozt-cyan/10 border-Ghozt-cyan text-Ghozt-cyan" 
                              : "bg-white/5 border-white/5 text-white/60 hover:bg-white/10"
                          )}
                        >
                          <div className="w-5 h-5 rounded-full bg-Ghozt-cyan/20 flex items-center justify-center overflow-hidden border border-Ghozt-cyan/30">
                            {contact.photoURL ? <img src={contact.photoURL} alt="" className="w-full h-full object-cover" /> : <User size={10} />}
                          </div>
                          <span className="text-xs font-bold truncate flex-1 text-left">{contact.displayName}</span>
                          {isMuted && <BellOff size={10} className="text-white/20" />}
                        </button>
                        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleMuteContact(contactUid);
                            }}
                            className="p-1.5 hover:bg-white/10 rounded-lg transition-all"
                          >
                            {isMuted ? <Bell size={10} className="text-Ghozt-cyan" /> : <BellOff size={10} className="text-white/40" />}
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteDirectMessage(contactUid);
                            }}
                            className="p-1.5 hover:bg-white/10 rounded-lg transition-all text-red-500/60 hover:text-red-500"
                          >
                            <X size={10} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                  {(!effectiveUserProfile?.directMessages || effectiveUserProfile.directMessages.length === 0) && (
                    <p className="text-[10px] text-white/10 uppercase tracking-widest text-center py-4 border border-dashed border-white/5 rounded-xl">No active chats</p>
                  )}
                </div>

                {!isPremium && (
                  <button 
                    onClick={handleUpgrade}
                    disabled={isUpgrading}
                    className="w-full p-4 mb-2 bg-white text-black rounded-2xl flex items-center justify-between group hover:bg-zinc-200 transition-all disabled:opacity-50"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-black/5 rounded-lg flex items-center justify-center">
                        <Shield size={16} className="text-black/40" />
                      </div>
                      <div className="text-left">
                        <p className="text-[10px] font-black uppercase tracking-tighter">Premium</p>
                        <p className="text-xs font-bold">Remove Ads</p>
                      </div>
                    </div>
                    {isUpgrading ? (
                      <div className="w-4 h-4 border-2 border-black/20 border-t-black rounded-full animate-spin" />
                    ) : (
                      <Plus size={16} className="text-black/20 group-hover:text-black transition-colors" />
                    )}
                  </button>
                )}

                <button 
                  onClick={syncContacts}
                  disabled={isSyncing}
                  className="w-full p-4 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/5 flex items-center justify-center gap-3 transition-all active:scale-95 disabled:opacity-50"
                >
                  <Smartphone size={18} className={isSyncing ? "animate-bounce" : ""} />
                  <span className="text-sm font-bold tracking-tight">
                    {isSyncing ? "Syncing..." : "Sync Phone Contacts"}
                  </span>
                </button>

                {syncedContacts.length > 0 && (
                  <div className="pt-4 space-y-4">
                    <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-white/20">
                      <Check size={10} />
                      <span>Found on Ghozt ({syncedContacts.length})</span>
                    </div>
                    {syncedContacts.map((c) => {
                      const isAdded = userContacts.includes(c.uid);
                      const contactProfile = effectiveContacts.find(p => p.uid === c.uid);
                      const isMuted = contactProfile?.isMuted ?? false;
                      
                      return (
                        <div key={c.uid} className="flex items-center gap-3 p-2 bg-white/5 rounded-xl border border-white/5">
                          <div className="w-8 h-8 bg-zinc-900 rounded-full flex items-center justify-center overflow-hidden">
                            {c.photoURL ? <img src={c.photoURL} alt="" className="w-full h-full object-cover" /> : <User size={16} />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-bold truncate flex items-center gap-2">
                              {c.contactName}
                              {isMuted && <BellOff size={10} className="text-white/20" />}
                            </p>
                            <p className="text-[8px] text-white/40 uppercase tracking-widest truncate">@{c.displayName}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            {isAdded && (
                              <button
                                onClick={() => toggleMuteContact(c.uid)}
                                className="p-1.5 hover:bg-white/10 rounded-lg transition-colors text-white/40 hover:text-white"
                                title={isMuted ? "Unmute" : "Mute"}
                              >
                                {isMuted ? <Bell size={12} className="text-Ghozt-cyan" /> : <BellOff size={12} />}
                              </button>
                            )}
                            {isAdded ? (
                              <div className="flex items-center gap-1 text-[8px] font-bold text-Ghozt-cyan uppercase tracking-widest">
                                <Check size={10} />
                                <span>Added</span>
                              </div>
                            ) : (
                              <button
                                onClick={() => addContact(c)}
                                className="px-3 py-1.5 bg-Ghozt-purple text-white text-[10px] font-bold uppercase tracking-widest rounded-lg transition-all hover:scale-105 active:scale-95 flex items-center gap-2"
                                title="Add to Ghozt"
                              >
                                <UserPlus size={12} />
                                <span>Add to Ghozt</span>
                              </button>
                            )}
                          </div>
                          <div className={`w-2 h-2 rounded-full ${c.isOnline ? "bg-green-500" : "bg-white/10"}`} />
                        </div>
                      );
                    })}
                  </div>
                )}

                <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-white/20 mt-8 mb-4">
                  <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                  <span>Online Now ({effectiveOnlineUsers.length})</span>
                </div>

                {effectiveOnlineUsers.map((u) => (
                  <div key={u.uid} className="flex items-center gap-3 group">
                    <div className="relative">
                      {u.photoURL ? (
                        <img 
                          src={u.photoURL} 
                          alt={u.displayName} 
                          className="w-10 h-10 rounded-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-10 h-10 bg-zinc-900 rounded-full flex items-center justify-center">
                          <User size={20} className="text-white/20" />
                        </div>
                      )}
                      <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-zinc-950" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{u.displayName}</p>
                      <p className="text-[10px] text-white/40 uppercase tracking-widest font-bold">Active</p>
                    </div>
                  </div>
                ))}

                {effectiveOnlineUsers.length === 0 && (
                  <div className="text-center py-12 opacity-20">
                    <User size={32} className="mx-auto mb-2" />
                    <p className="text-xs">No one else is online</p>
                  </div>
                )}
              </div>

              <div className="mt-auto pt-6 border-t border-white/5">
                <div className="flex items-center gap-3 p-3 bg-white/5 rounded-2xl">
                  <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center overflow-hidden">
                    <img 
                      src="/icon.svg" 
                      alt="User" 
                      className="w-5 h-5 object-contain"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold truncate">{effectiveUserProfile?.displayName || user?.displayName || "Anonymous"}</p>
                    <p className="text-[8px] text-green-500 uppercase tracking-widest font-bold">You are online</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Create Group Modal */}
      <AnimatePresence>
        {showCreateGroup && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCreateGroup(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-sm glass border-Ghozt-purple/20 p-8 rounded-3xl glow-purple"
            >
              <h2 className="text-2xl font-black tracking-tighter mb-2 uppercase text-glow-purple">New Group</h2>
              <p className="text-sm text-white/60 mb-8 font-medium">Create a private room for your squad.</p>
              
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-white/40 ml-1">Group Name</label>
                  <input 
                    type="text"
                    value={newGroupName}
                    onChange={(e) => setNewGroupName(e.target.value)}
                    placeholder="The Squad"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm focus:outline-none focus:border-Ghozt-purple transition-all text-white"
                    autoFocus
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-white/40 ml-1">Add Members ({selectedGroupMembers.length})</label>
                  <div className="max-h-48 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                    {effectiveContacts.length === 0 ? (
                      <p className="text-[10px] text-white/20 uppercase tracking-widest text-center py-4">No contacts added yet</p>
                    ) : (
                      effectiveContacts.map((contact) => (
                        <div key={contact.uid} className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              if (selectedGroupMembers.includes(contact.uid)) {
                                setSelectedGroupMembers(prev => prev.filter(id => id !== contact.uid));
                              } else {
                                setSelectedGroupMembers(prev => [...prev, contact.uid]);
                              }
                            }}
                            className={cn(
                              "flex-1 flex items-center gap-3 p-3 rounded-xl border transition-all",
                              selectedGroupMembers.includes(contact.uid)
                                ? "bg-Ghozt-purple/20 border-Ghozt-purple"
                                : "bg-white/5 border-white/5 hover:bg-white/10"
                            )}
                          >
                            <div className="w-8 h-8 bg-zinc-900 rounded-full flex items-center justify-center overflow-hidden">
                              {contact.photoURL ? <img src={contact.photoURL} alt="" className="w-full h-full object-cover" /> : <User size={16} />}
                            </div>
                            <div className="flex-1 text-left">
                              <p className="text-xs font-bold truncate">{contact.displayName}</p>
                            </div>
                            {selectedGroupMembers.includes(contact.uid) && (
                              <Check size={14} className="text-Ghozt-purple" />
                            )}
                          </button>
                          <button
                            onClick={() => startDirectMessage(contact.uid)}
                            className="p-3 bg-Ghozt-cyan/10 border border-Ghozt-cyan/20 text-Ghozt-cyan rounded-xl hover:bg-Ghozt-cyan/20 transition-all"
                            title="Start Direct Message"
                          >
                            <MessageSquare size={16} />
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <button 
                  onClick={createGroup}
                  disabled={!newGroupName.trim()}
                  className="w-full py-4 bg-Ghozt-purple text-white font-black uppercase tracking-widest rounded-2xl glow-purple transition-all active:scale-95 disabled:opacity-50 disabled:active:scale-100"
                >
                  Create Room
                </button>
                
                <button 
                  onClick={() => setShowCreateGroup(false)}
                  className="w-full py-4 text-white/40 text-[10px] font-bold uppercase tracking-widest hover:text-white transition-colors"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Group Settings Modal */}
      <AnimatePresence>
        {showGroupSettings && currentRoomId !== "global-chat" && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowGroupSettings(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-sm glass border-Ghozt-purple/20 p-8 rounded-3xl glow-purple"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-black tracking-tighter uppercase text-glow-purple">
                    {effectiveGroups.find(g => g.id === currentRoomId)?.name}
                  </h2>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">Group Settings</p>
                </div>
                <button 
                  onClick={() => setShowGroupSettings(false)}
                  className="p-2 hover:bg-white/5 rounded-full transition-colors text-white/40"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-white/40 ml-1">
                    Members ({effectiveGroups.find(g => g.id === currentRoomId)?.members.length})
                  </label>
                  <div className="max-h-40 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                    {effectiveGroups.find(g => g.id === currentRoomId)?.members.map(memberId => {
                      const member = fullContacts.find(c => c.uid === memberId) || (memberId === user?.uid ? userProfile : null);
                      return (
                        <div key={memberId} className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/5">
                          <div className="w-8 h-8 bg-zinc-900 rounded-full flex items-center justify-center overflow-hidden">
                            {member?.photoURL ? <img src={member.photoURL} alt="" className="w-full h-full object-cover" /> : <User size={16} />}
                          </div>
                          <div className="flex-1">
                            <p className="text-xs font-bold truncate">{member?.displayName || "Unknown User"}</p>
                            {memberId === user?.uid && <span className="text-[8px] uppercase tracking-widest text-Ghozt-cyan font-bold">You</span>}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-white/40 ml-1">Invite Contacts</label>
                  <div className="max-h-40 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                    {effectiveContacts.filter(c => !effectiveGroups.find(g => g.id === currentRoomId)?.members.includes(c.uid)).length === 0 ? (
                      <p className="text-[10px] text-white/20 uppercase tracking-widest text-center py-4">All contacts are already here</p>
                    ) : (
                      effectiveContacts
                        .filter(c => !effectiveGroups.find(g => g.id === currentRoomId)?.members.includes(c.uid))
                        .map((contact) => (
                          <button
                            key={contact.uid}
                            onClick={() => inviteToGroup(currentRoomId, [contact.uid])}
                            className="w-full flex items-center gap-3 p-3 bg-white/5 border border-white/5 rounded-xl hover:bg-white/10 transition-all group"
                          >
                            <div className="w-8 h-8 bg-zinc-900 rounded-full flex items-center justify-center overflow-hidden">
                              {contact.photoURL ? <img src={contact.photoURL} alt="" className="w-full h-full object-cover" /> : <User size={16} />}
                            </div>
                            <div className="flex-1 text-left">
                              <p className="text-xs font-bold truncate">{contact.displayName}</p>
                            </div>
                            <Plus size={14} className="text-Ghozt-cyan opacity-0 group-hover:opacity-100 transition-opacity" />
                          </button>
                        ))
                    )}
                  </div>
                </div>

                <div className="pt-4 space-y-3">
                  <button 
                    onClick={() => leaveGroup(currentRoomId)}
                    className="w-full py-4 bg-red-500/10 border border-red-500/20 text-red-500 font-black uppercase tracking-widest rounded-2xl hover:bg-red-500/20 transition-all active:scale-95"
                  >
                    Leave Group
                  </button>
                  
                  <button 
                    onClick={() => setShowGroupSettings(false)}
                    className="w-full py-4 text-white/40 text-[10px] font-bold uppercase tracking-widest hover:text-white transition-colors"
                  >
                    Close
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Phone Number Prompt */}
      <AnimatePresence>
        {showPhonePrompt && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center bg-Ghozt-bg/95 backdrop-blur-2xl p-6"
          >
            <div className="w-full max-w-xs text-center">
              <div className="w-16 h-16 bg-Ghozt-purple/10 rounded-3xl flex items-center justify-center mx-auto mb-6 border border-Ghozt-purple/20 glow-purple rotate-6">
                <Smartphone size={32} className="text-Ghozt-cyan" />
              </div>
              <h2 className="text-3xl font-black tracking-tighter mb-2 text-glow-cyan">Sync Contacts</h2>
              <p className="text-sm text-white/60 mb-8 leading-relaxed font-medium">
                Add your phone number to find friends already using Ghozt. Your number is never shared.
              </p>
              
              <div className="space-y-4">
                <input
                  type="tel"
                  placeholder="+1 (555) 000-0000"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full bg-Ghozt-purple/5 border border-Ghozt-purple/20 rounded-2xl p-4 text-center text-lg font-mono focus:outline-none focus:border-Ghozt-cyan/40 transition-colors text-white placeholder:text-white/20"
                />
                <button
                  onClick={savePhoneNumber}
                  disabled={phoneNumber.replace(/\D/g, "").length < 10}
                  className="w-full bg-Ghozt-cyan text-black font-black uppercase tracking-widest text-xs py-4 rounded-2xl active:scale-95 transition-all glow-cyan disabled:opacity-50"
                >
                  Continue
                </button>
                <button
                  onClick={() => setShowPhonePrompt(false)}
                  className="text-[10px] font-bold uppercase tracking-widest text-Ghozt-cyan/40 hover:text-Ghozt-cyan transition-colors"
                >
                  Maybe Later
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Onboarding Modal */}
      <AnimatePresence>
        {showOnboarding && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="w-full max-w-md glass border-Ghozt-purple/30 rounded-[2.5rem] overflow-hidden flex flex-col glow-purple"
            >
              <div className="p-8 flex flex-col items-center text-center">
                <div className="w-20 h-20 bg-Ghozt-purple/20 rounded-full flex items-center justify-center mb-6 border border-Ghozt-purple/30 glow-purple overflow-hidden">
                  <img 
                    src="/logo.jpg" 
                    alt="Ghozt Logo" 
                    className="w-full h-full object-contain rounded-full drop-shadow-[0_0_10px_rgba(0,229,255,0.4)]"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "/icon.svg";
                    }}
                  />
                </div>
                
                <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Welcome to <span className="text-Ghozt-cyan">GHOZT</span>
                </h2>
                <p className="text-white/40 text-xs font-bold uppercase tracking-widest mb-8">The Phantom Protocol</p>
                
                <div className="space-y-6 w-full text-left">
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-Ghozt-cyan/10 flex items-center justify-center shrink-0 border border-Ghozt-cyan/20">
                      <Clock size={20} className="text-Ghozt-cyan" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white uppercase tracking-tight">Ephemeral Messaging</h3>
                      <p className="text-xs text-white/40 leading-relaxed">Every message has a timer. Once it reaches zero, it's gone forever from our servers.</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-Ghozt-pink/10 flex items-center justify-center shrink-0 border border-Ghozt-pink/20">
                      <Shield size={20} className="text-Ghozt-pink" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white uppercase tracking-tight">Screenshot Deterrents</h3>
                      <p className="text-xs text-white/40 leading-relaxed">Our system detects and flags screenshot attempts. Privacy is our absolute priority.</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-Ghozt-purple/10 flex items-center justify-center shrink-0 border border-Ghozt-purple/20">
                      <EyeOff size={20} className="text-Ghozt-purple" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white uppercase tracking-tight">Privacy Shield</h3>
                      <p className="text-xs text-white/40 leading-relaxed">Enable Privacy Cloak to go invisible or use Privacy Shield to hide your identity.</p>
                    </div>
                  </div>
                </div>
                
                <button
                  onClick={() => setShowOnboarding(false)}
                  className="w-full mt-10 py-4 bg-Ghozt-cyan text-black text-xs font-black uppercase tracking-[0.2em] rounded-2xl glow-cyan hover:scale-[1.02] active:scale-95 transition-all"
                >
                  Enter the Void
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delete Account Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowDeleteConfirm(false)}
              className="absolute inset-0 bg-black/95 backdrop-blur-2xl"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-sm glass border-red-500/20 p-8 rounded-3xl glow-pink"
            >
              <div className="w-16 h-16 bg-red-500/10 rounded-2xl flex items-center justify-center mb-6 border border-red-500/20 glow-pink">
                <AlertCircle size={32} className="text-red-500" />
              </div>
              <h2 className="text-2xl font-black tracking-tighter mb-2 uppercase text-red-500">Delete Account?</h2>
              <p className="text-sm text-white/60 mb-8 font-medium leading-relaxed">
                This will permanently delete your profile, messages, and contacts. This action cannot be undone.
              </p>
              
              <div className="space-y-4">
                <button 
                  onClick={deleteAccount}
                  className="w-full py-4 bg-red-500 text-white font-black uppercase tracking-widest rounded-2xl shadow-[0_0_20px_rgba(239,68,68,0.3)] transition-all active:scale-95"
                >
                  Yes, Delete Everything
                </button>
                
                <button 
                  onClick={() => setShowDeleteConfirm(false)}
                  className="w-full py-4 text-white/40 text-[10px] font-bold uppercase tracking-widest hover:text-white transition-colors"
                >
                  No, Keep My Account
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
    </ErrorBoundary>
  );
}
