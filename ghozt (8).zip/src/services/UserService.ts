import { 
  collection, 
  query, 
  limit, 
  getDocs, 
  orderBy, 
  onSnapshot, 
  doc, 
  updateDoc, 
  arrayUnion, 
  arrayRemove,
  where,
  getDoc
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { UserProfile } from '../types';
import { handleFirestoreError, OperationType } from '../lib/error-handler';

export class UserService {
  private static COLLECTION = 'users';

  static async getUserProfile(uid: string): Promise<UserProfile> {
    try {
      const userRef = doc(db, this.COLLECTION, uid);
      const userDoc = await getDoc(userRef);
      if (userDoc.exists()) {
        return userDoc.data() as UserProfile;
      } else {
        throw new Error('Shadow Profile Not Found');
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, `${this.COLLECTION}/${uid}`);
      throw error;
    }
  }

  static async blockUser(targetUid: string): Promise<void> {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error('Not authenticated');

      const userRef = doc(db, this.COLLECTION, user.uid);
      await updateDoc(userRef, {
        blockedUsers: arrayUnion(targetUid)
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, this.COLLECTION);
    }
  }

  static async unblockUser(targetUid: string): Promise<void> {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error('Not authenticated');

      const userRef = doc(db, this.COLLECTION, user.uid);
      await updateDoc(userRef, {
        blockedUsers: arrayRemove(targetUid)
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, this.COLLECTION);
    }
  }

  static async getBlockedUsers(): Promise<string[]> {
    try {
      const user = auth.currentUser;
      if (!user) return [];

      const userDoc = await getDoc(doc(db, this.COLLECTION, user.uid));
      if (!userDoc.exists()) return [];

      const data = userDoc.data() as UserProfile;
      return data.blockedUsers || [];
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, this.COLLECTION);
      return [];
    }
  }

  static async penalizeTrustScore(points = 10): Promise<void> {
    try {
      const user = auth.currentUser;
      if (!user) return;

      const userRef = doc(db, this.COLLECTION, user.uid);
      const userDoc = await getDoc(userRef);
      if (!userDoc.exists()) return;

      const currentScore = userDoc.data().trustScore || 100;
      await updateDoc(userRef, {
        trustScore: Math.max(0, currentScore - points)
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, this.COLLECTION);
    }
  }

  static async rewardTrustScore(points = 1): Promise<void> {
    try {
      const user = auth.currentUser;
      if (!user) return;

      const userRef = doc(db, this.COLLECTION, user.uid);
      const userDoc = await getDoc(userRef);
      if (!userDoc.exists()) return;

      const currentScore = userDoc.data().trustScore || 100;
      await updateDoc(userRef, {
        trustScore: Math.min(100, currentScore + points)
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, this.COLLECTION);
    }
  }

  static async isBlocked(uid: string): Promise<boolean> {
    const blockedUsers = await this.getBlockedUsers();
    return blockedUsers.includes(uid);
  }

  static async searchUsers(searchTerm: string): Promise<UserProfile[]> {
    if (!searchTerm.trim()) return [];
    
    const term = searchTerm.trim();
    const lowerTerm = term.toLowerCase();
    try {
      // 1. Exact Email match (still useful if they enter full email)
      const qEmail = query(collection(db, this.COLLECTION), where('email', '==', term));
      
      // 2. Exact Phone match
      const qPhone = query(collection(db, this.COLLECTION), where('phone', '==', term));
      
      // 3. Name "starts with" search using lowercase field for case-insensitivity
      const qName = query(
        collection(db, this.COLLECTION), 
        where('displayName_lowercase', '>=', lowerTerm),
        where('displayName_lowercase', '<=', lowerTerm + '\uf8ff'),
        limit(20)
      );

      const [snapEmail, snapPhone, snapName] = await Promise.all([
        getDocs(qEmail),
        getDocs(qPhone),
        getDocs(qName)
      ]);

      // Use a Map to de-duplicate results by UID
      const resultsMap = new Map<string, UserProfile>();
      
      [...snapEmail.docs, ...snapPhone.docs, ...snapName.docs].forEach(doc => {
        const data = doc.data() as UserProfile;
        if (data.uid !== auth.currentUser?.uid) {
          resultsMap.set(data.uid, data);
        }
      });

      return Array.from(resultsMap.values());
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, this.COLLECTION);
      return [];
    }
  }

  static async searchUsersByPhoneNumbers(phones: string[]): Promise<UserProfile[]> {
    if (phones.length === 0) return [];
    
    try {
      // Firebase "in" queries have a limit of 30 items per query
      const batches = [];
      for (let i = 0; i < phones.length; i += 30) {
        batches.push(phones.slice(i, i + 30));
      }

      const results: UserProfile[] = [];
      for (const batch of batches) {
        const q = query(
          collection(db, this.COLLECTION),
          where('phone', 'in', batch)
        );
        const snapshot = await getDocs(q);
        snapshot.docs.forEach(doc => {
          results.push(doc.data() as UserProfile);
        });
      }

      return results.filter(u => u.uid !== auth.currentUser?.uid);
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, this.COLLECTION);
      return [];
    }
  }

  static async getAllUsers(maxResults = 50): Promise<UserProfile[]> {
    try {
      const q = query(
        collection(db, this.COLLECTION),
        orderBy('displayName'),
        limit(maxResults)
      );
      const snapshot = await getDocs(q);
      return snapshot.docs
        .map(doc => doc.data() as UserProfile)
        .filter(u => u.uid !== auth.currentUser?.uid);
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, this.COLLECTION);
      return [];
    }
  }

  static subscribeToAllUsers(callback: (users: UserProfile[]) => void) {
    const q = query(collection(db, this.COLLECTION), orderBy('displayName'), limit(100));
    return onSnapshot(q, (snapshot) => {
      const users = snapshot.docs
        .map(doc => doc.data() as UserProfile)
        .filter(u => u.uid !== auth.currentUser?.uid);
      callback(users);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, this.COLLECTION);
    });
  }
}
