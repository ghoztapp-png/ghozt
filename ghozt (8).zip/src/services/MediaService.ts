import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { storage, auth } from '../lib/firebase';

export class MediaService {
  static async uploadMedia(file: File, conversationId: string): Promise<string> {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error('Not authenticated');

      const fileName = `${Date.now()}_${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
      const storageRef = ref(storage, `conversations/${conversationId}/media/${fileName}`);
      
      console.log(`📡 Initializing shadow transmission: ${fileName}`);

      return new Promise((resolve, reject) => {
        const uploadTask = uploadBytesResumable(storageRef, file);

        uploadTask.on('state_changed', 
          (snapshot) => {
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            console.log(`⚡ Transmission progress: ${progress.toFixed(2)}%`);
          }, 
          (error) => {
            console.error("❌ Shadow transmission interrupted:", error);
            if (error.code === 'storage/retry-limit-exceeded') {
              reject(new Error("Signal Timeout: The grid is too noisy or Storage is not enabled in your Firebase Console. Please try again or check your bucket settings."));
            } else if (error.code === 'storage/unauthorized') {
              reject(new Error("Access Denied: The spectral gates are locked. Ensure Storage Rules are deployed."));
            } else {
              reject(error);
            }
          }, 
          async () => {
            const url = await getDownloadURL(uploadTask.snapshot.ref);
            console.log(`✅ Transmission successful: ${url}`);
            resolve(url);
          }
        );
      });
    } catch (error: any) {
      console.error("Media upload failed:", error);
      throw error;
    }
  }

  static async uploadVoice(blob: Blob, conversationId: string): Promise<string> {
    const fileName = `voice_${Date.now()}.webm`;
    const storageRef = ref(storage, `conversations/${conversationId}/media/${fileName}`);
    const uploadTask = await uploadBytesResumable(storageRef, blob);
    return await getDownloadURL(uploadTask.ref);
  }
}
