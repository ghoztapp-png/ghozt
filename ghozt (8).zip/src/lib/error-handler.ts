import { auth } from './firebase';
import { toast } from 'sonner';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  
  if (errInfo.error.includes('insufficient permissions')) {
    toast.error("Access Refused", { description: "Encryption handshake failed or unauthorized frequency." });
  } else if (errInfo.error.includes('No document to update')) {
    toast.error("Shadow Missing", { description: "The destination frequency does not exist." });
  } else if (errInfo.error.toLowerCase().includes('unavailable') || errInfo.error.toLowerCase().includes('could not reach')) {
    toast.error("Network Jammed", { description: "Shadow network connection interrupted. Retrying..." });
  } else if (errInfo.error.toLowerCase().includes('quota exceeded')) {
    toast.error("Protocol Capacity Reached", { description: "Daily shadow transmission limit exceeded. Resets in 24h." });
  }

  throw new Error(JSON.stringify(errInfo));
}
