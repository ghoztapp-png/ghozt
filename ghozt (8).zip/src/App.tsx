import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MessageSquare, Users } from "lucide-react";
import { FirebaseProvider, useFirebase } from "./context/FirebaseContext";
import { Toaster } from "sonner";
import { ConversationList } from "./components/ConversationList";
import { ChatWindow } from "./components/ChatWindow";
import { PrivacyService } from "./services/PrivacyService";

import { SplashScreen } from "./components/SplashScreen";
import { PrivacyPolicy } from "./components/PrivacyPolicy";
import { LandingPage } from "./components/LandingPage";
import { TermsOfService } from "./components/TermsOfService";

function AppContent() {
  const { user, loading } = useFirebase();
  const [showSplash, setShowSplash] = useState(true);
  const [currentScreen, setCurrentScreen] = useState<'home' | 'privacy' | 'terms'>('home');

  useEffect(() => {
    PrivacyService.initialize();
    
    // Fallback timer to ensure app loads even if splash takes too long
    const timer = setTimeout(() => setShowSplash(false), 3500);
    return () => clearTimeout(timer);
  }, []);

  if (loading) return null;

  return (
    <div className="h-[100dvh] w-full flex flex-col overflow-hidden bg-phantom-black text-white font-sans selection:bg-phantom-purple/30">
      <AnimatePresence mode="wait">
        {showSplash ? (
          <SplashScreen key="splash" onComplete={() => setShowSplash(false)} />
        ) : !user ? (
          <div key="auth-flow" className="flex-1 flex flex-col min-h-0">
            <AnimatePresence mode="wait">
              {currentScreen === 'home' && (
                <LandingPage key="home" onNavigate={setCurrentScreen} />
              )}
              {currentScreen === 'privacy' && (
                <PrivacyPolicy key="privacy" onBack={() => setCurrentScreen('home')} />
              )}
              {currentScreen === 'terms' && (
                <TermsOfService key="terms" onBack={() => setCurrentScreen('home')} />
              )}
            </AnimatePresence>
          </div>
        ) : (
          <Dashboard key="dashboard" />
        )}
      </AnimatePresence>
      <Toaster 
        position="top-center" 
        theme="dark" 
        richColors 
        toastOptions={{ 
          style: { 
            background: 'rgba(15, 15, 15, 0.8)', 
            border: '1px solid rgba(157, 80, 187, 0.3)', 
            backdropFilter: 'blur(10px)', 
            color: 'white' 
          } 
        }} 
      />
    </div>
  );
}

import { ProfileScreen } from "./components/ProfileScreen";

function Dashboard() {
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [showProfile, setShowProfile] = useState(false);

  if (showProfile) {
    return <ProfileScreen onBack={() => setShowProfile(false)} />;
  }

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-phantom-black relative">
      <AnimatePresence mode="wait">
        {!selectedConversationId ? (
          <motion.div 
            key="list"
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -20, opacity: 0 }}
            className="flex-1 flex flex-col min-h-0"
          >
            <header className="flex items-center justify-between p-6 glass border-b border-white/5">
              <motion.div 
                className="flex items-center gap-3 cursor-pointer group"
                whileHover={{ x: 2 }}
                transition={{ type: "spring", stiffness: 400, damping: 10 }}
              >
                <motion.div
                  animate={{ 
                    y: [0, -3, 0],
                    filter: ["drop-shadow(0 0 10px rgba(157,80,187,0.4))", "drop-shadow(0 0 20px rgba(157,80,187,0.6))", "drop-shadow(0 0 10px rgba(157,80,187,0.4))"]
                  }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="relative flex items-center justify-center w-12 h-12 rounded-full overflow-hidden border border-phantom-purple/30 bg-black"
                >
                  <img src="https://i.imgur.com/KjaXBWH.png" alt="Ghozt Logo" className="w-full h-full object-cover" />
                </motion.div>
                <div className="relative">
                  <motion.h1 
                    animate={{ opacity: [1, 0.9, 1, 0.8, 1] }}
                    transition={{ duration: 5, repeat: Infinity, times: [0, 0.45, 0.5, 0.55, 1] }}
                    className="text-4xl font-serif font-bold tracking-widest text-transparent bg-clip-text bg-gradient-to-br from-white via-phantom-purple to-phantom-purple drop-shadow-[0_0_12px_rgba(157,80,187,0.5)] group-hover:drop-shadow-[0_0_20px_rgba(0,229,255,0.8)] transition-all uppercase"
                  >
                    Ghozt
                  </motion.h1>
                  <motion.h1 
                    animate={{ 
                      x: [-2, 2, -1, 3, 0],
                      opacity: [0, 0.8, 0, 0.9, 0],
                      clipPath: [
                        "inset(10% 0 80% 0)", 
                        "inset(50% 0 30% 0)", 
                        "inset(20% 0 60% 0)", 
                        "inset(80% 0 10% 0)",
                        "inset(0 0 100% 0)"
                      ]
                    }}
                    transition={{ duration: 0.4, repeat: Infinity, repeatDelay: 4 }}
                    className="absolute top-0 left-[2px] text-4xl font-serif font-bold tracking-widest uppercase text-phantom-purple z-10 drop-shadow-[0_0_10px_rgba(0,229,255,1)]"
                  >
                    Ghozt
                  </motion.h1>
                </div>
              </motion.div>
              <button 
                onClick={() => setShowProfile(true)}
                className="h-10 w-10 rounded-full bg-phantom-purple/20 border border-phantom-purple/30 glow-purple overflow-hidden flex items-center justify-center transition-transform active:scale-95"
              >
                <div className="text-[10px] uppercase font-bold text-phantom-purple">User</div>
              </button>
            </header>
            
            <div className="flex-1 overflow-hidden">
               <ConversationList 
                 onSelect={(id) => setSelectedConversationId(id)} 
                 selectedId={selectedConversationId} 
               />
            </div>

            <nav className="flex items-center justify-around p-6 glass border-t border-white/5 pb-10">
              <div className="text-phantom-purple drop-shadow-[0_0_5px_rgba(0,229,255,0.5)]"><MessageSquare /></div>
              <div className="text-muted-foreground hover:text-white transition-colors" onClick={() => setShowProfile(true)}><Users /></div>
            </nav>
          </motion.div>
        ) : (
          <motion.div 
            key="chat"
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 20, opacity: 0 }}
            className="flex-1 flex flex-col overflow-hidden min-h-0"
          >
            <ChatWindow 
              conversationId={selectedConversationId} 
              onBack={() => setSelectedConversationId(null)} 
              onOpenProfile={() => setShowProfile(true)}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

const GhostIcon = ({ size = 24, className = "" }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M9 10h.01M15 10h.01M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z" />
  </svg>
);

export default function App() {
  return (
    <FirebaseProvider>
      <AppContent />
    </FirebaseProvider>
  );
}
