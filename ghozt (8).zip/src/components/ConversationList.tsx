import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, orderBy } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { Conversation, UserProfile } from '../types';
import { MessageSquare, Users, Plus, User as UserIcon, ArrowLeft, ShieldAlert, ShieldCheck, Zap, Activity, RefreshCw, Search, X, Share2, Clipboard } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { motion, AnimatePresence } from 'motion/react';
import { UserService } from '../services/UserService';
import { MessageService } from '../services/MessageService';
import { NewChatDialog } from './NewChatDialog';
import { useFirebase } from '../context/FirebaseContext';
import { toast } from 'sonner';
import { Capacitor } from '@capacitor/core';
import { Contacts } from '@capacitor-community/contacts';

interface ConversationListProps {
  onSelect: (id: string) => void;
  selectedId?: string | null;
}

export const ConversationList: React.FC<ConversationListProps> = ({ onSelect, selectedId }) => {
  const { profile } = useFirebase();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'chats' | 'contacts'>('chats');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    // Subscribe to conversations
    const qConv = query(
      collection(db, 'conversations'),
      where('participants', 'array-contains', user.uid),
      orderBy('updatedAt', 'desc')
    );

    const unsubscribeConv = onSnapshot(qConv, (snapshot) => {
      const list = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Conversation[];
      setConversations(list);
      if (view === 'chats') setLoading(false);
    });

    // Subscribe to users
    const unsubscribeUsers = UserService.subscribeToAllUsers((allUsers) => {
      setUsers(allUsers);
      if (view === 'contacts') setLoading(false);
    });

    return () => {
      unsubscribeConv();
      unsubscribeUsers();
    };
  }, [view]);

  const handleSyncContacts = async () => {
    try {
      setIsSyncing(true);
      
      let matchingUsers = [];

      if (Capacitor.isNativePlatform()) {
        const permission = await Contacts.checkPermissions();
        
        if (permission.contacts !== 'granted') {
          const request = await Contacts.requestPermissions();
          if (request.contacts !== 'granted') {
            toast.error("Contact permission denied.");
            setIsSyncing(false);
            return;
          }
        }

        const result = await Contacts.getContacts({
          projection: {
            name: true,
            phones: true,
          }
        });

        const phoneNumbers = result.contacts
          .flatMap(c => c.phones?.map(p => p.number.replace(/\D/g, '')) || [])
          .filter(n => n.length >= 10);

        if (phoneNumbers.length === 0) {
          toast.info("No valid phone contacts found.");
          setIsSyncing(false);
          return;
        }

        matchingUsers = await UserService.searchUsersByPhoneNumbers(phoneNumbers);
      } else {
        toast.info("Web bypass active. Initiating global shadow ping...");
        matchingUsers = await UserService.getAllUsers();
        matchingUsers = matchingUsers.filter(u => u.uid !== auth.currentUser?.uid);
      }
      
      if (matchingUsers.length > 0) {
        setUsers(prev => {
          const existingIds = new Set(prev.map(u => u.uid));
          const newUsers = matchingUsers.filter(u => !existingIds.has(u.uid));
          return [...newUsers, ...prev];
        });
        toast.success(`Found ${matchingUsers.length} shadows in your contact list!`);
      } else {
        toast.info("No matching shadows found.");
      }
    } catch (error) {
      console.error(error);
      toast.error("Shadow sync failed.");
    } finally {
      setIsSyncing(false);
    }
  };

  const handleStartChat = async (targetUserId: string) => {
    if (profile?.blockedUsers?.includes(targetUserId)) {
      toast.error("Frequency Blocked. Clear encryption protocol first.");
      return;
    }
    try {
      const conversationId = await MessageService.getOrCreateConversation([targetUserId]);
      onSelect(conversationId);
      setView('chats');
    } catch (error: any) {
      toast.error(error.message || "Failed to start shadow");
    }
  };

  const handleToggleBlock = async (e: React.MouseEvent, targetUserId: string) => {
    e.stopPropagation();
    const isBlocked = profile?.blockedUsers?.includes(targetUserId);
    try {
      if (isBlocked) {
        await UserService.unblockUser(targetUserId);
        toast.success("Frequency Restored");
      } else {
        await UserService.blockUser(targetUserId);
        toast.success("Shadow Purged");
      }
    } catch (error) {
      toast.error("Operation Failed");
    }
  };

  const visibleConversations = conversations.filter(c => {
    // Filter out private chats with blocked users
    if (c.type === 'private') {
      const otherParticipant = c.participants.find(p => p !== auth.currentUser?.uid);
      if (otherParticipant && profile?.blockedUsers?.includes(otherParticipant)) {
        return false;
      }
    }
    
    // Search filtering
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      if (c.name?.toLowerCase().includes(term)) return true;
      
      // If private, check other participant's name
      if (c.type === 'private') {
        const otherId = c.participants.find(p => p !== auth.currentUser?.uid);
        const otherUser = users.find(u => u.uid === otherId);
        if (otherUser?.displayName.toLowerCase().includes(term)) return true;
        if (otherUser?.email.toLowerCase().includes(term)) return true;
      }
      return false;
    }

    return true;
  });

  const filteredUsers = users.filter(u => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    return (
      u.displayName.toLowerCase().includes(term) ||
      u.email.toLowerCase().includes(term) ||
      u.phone?.includes(term)
    );
  });

  const handleShare = async () => {
    const shareData = {
      title: 'Join the Shadow Protocol',
      text: 'Encrypted, ephemeral, and absolute privacy. Join me on GHOZT.',
      url: window.location.origin
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
        toast.success("Frequency Shared", { description: "Invitation sent to the network." });
      } else {
        throw new Error('Web Share API not supported');
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        // User canceled, do nothing
        return;
      }
      
      console.warn('Share failed, falling back to clipboard:', err);
      try {
        await navigator.clipboard.writeText(window.location.origin);
        toast.success("Link Cached", { description: "Invite link copied to clipboard." });
      } catch (clipErr) {
        toast.error("Bridge Failure", { description: "Invite link could not be shared." });
      }
    }
  };

  return (
    <div className="flex flex-col h-full bg-phantom-black overflow-hidden relative">
      <div className="p-6 pb-2">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            {view === 'contacts' && (
              <button 
                onClick={() => setView('chats')}
                className="p-1 hover:text-phantom-purple transition-colors"
              >
                <ArrowLeft size={16} />
              </button>
            )}
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground">
              {view === 'chats' ? 'Active Sessions' : 'Global Shadows'}
            </h2>
          </div>
          
          <div className="flex items-center gap-1">
            {view === 'contacts' && (
              <button 
                onClick={handleSyncContacts}
                disabled={isSyncing}
                className={`p-2 rounded-full transition-all hover:bg-white/5 text-muted-foreground ${isSyncing ? 'animate-spin text-phantom-purple' : ''}`}
                title="Sync Contacts"
              >
                <RefreshCw size={20} />
              </button>
            )}
            <button 
              onClick={() => setView(view === 'chats' ? 'contacts' : 'chats')}
              className={`p-2 rounded-full transition-all ${
                view === 'contacts' ? 'bg-phantom-purple/20 text-phantom-purple' : 'hover:bg-white/5 text-muted-foreground'
              }`}
              title={view === 'chats' ? "View Contacts" : "View Chats"}
            >
              <UserIcon size={20} />
            </button>
            <NewChatDialog onSuccess={(id) => onSelect(id)} />
          </div>
        </div>

        <div className="relative mb-4 group">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground group-focus-within:text-phantom-purple transition-colors" />
          <input 
            type="text"
            placeholder={view === 'chats' ? "Search sessions..." : "Search shadows..."}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white/5 border border-white/5 focus:border-phantom-purple/30 focus:bg-white/[0.08] rounded-xl py-2 pl-9 pr-9 text-xs transition-all outline-none"
          />
          {searchTerm && (
            <button 
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-white"
            >
              <X size={14} />
            </button>
          )}
        </div>

        {!profile?.isPremium && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4 mt-2 px-4"
          >
            <div className="p-3 rounded-lg bg-[#111111] border border-white/5 flex items-center justify-between group overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-r from-phantom-purple/0 via-phantom-purple/5 to-phantom-purple/0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
              <div className="flex items-center gap-3 relative z-10">
                <div className="w-8 h-8 rounded bg-phantom-purple/10 flex items-center justify-center text-phantom-purple">
                  <Zap size={14} />
                </div>
                <div className="flex flex-col">
                  <span className="text-[11px] font-bold text-white leading-none mb-1">Ghozt Premium</span>
                  <span className="text-[9px] text-white/40 leading-none">Remove ads & unlock themes</span>
                </div>
              </div>
              <button 
                onClick={() => toast.info("Premium upgrade required ($5.89).")}
                className="relative z-10 px-3 py-1.5 rounded bg-white/10 text-[9px] font-bold text-white hover:bg-white/20 transition-colors"
              >
                Upgrade
              </button>
            </div>
          </motion.div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-20 custom-scrollbar relative">
        <AnimatePresence mode="wait">
          {view === 'chats' ? (
            <motion.div 
              key="chats"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
            >
              {loading ? (
                Array(5).fill(0).map((_, i) => (
                  <div key={i} className="mb-2 h-20 w-full animate-pulse rounded-2xl bg-white/5"></div>
                ))
              ) : visibleConversations.length === 0 ? (
                <div className="mt-20 text-center opacity-30">
                  <Ghost className="mx-auto mb-4" size={48} />
                  <p className="text-sm">{searchTerm ? 'No frequency match.' : 'No ghosts detected.'}</p>
                </div>
              ) : (
                <>
                  {/* Global Frequency (Always at top) */}
                  <motion.div
                    whileTap={{ scale: 0.98 }}
                    onClick={() => onSelect('global')}
                    className={`group mb-1 flex w-full items-center gap-3 rounded-xl p-3 transition-all hover:bg-white/5 cursor-pointer border ${
                      selectedId === 'global' ? 'bg-phantom-purple/10 border-phantom-purple/30' : 'border-transparent'
                    }`}
                  >
                    <div className="relative shrink-0">
                      <div className="h-10 w-10 border border-phantom-purple/30 bg-phantom-purple/10 text-phantom-purple flex items-center justify-center rounded-lg">
                        <Activity size={20} className="animate-pulse" />
                      </div>
                      <div className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-green-500 border-[1.5px] border-phantom-black"></div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-0.5">
                        <h3 className="text-sm font-black text-phantom-purple uppercase tracking-tighter italic">Global Frequency</h3>
                        <span className="text-[8px] font-black bg-phantom-purple/20 text-phantom-purple px-1.5 py-0.5 rounded uppercase">Public</span>
                      </div>
                      <p className="text-[11px] text-white/40 truncate italic">Synchronizing all shadows...</p>
                    </div>
                  </motion.div>

                  {visibleConversations.map((conv) => (
                  <motion.div
                    key={conv.id}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => onSelect(conv.id)}
                    className={`group mb-1 flex w-full items-center gap-3 rounded-xl p-3 transition-all hover:bg-white/5 cursor-pointer ${
                      selectedId === conv.id ? 'bg-white/10 shadow-sm border border-white/5' : 'border border-transparent'
                    }`}
                  >
                    <div className="relative shrink-0">
                      <Avatar className="h-10 w-10 border border-white/10 group-hover:border-phantom-purple/30 transition-colors bg-black/50">
                        {conv.type === 'private' ? (
                          <>
                            <AvatarImage src={users.find(u => u.uid === conv.participants.find(p => p !== auth.currentUser?.uid))?.photoURL || undefined} />
                            <AvatarFallback className="text-white/50 bg-black">
                              {(users.find(u => u.uid === conv.participants.find(p => p !== auth.currentUser?.uid))?.displayName?.[0] || 'S')}
                            </AvatarFallback>
                          </>
                        ) : (
                          <>
                            <AvatarImage src={`https://avatar.vercel.sh/${conv.id}`} />
                            <AvatarFallback className="text-white/50 bg-black">
                              <Users size={18} />
                            </AvatarFallback>
                          </>
                        )}
                      </Avatar>
                      <div className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-phantom-purple border-[1.5px] border-phantom-black shadow-[0_0_8px_rgba(157,80,187,0.4)]"></div>
                    </div>
                    
                    <div className="flex-1 min-w-0 flex flex-col justify-center">
                      <div className="flex items-center justify-between mb-0.5">
                        <h3 className="text-sm font-semibold text-white/90 truncate">
                          {conv.name || (conv.type === 'group' ? 'Unnamed Group' : (users.find(u => u.uid === conv.participants.find(p => p !== auth.currentUser?.uid))?.displayName || 'Private Shadow'))}
                        </h3>
                        <span className="text-[10px] font-medium text-white/30 shrink-0 ml-2">
                          {conv.updatedAt?.toDate() ? new Intl.DateTimeFormat('en-US', { hour: 'numeric', minute: 'numeric' }).format(conv.updatedAt.toDate()) : ''}
                        </span>
                      </div>
                      <p className="text-[11px] text-white/40 truncate flex items-center gap-1.5">
                         <ShieldCheck size={10} className="text-phantom-purple/50" />
                         Encrypted communication
                      </p>
                    </div>
                  </motion.div>
                ))}
              </>
            )}
          </motion.div>
        ) : (
            <motion.div 
              key="contacts"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
              className="space-y-2"
            >
              <div className="flex items-center gap-2 mb-4">
                <button 
                  onClick={handleSyncContacts}
                  disabled={isSyncing}
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-phantom-purple/10 border border-phantom-purple/20 text-phantom-purple text-xs font-bold uppercase tracking-widest hover:bg-phantom-purple/20 transition-all disabled:opacity-50"
                >
                  <RefreshCw size={14} className={isSyncing ? 'animate-spin' : ''} />
                  {isSyncing ? 'Syncing...' : 'Sync Patterns'}
                </button>
                <button 
                  onClick={handleShare}
                  className="flex items-center justify-center w-12 h-12 rounded-xl bg-white/5 border border-white/10 text-white hover:bg-white/10 transition-all"
                  title="Share Invite Link"
                >
                  <Share2 size={18} />
                </button>
              </div>

              {filteredUsers.length === 0 ? (
                <div className="mt-20 text-center opacity-30">
                  <UserIcon className="mx-auto mb-4" size={48} />
                  <p className="text-sm">{searchTerm ? 'Shadow not found.' : 'No other shadows active.'}</p>
                </div>
              ) : (
                filteredUsers.map((user) => (
                  <motion.div
                    key={user.uid}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleStartChat(user.uid)}
                    className="group mb-1 flex w-full items-center gap-3 rounded-xl p-3 transition-all hover:bg-white/5 cursor-pointer border border-transparent"
                  >
                    <Avatar className="h-10 w-10 border border-white/10 group-hover:border-phantom-purple/30 transition-colors bg-black/50 shrink-0">
                      <AvatarImage src={user.photoURL || undefined} />
                      <AvatarFallback className="text-white/50 bg-black">
                        {user.displayName[0]}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0 flex flex-col justify-center text-left">
                      <h3 className="text-sm font-semibold text-white/90 truncate">{user.displayName}</h3>
                      <p className="text-[11px] text-white/40 truncate flex items-center gap-1.5 mt-0.5">
                         {user.email}
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-1 shrink-0">
                       <button 
                         onClick={(e) => handleToggleBlock(e, user.uid)}
                         className={`p-2 rounded-lg transition-all ${
                           profile?.blockedUsers?.includes(user.uid) 
                           ? 'bg-red-500/20 text-red-500 opacity-100' 
                           : 'opacity-0 group-hover:opacity-100 text-white/30 hover:text-red-500 hover:bg-white/5'
                         }`}
                         title={profile?.blockedUsers?.includes(user.uid) ? "Unblock" : "Block"}
                       >
                         {profile?.blockedUsers?.includes(user.uid) ? <ShieldAlert size={16} /> : <ShieldCheck size={16} />}
                       </button>

                       <button 
                         onClick={(e) => { e.stopPropagation(); handleStartChat(user.uid); }}
                         className="p-2 rounded-lg opacity-0 group-hover:opacity-100 transition-all text-white/30 hover:text-phantom-purple hover:bg-white/5"
                       >
                          <Plus size={16} />
                       </button>
                    </div>
                  </motion.div>
                ))
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="absolute bottom-6 left-0 right-0 flex flex-col items-center pointer-events-none select-none">
        <p className="text-[9px] font-black uppercase tracking-[0.4em] text-phantom-purple opacity-20">Chat without echoes</p>
        <p className="text-[7px] font-mono text-white/10 tracking-widest mt-1">GHOZT_v4.0.2</p>
      </div>
    </div>
  );
};

const Ghost = ({ size = 24, className = "" }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M9 10h.01M15 10h.01M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z" />
  </svg>
);
