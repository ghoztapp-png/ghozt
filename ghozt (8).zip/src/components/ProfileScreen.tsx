import React, { useState } from 'react';
import { motion } from 'motion/react';
import { User, Shield, CreditCard, LogOut, Moon, Sun, Palette, Zap, Bell, BellOff, ShieldAlert, Play, Share2 } from 'lucide-react';
import { useFirebase } from '../context/FirebaseContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { db } from '../lib/firebase';
import { doc, updateDoc, arrayRemove } from 'firebase/firestore';
import { toast } from 'sonner';
import { NotificationService } from '../services/NotificationService';

export const ProfileScreen: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const { user, profile, signOut } = useFirebase();
  const [selectedTheme, setSelectedTheme] = useState('phantom');

  const playPreview = (type: 'messages' | 'mentions' | 'system', sound: string) => {
    if (!user) return;
    // We create a temporary profile-like object to preview
    const previewProfile = {
      ...profile,
      notifications: {
        ...profile?.notifications,
        [type]: { enabled: true, sound }
      }
    } as any;
    NotificationService.playSound(type, user.uid);
  };

  const themes = [
    { id: 'phantom', name: 'Phantom', color: 'bg-phantom-purple', border: 'border-phantom-purple' },
    { id: 'void', name: 'Void', color: 'bg-black', border: 'border-white/20' },
    { id: 'mist', name: 'Mist', color: 'bg-gray-400', border: 'border-black' },
    { id: 'solar', name: 'Solar', color: 'bg-amber-500', border: 'border-amber-900' }
  ];

  const updateSetting = async (key: string, value: any) => {
    if (!user) return;
    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, { [key]: value });
      toast.success('Frequency Synchronized');
    } catch (e) {
      console.error(e);
      toast.error('Sync Interrupted');
    }
  };

  const handleUnblock = async (uid: string) => {
    if (!user) return;
    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, {
        blockedUsers: arrayRemove(uid)
      });
      toast.success('Frequency Restored');
    } catch (e) {
      toast.error('Operation Failed');
    }
  };

  const handleShare = async () => {
    const shareData = {
      title: 'Join the Shadow Protocol',
      text: 'Encrypted, ephemeral, and absolute privacy. Join me on GHOZT.',
      url: window.location.origin
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
        toast.success("Frequency Shared", { description: "Invitation sent to the network." });
      } else {
        throw new Error('Web Share API not supported');
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        // User canceled, do nothing
        return;
      }
      
      console.warn('Share failed, falling back to clipboard:', err);
      try {
        await navigator.clipboard.writeText(window.location.origin);
        toast.success("Link Cached", { description: "Invite link copied to clipboard." });
      } catch (clipErr) {
        toast.error("Bridge Failure", { description: "Invite link could not be shared." });
      }
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col h-full bg-phantom-black p-6 overflow-y-auto"
    >
      <header className="flex items-center gap-4 mb-8">
        <button onClick={onBack} className="text-muted-foreground">Back</button>
        <h2 className="text-xl font-bold italic uppercase tracking-widest">Ghost Profile</h2>
      </header>

      <div className="flex flex-col items-center mb-8">
         <div className="relative mb-4">
            <Avatar className="h-24 w-24 border-2 border-phantom-purple shadow-[0_0_20px_rgba(157,80,187,0.2)]">
               <AvatarImage src={user?.photoURL || undefined} />
               <AvatarFallback className="bg-phantom-purple text-2xl uppercase">
                  {user?.displayName?.[0]}
               </AvatarFallback>
            </Avatar>
            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2">
               <Badge className="bg-phantom-purple text-phantom-black font-black text-[10px]">
                  {profile?.isPremium ? 'PREMIUM' : 'FREE SHADOW'}
               </Badge>
            </div>
         </div>
         <h3 className="text-xl font-bold">{user?.displayName}</h3>
         <p className="text-xs text-muted-foreground opacity-60 mb-2">{user?.email}</p>
         
         <div className="flex items-center gap-2 mt-2 w-full max-w-[240px]">
            <input 
               type="tel"
               placeholder="Enter Phone Contact..."
               defaultValue={profile?.phone || ''}
               onBlur={(e) => updateSetting('phone', e.target.value)}
               className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-center focus:outline-none focus:border-phantom-purple/50 focus:bg-white/10 transition-all font-mono"
            />
         </div>
         <p className="text-[10px] text-muted-foreground opacity-30 mt-2 uppercase italic">Required for shadow lookup</p>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-8">
         <div className="glass p-4 rounded-2xl border-white/5 flex flex-col items-center">
            <Shield className="text-phantom-purple mb-2" size={24} />
            <span className="text-[10px] uppercase font-bold text-muted-foreground">Trust Score</span>
            <span className="text-2xl font-black text-phantom-purple">{profile?.trustScore || 100}</span>
         </div>
         <div className="glass p-4 rounded-2xl border-white/5 flex flex-col items-center">
            <Zap className="text-phantom-purple mb-2" size={24} />
            <span className="text-[10px] uppercase font-bold text-muted-foreground">Days Active</span>
            <span className="text-2xl font-black text-white">4</span>
         </div>
      </div>

      <div className="space-y-4 pb-12">
         {/* Do Not Disturb Toggle */}
         <div className="glass p-5 rounded-2xl border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-3">
               <div className={profile?.dndMode ? "text-red-500" : "text-phantom-purple"}>
                  {profile?.dndMode ? <BellOff size={18} /> : <Bell size={18} />}
               </div>
               <div>
                  <p className="text-xs font-bold uppercase">Do Not Disturb</p>
                  <p className="text-[10px] text-muted-foreground opacity-60">Silence all incoming shadows</p>
               </div>
            </div>
            <Switch 
               checked={profile?.dndMode || false} 
               onCheckedChange={(val) => updateSetting('dndMode', val)}
               className="data-[state=checked]:bg-phantom-purple"
            />
         </div>

         <div className="glass p-5 rounded-2xl border-white/5">
            <div className="flex items-center gap-3 mb-4">
               <Palette size={18} className="text-muted-foreground" />
               <span className="text-xs font-bold uppercase tracking-wider">Interface Mood</span>
            </div>
            <div className="flex justify-between">
               {themes.map(t => (
                 <button 
                  key={t.id}
                  onClick={() => setSelectedTheme(t.id)}
                  className={`flex flex-col items-center gap-2 transition-all ${selectedTheme === t.id ? 'scale-110' : 'opacity-40 grayscale'}`}
                 >
                    <div className={`h-8 w-8 rounded-full ${t.color} border-2 ${t.border}`} />
                    <span className="text-[8px] font-bold uppercase">{t.name}</span>
                 </button>
               ))}
            </div>
         </div>

         {/* Notification Preferences */}
         <div className="glass p-5 rounded-2xl border-white/5 space-y-6">
            <div className="flex items-center gap-3 mb-2">
               <Bell size={18} className="text-muted-foreground" />
               <span className="text-xs font-bold uppercase tracking-wider">Shadow Alerts</span>
            </div>
            
            {/* Messages */}
            <div className="space-y-3">
               <div className="flex items-center justify-between">
                  <div>
                     <p className="text-[10px] uppercase font-bold">Shadow Messages</p>
                     <p className="text-[8px] text-muted-foreground opacity-60">Private direct frequency alerts</p>
                  </div>
                  <Switch 
                     checked={profile?.notifications?.messages?.enabled !== false}
                     onCheckedChange={(val) => updateSetting('notifications.messages.enabled', val)}
                     className="data-[state=checked]:bg-phantom-purple"
                  />
               </div>
               {profile?.notifications?.messages?.enabled !== false && (
                  <div className="flex gap-2">
                     {['phantom', 'whisper', 'pulse', 'static'].map(s => (
                        <button
                           key={s}
                           onClick={() => {
                             updateSetting('notifications.messages.sound', s);
                             playPreview('messages', s);
                           }}
                           className={`flex-1 group relative pt-1.5 pb-2 rounded-lg border text-[8px] font-black uppercase transition-all ${
                              (profile?.notifications?.messages?.sound || 'phantom') === s
                              ? 'bg-phantom-purple/20 border-phantom-purple text-phantom-purple'
                              : 'bg-white/5 border-white/5 text-muted-foreground'
                           }`}
                        >
                           {s}
                           <Play size={8} className="absolute bottom-0 right-1 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </button>
                     ))}
                  </div>
               )}
            </div>

            {/* Mentions */}
            <div className="space-y-3">
               <div className="flex items-center justify-between">
                  <div>
                     <p className="text-[10px] uppercase font-bold">Group Mentions</p>
                     <p className="text-[8px] text-muted-foreground opacity-60">When your shadow is tagged in groups</p>
                  </div>
                  <Switch 
                     checked={profile?.notifications?.mentions?.enabled !== false}
                     onCheckedChange={(val) => updateSetting('notifications.mentions.enabled', val)}
                     className="data-[state=checked]:bg-phantom-purple"
                  />
               </div>
               {profile?.notifications?.mentions?.enabled !== false && (
                  <div className="flex gap-2">
                     {['phantom', 'whisper', 'pulse', 'static'].map(s => (
                        <button
                           key={s}
                           onClick={() => {
                             updateSetting('notifications.mentions.sound', s);
                             playPreview('mentions', s);
                           }}
                           className={`flex-1 group relative pt-1.5 pb-2 rounded-lg border text-[8px] font-black uppercase transition-all ${
                              (profile?.notifications?.mentions?.sound || 'phantom') === s
                              ? 'bg-phantom-purple/20 border-phantom-purple text-phantom-purple'
                              : 'bg-white/5 border-white/5 text-muted-foreground'
                           }`}
                        >
                           {s}
                           <Play size={8} className="absolute bottom-0 right-1 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </button>
                     ))}
                  </div>
               )}
            </div>

            {/* Core Updates */}
            <div className="flex items-center justify-between">
               <div>
                  <p className="text-[10px] uppercase font-bold">System Alerts</p>
                  <p className="text-[8px] text-muted-foreground opacity-60">Security & integrity notifications</p>
               </div>
               <Switch 
                  checked={profile?.notifications?.system?.enabled !== false}
                  onCheckedChange={(val) => updateSetting('notifications.system.enabled', val)}
                  className="data-[state=checked]:bg-phantom-purple"
               />
            </div>

            {profile?.isPremium && (
               <div className="pt-2 border-t border-white/5">
                  <p className="text-[10px] font-black text-phantom-purple uppercase mb-2">Internal Override: Custom Sound URL</p>
                  <div className="flex gap-2">
                     <input 
                        type="text"
                        placeholder="https://.../alert.mp3"
                        className="flex-1 bg-white/5 border border-white/10 rounded-lg p-2 text-[10px] outline-none focus:border-phantom-purple/50"
                        onBlur={(e) => {
                           if (e.target.value) {
                              updateSetting('notifications.customSounds.alert', e.target.value);
                           }
                        }}
                     />
                     <button className="bg-phantom-purple/10 border border-phantom-purple/30 text-phantom-purple p-2 rounded-lg text-[10px] font-bold">SYNC</button>
                  </div>
               </div>
            )}
         </div>

         {/* Blocked Users */}
         {profile?.blockedUsers && profile.blockedUsers.length > 0 && (
           <div className="glass p-5 rounded-2xl border-white/5 space-y-4">
              <div className="flex items-center gap-3 mb-2">
                 <ShieldAlert size={18} className="text-red-500" />
                 <span className="text-xs font-bold uppercase tracking-wider">Purged Frequencies</span>
              </div>
              <div className="space-y-2">
                 {profile.blockedUsers.map(uid => (
                   <div key={uid} className="flex items-center justify-between bg-white/5 p-3 rounded-xl">
                      <span className="text-[10px] font-mono opacity-60">ID: {uid.slice(0, 12)}...</span>
                      <button 
                        onClick={() => handleUnblock(uid)}
                        className="text-[10px] uppercase font-black text-phantom-purple hover:underline"
                      >
                        Restore
                      </button>
                   </div>
                 ))}
              </div>
           </div>
         )}

         <button className="w-full glass p-5 rounded-2xl border-white/5 flex items-center justify-between group hover:border-phantom-purple/30 transition-all">
            <div className="flex items-center gap-3">
               <CreditCard size={18} className="text-phantom-purple" />
               <span className="text-xs font-bold uppercase">Upgrade to Premium</span>
            </div>
            <span className="text-[10px] font-bold text-phantom-purple">$5.89</span>
         </button>

         <button 
           onClick={handleShare}
           className="w-full p-5 rounded-2xl bg-phantom-purple text-phantom-black flex items-center justify-center gap-3 font-bold text-xs uppercase shadow-[0_0_20px_rgba(157,80,187,0.3)]"
         >
            <Share2 size={16} strokeWidth={3} />
            Invite Contacts
         </button>

         <button 
           onClick={signOut}
           className="w-full p-5 rounded-2xl border border-red-500/20 bg-red-500/5 flex items-center justify-center gap-3 text-red-500 font-bold text-xs uppercase"
         >
            <LogOut size={16} />
            Purge Session
         </button>
      </div>

      <div className="mt-auto text-center py-8 flex flex-col items-center gap-1.5 opacity-20 select-none">
        <p className="text-[10px] font-black uppercase tracking-[0.4em] text-phantom-purple">Chat without echoes</p>
        <p className="text-[7px] font-mono tracking-widest">GHOZT_v4.0.2 // ENCRYPTED_NODE</p>
      </div>
    </motion.div>
  );
};
