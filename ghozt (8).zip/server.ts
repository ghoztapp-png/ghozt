import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { createServer as createViteServer } from 'vite';
import path from 'path';

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  const PORT = 3000;

  // Real-time signals
  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('typing', (data) => {
      socket.to(data.roomId).emit('typing', { 
        userId: data.userId, 
        userName: data.userName, 
        isTyping: data.isTyping 
      });
    });

    socket.on('screenshot', (data) => {
      socket.to(data.roomId).emit('screenshot', { 
        userId: data.userId, 
        userName: data.userName 
      });
    });

    socket.on('join', (roomId) => {
      socket.join(roomId);
    });

    socket.on('leave', (roomId) => {
      socket.leave(roomId);
    });

    socket.on('disconnect', () => {
      console.log('User disconnected');
    });
  });

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
  });

  // Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Ghozt server running on http://localhost:${PORT}`);
  });
}

startServer();
